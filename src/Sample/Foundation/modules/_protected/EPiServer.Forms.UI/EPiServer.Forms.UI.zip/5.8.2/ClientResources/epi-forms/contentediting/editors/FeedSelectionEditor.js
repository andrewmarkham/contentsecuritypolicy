define("epi-forms/contentediting/editors/FeedSelectionEditor", [// dojo
"dojo/_base/declare", "dojo/_base/lang", // epi-cms
"epi-cms/contentediting/editors/SelectionEditor"], function ( // dojo
declare, lang, // epi-cms
SelectionEditor) {
  // module:
  //      epi-forms/contentediting/editors/FeedSelectionEditor
  // tags:
  //      protected
  return declare([SelectionEditor], {
    postMixInProperties: function postMixInProperties() {
      // summary:
      //		Set options based on the selections passed through.
      this.inherited(arguments);
      this.connect(this, "_handleOnChange", lang.hitch(this, function (value, priotyChange) {
        this.onFeedValueChange(this.name, value);
      }));
    },
    onFeedValueChange: function onFeedValueChange(propertyName, value) {// summary:
      //		Callback when this widget's value is changed.
      // tags:
      //		callback
    }
  });
});