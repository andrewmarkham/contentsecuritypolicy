define("epi-forms/widget/_ChoiceItemWith", [// dojo
"dojo/_base/declare", "dojo/_base/lang", "dojo/Deferred", "dojo/dom-class", "dojo/dom-construct", "dojo/Evented", "dojo/when", // epi-addons
"epi-forms/_UtilityMixin", "epi-forms/ModuleSettings", "epi-forms/widget/ChoiceItem"], function ( // dojo
declare, lang, Deferred, domClass, domConstruct, Evented, when, // epi-addons
_UtilityMixin, ModuleSettings, ChoiceItem) {
  // module:
  //      epi-forms/widget/_ChoiceItemWith
  // summary:
  //      Base class for an instance of 'epi-forms/widget/ChoiceItem' class with additional WIDGET.
  //      Render a row of checkbox, with  label, and extended widget (a previewable textbox, ...)
  // tags:
  //      protected
  return declare([ChoiceItem, _UtilityMixin, Evented], {
    // _recordFieldSeparator: [private] String
    //
    _recordFieldSeparator: ModuleSettings.recordFieldSeparator,
    _addExtendedWidgetDeferred: null,
    // =======================================================================
    // Public, overrided stubs
    // =======================================================================
    buildRendering: function buildRendering() {
      this.inherited(arguments);
      this._addExtendedWidgetDeferred = new Deferred();

      this._addExtendedWidget(this.item);
    },
    // =======================================================================
    // Protected stubs
    // =======================================================================
    _getExtendedWidget: function _getExtendedWidget() {
      // summary:
      //      Gets created extended widget object.
      // returns: [Object]
      //      An instance of 'dijit/_Widget' class.
      // tags:
      //      protected
      if (this._extendedWidget) {
        return this._extendedWidget;
      }

      return this._addExtendedWidgetDeferred;
    },
    _setExtendedWidgetValueAttr: function _setExtendedWidgetValueAttr(
    /*Object*/
    item) {
      // summary:
      //
      // item: [Object]
      //      Item data object used to build extended widget.
      // tags:
      //      protected
      if (!this._extendedWidget || !item) {
        return;
      }

      var extendedWidgetValue = this._getExtendedWidgetValue(item);

      if (extendedWidgetValue != null) {
        this._extendedWidget.set("value", extendedWidgetValue);
      }
    },
    _getExtendedWidgetValue: function _getExtendedWidgetValue(
    /*Object*/
    item) {
      // summary:
      //      Gets stored value to display on the extended widget.
      // item: [Object]
      //      Item data object used to build extended widget.
      // returns: [String]
      //      Value to display on the extended widget.
      // tags:
      //      protected
      if (!item) {
        return;
      }

      var itemValue = item.value;

      if (!itemValue) {
        return;
      }

      if (itemValue.indexOf(this._recordFieldSeparator) === -1) {
        return;
      }

      return itemValue.split(this._recordFieldSeparator).pop() || "";
    },
    _validToAddExtendedWidget: function _validToAddExtendedWidget(
    /*Object*/
    item) {
      // summary:
      //      Verifies that should be to create and then add extended widget or not.
      //      By default, return TRUE.
      //      Can be modified in an extended class.
      // item: [Object]
      //      Item data object used to build extended widget.
      // returns: [Boolean]
      //      TRUE:       Create and then Add extended widget. (Default)
      //      FALSE:      Do nothing.
      // tags:
      //      protected, abstract
      return true;
    },
    _updateSelectorValue: function _updateSelectorValue(
    /*String*/
    value) {
      // summary:
      //
      // value: [String]
      //
      // returns: [String]
      //
      // tags:
      //      protected, extensions
      var selectorValue = this._selector.value;

      if (typeof selectorValue === "string") {
        var extendedValue = this._recordFieldSeparator + value;

        this._selector.set("value", selectorValue.indexOf(this._recordFieldSeparator) === -1 ? selectorValue + extendedValue : selectorValue.split(this._recordFieldSeparator)[0] + extendedValue);

        this.emit("selectorChanged");
      }
    },
    // =======================================================================
    // Private stubs
    // =======================================================================
    _addExtendedWidget: function _addExtendedWidget(
    /*Object*/
    item) {
      // summary:
      //      Places created widget as the last child of the selector container section.
      // item: [Object]
      //      Item data object used to build extended widget.
      // tags:
      //      private
      if (!this.extendedWidgetType || !this._validToAddExtendedWidget(item)) {
        return;
      }

      when(this.getInstanceFromType(this.extendedWidgetType, this._getParams(item)), lang.hitch(this, function (
      /*Object*/
      extendedWidget) {
        // extendedWidget: [Object]
        //      An instance of 'dijit/_Widget' class.
        if (!extendedWidget || !extendedWidget.domNode || !this.selectorContainer) {
          this._addExtendedWidgetDeferred.resolve(null);

          return;
        }

        domClass.add(extendedWidget.domNode, "epi-forms-extendedWidget");
        domConstruct.place(extendedWidget.domNode, this.selectorLabel, "after");
        this._extendedWidget = extendedWidget;

        this._addExtendedWidgetDeferred.resolve(extendedWidget);
      }));
    },
    _getParams: function _getParams(item) {
      // summary:
      //      Return the object which includes every parameters to initialize the extended widget
      // item: [Object]
      //      Item data object used to build extended widget.
      // tags:
      //      protected
      return {
        readOnly: item.readOnly
      };
    }
  });
});