define([
    "dojo/topic",
    "dojo/when",
    "epi/dependency",
    "epi/shell/StickyViewSelector",
    "epi/shell/TypeDescriptorManager"
], function (
    topic,
    when,
    dependency,
    StickyViewSelector,
    TypeDescriptorManager
) {
    function initialize() {
    }

    return {
        initialize: initialize
    };
});
