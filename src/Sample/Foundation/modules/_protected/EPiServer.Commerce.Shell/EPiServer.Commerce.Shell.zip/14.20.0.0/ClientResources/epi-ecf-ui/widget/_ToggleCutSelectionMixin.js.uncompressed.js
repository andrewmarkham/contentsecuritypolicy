﻿define("epi-ecf-ui/widget/_ToggleCutSelectionMixin", [
    // dojo
    "dojo/_base/declare",
    "dojo/dom-class"
], function (
    // dojo
    declare,
    domClass
) {
        return declare(null, {
            postCreate: function () {
                this.inherited(arguments);
                this.own(
                    this.model.clipboardManager.watch("data", function (name, oldValues, newValues) {
                        var isCopy = this.model.clipboardManager.isCopy(),
                            grid = this.grid;

                        var toggleCut = function (items, isCut) {
                            items.forEach(function (clip) {
                                var row;
                                if (clip && clip.data && clip.data.rowId) {
                                    var rowId = clip.data.rowId;
                                    row = grid.row(rowId);
                                    if (row && row.element) {
                                        domClass.toggle(row.element, "epi-row-cut", isCut);
                                    }
                                }
                            });
                        };

                        if (oldValues instanceof Array) {
                            toggleCut(oldValues, false);
                        }

                        if (!isCopy && newValues instanceof Array) {
                            toggleCut(newValues, true);
                        }
                    }.bind(this))
                );
            }
        });
    });