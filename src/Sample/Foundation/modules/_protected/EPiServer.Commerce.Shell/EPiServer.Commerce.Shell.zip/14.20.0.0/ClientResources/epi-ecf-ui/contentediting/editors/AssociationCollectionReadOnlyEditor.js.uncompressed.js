﻿define("epi-ecf-ui/contentediting/editors/AssociationCollectionReadOnlyEditor", [
    // dojo
    "dojo/_base/declare",
    // epi commerce
    "./ReadOnlyCollectionEditor",
    "../viewmodel/AssociationCollectionReadOnlyEditorModel",
        
    // Resources
    "epi/i18n!epi/cms/nls/commerce.contentediting.editors.associationcollectioneditor"
],
function (
    //dojo
    declare,
    // epi commerce
    ReadOnlyCollectionEditor,
    AssociationCollectionReadOnlyEditorModel,

    res
) {
    return declare([ReadOnlyCollectionEditor], {
        // module: 
        //      epi-ecf-ui/contentediting/editors/AssociationCollectionEditor
        // summary:
        //      Represents the Read-only editor widget for product's association list.

        _renderNoDataMessage: function () {
            this.grid.set("noDataMessage", res.nodatamessage);
            this.inherited(arguments);
        },

        iconClass: "epi-iconReferences",

        modelType: AssociationCollectionReadOnlyEditorModel,
        
        changeToView: "relatedentrieseditview",

        buttonLabel: res.editbuttontext
    });
});