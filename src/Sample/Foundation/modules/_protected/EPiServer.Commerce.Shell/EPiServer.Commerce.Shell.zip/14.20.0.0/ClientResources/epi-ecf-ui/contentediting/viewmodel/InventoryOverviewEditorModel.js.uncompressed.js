﻿define("epi-ecf-ui/contentediting/viewmodel/InventoryOverviewEditorModel", [
    // dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/promise/all",

    // dojox
    "dojox/html/entities",

    // epi
    "epi/shell/command/DelegateCommand",
    "epi/datetime",
    "epi-cms/dgrid/formatters",
    "epi/shell/dgrid/util/misc",

    // commerce
    "./_OverviewEditorModelBase",

    // resources
    "epi/i18n!epi/cms/nls/commerce.widget.pricingoverview.grid",
    "epi/i18n!epi/cms/nls/commerce.widget.pricecollection.message"
],
function (
    //dojo
    array,
    declare,
    all,

    // dojox
    htmlEntities,

    // epi
    DelegateCommand,
    epiDate,
    formatters,
    misc,

    // commerce
    _OverviewEditorModelBase,

    // resources
    resources,
    res
) {
    return declare([_OverviewEditorModelBase], {
        // module:
        //      epi-ecf-ui/contentediting/viewmodel/InventoryOverviewEditorModel
        // summary:
        //      Represents the model for InventoryOverviewEditor

        _storeKey: "epi.commerce.inventory",

        _createQueryOptions: function () {
            // summary:
            //      Creates and returns query options, based on selected content link, market id and customer group (if any).
            // tags:
            //      private

            return {
                query: { referenceId: this.get("contentLink"), query: "getinventory" }
            };
        },

        getCommands: function (model, category) {
            return [
                new DelegateCommand({
                    name: "remove",
                    label: resources.commands.remove,
                    iconClass: "epi-iconTrash",
                    category: category,
                    model: model,
                    canExecute: true,
                    isAvailable: true,
                    delegate: function (cmd) {
                        this.emit("removeCommandEvent");
                    }.bind(this)
                })
            ];
        },

        removeItems: function (models) {
            var promises = [];

            for (var i = 0, j = models.length; i < j; i += 1) {
                promises.push(this.store.remove(models[i].contentLink + "$" + models[i].warehouseCode));
            }

            return all(promises).then(function (removed) {
                this.emit("itemsRemoved", { removedItems: removed });
            }.bind(this));
        },

        generateFormatters: function (columnDefinitions, editableColumns, metadata) {
            var warehouseCodeFormatter = function (value) { return value; };

            for (var definitionName in columnDefinitions) {
                var column = columnDefinitions[definitionName];

                if (definitionName === "warehouseCode") {
                    column.formatter = warehouseCodeFormatter;
                    continue;
                }

                if (!this._isColumnEditable(definitionName, editableColumns)) {
                    continue;
                }

                if (definitionName === "backorderAvailableUtc" || definitionName === "preorderAvailableUtc" || definitionName === "purchaseAvailableUtc") {
                    column.formatter = formatters.localizedDate;
                } else if (definitionName === "isTracked") {
                    column.formatter = formatters.friendlyBoolean;
                } else if (column.editorArgs && column.editorArgs.selections && column.editorArgs.selections.length > 0) {
                    column.formatter = this._getSelectionFormatter(column);
                } else {
                    column.formatter = this._editableValueFormatter;
                }

                column.className = column.className ? column.className + " epi-dgrid--editable" : "epi-dgrid--editable";
            }
        },

        getAllItems: function (contentLink) {
            return this.store.query({ referenceId: contentLink });
        }
    });
});