require({cache:{
'url:epi-ecf-ui/contentediting/editors/templates/BuyOneGetOneDiscountItemsEditor.html':"﻿<div>\r\n    <div class=\"epi-form-container__section__row\">\r\n        <div data-dojo-attach-point=\"freeQuantity\"\r\n            data-dojo-type=\"dijit/form/NumberSpinner\"\r\n            data-dojo-props=\"constraints: { min: 1 }\">\r\n        </div>\r\n    </div>\r\n    <div class=\"epi-form-container__section__row\">\r\n        <div>\r\n            <input type=\"radio\" data-dojo-type=\"dijit/form/RadioButton\" data-dojo-attach-point=\"customerGetsSame\" name=\"useCampaignDateGroup_${id}\" id=\"customerGetsSame_${id}\" />\r\n            <label for=\"customerGetsSame_${id}\">${resources.customergetssame}</label>\r\n            <label data-dojo-attach-point=\"labelUseCampaign\" for=\"customerGetsSame_${id}\"></label>\r\n        </div>\r\n    </div>\r\n    <div class=\"epi-form-container__section__row\">\r\n        <div>\r\n            <input type=\"radio\" data-dojo-type=\"dijit/form/RadioButton\" data-dojo-attach-point=\"notCustomerGetsSame\" name=\"useCampaignDateGroup_${id}\" id=\"notCustomerGetsSame_${id}\" />\r\n            <label for=\"notCustomerGetsSame_${id}\">${resources.notcustomergetssame}</label>\r\n        </div>\r\n    </div>\r\n    <div class=\"epi-form-container__section__row\" data-dojo-attach-point=\"validDateFields\">\r\n        <div data-dojo-type=\"epi-ecf-ui/contentediting/editors/ContentReferenceListEditor\" data-dojo-attach-point=\"listEditor\" data-dojo-props=\"roots: this.roots, allowedTypes: this.allowedTypes\"></div>\r\n    </div>\r\n</div>"}});
﻿define("epi-ecf-ui/contentediting/editors/BuyOneGetOneDiscountItemsEditor", [
    // dojo
        "dojo/_base/declare",
        "dojo/_base/lang",
        "dojo/dom-style",
        "dojo/string",
    // dijit
        "dijit/form/RadioButton",
        "dijit/_WidgetBase",
        "dijit/_TemplatedMixin",
        "dijit/_WidgetsInTemplateMixin",
    // epi
        "epi/epi",
        "epi/shell/widget/_FocusableMixin",
        "epi/shell/widget/_ModelBindingMixin",
    // commerce
        "./../viewmodel/BuyOneGetOneDiscountItemsEditorViewModel",
    // template
        "dojo/text!./templates/BuyOneGetOneDiscountItemsEditor.html",
    // resources
        "epi/i18n!epi/cms/nls/commerce.contentediting.editors.buyonegetonediscountitems"
    ], function (
    // dojo
        declare,
        lang,
        domStyle,
        string,
    // dijit
        RadioButton,
        _WidgetBase,
        _TemplatedMixin,
        _WidgetsInTemplateMixin,
    // epi
        epi,
        _FocusableMixin,
        _ModelBindingMixin,
    // commerce
        BuyOneGetOneDiscountItemsEditorViewModel,
    // template
        template,
    // resources
        resources
    ) {
    
        return declare([_WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin, _ModelBindingMixin, _FocusableMixin], {
            // module:
            //  epi-ecf-ui/contentediting/editors/BuyOneGetOneDiscountItemsEditor
            // summary:
            //    Represents the widget to edit discount items of buy one get one promotion.
            // tags:
            //    public
    
            templateString: template,
    
            modelType: BuyOneGetOneDiscountItemsEditorViewModel,
    
            resources: resources,
    
            modelBindingMap: {
                "freeQuantity": ["freeQuantity"],
                "isCustomerGetsSame": ["isCustomerGetsSame"],
                "items": ["items"]
            },
    
            postMixInProperties: function () {
                this.inherited(arguments);
    
                if (!this.model && this.modelType) {
                    this.model = new this.modelType({ value: this.value });
                }
            },
    
            buildRendering: function () {
                this.inherited(arguments);
    
                this.own(
                    this.freeQuantity.on("change", function (value) {
                        this.model.set("freeQuantity", value);
                        this._raiseOnChange();
                    }.bind(this)),
                    this.customerGetsSame.on("change", function (value) {
                        this.model.set("isCustomerGetsSame", value);
                        this._raiseOnChange();
                    }.bind(this)),
                    this.listEditor.on("change", function (value) {
                        this.model.set("items", value);
                        this._raiseOnChange();
                    }.bind(this))
                );
            },

            _setRadioButtonState: function (value) {
                this.customerGetsSame.set("checked", value);
                this.notCustomerGetsSame.set("checked", !value);
            },
    
            _setIsCustomerGetsSameAttr: function (value) {
                domStyle.set(this.validDateFields, "display", value ? "none" : "");

                this._setRadioButtonState(value);
            },

            _setFreeQuantityAttr: function (value) {
                this.freeQuantity.set("value", value);
            },
    
            _setItemsAttr: function (value) {
                this.listEditor.set("value", value);
            },

            _getValueAttr: function () {
                return this.model.get("value");
            },
    
            _setValueAttr: function (value) {
                this.model.set("value", value);
            },
    
            _raiseOnChange: function() {
                this.onChange(this.model.get("value"));
            },
    
            onChange: function (value) {
                // summary:
                //    Fired when value is changed.
                // tags:
                //    public, callback
            }
        });
    });
    