define("epi-ecf-ui/contentediting/viewmodel/BuyOneGetOneDiscountItemsEditorViewModel", [
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/Stateful",
    "dojo/when",
    "dojo/string",

    "epi/dependency"
], function (
    array,
    declare,
    Stateful,
    when,
    string,

    dependency
) {
    return declare([Stateful], {
        // module:
        //  epi-ecf-ui/contentediting/viewmodel/BuyOneGetOneDiscountItemsEditorViewModel
        // summary:
        //    Represents the view model for Buy one get one discount items editor widget.
        // tags:
        //    public

        store: null,

        value: null,

        postscript: function () {
            this.inherited(arguments);

            if (!this.store) {
                var registry = dependency.resolve("epi.storeregistry");
                this.store = registry.get("epi.cms.contentdata");
            }
        },

        _valueSetter: function (value) {
            this.set("items", value ? value.items : null);
            this.set("isCustomerGetsSame", value && !!value.isCustomerGetsSame);
            this.set("freeQuantity", value && value.freeQuantity);
        },

        _valueGetter: function () {
            return {
                freeQuantity: this.get("freeQuantity"),
                isCustomerGetsSame: this.get("isCustomerGetsSame"),
                items: this.get("items")
            };
        }
    });
});
