﻿define("epi-ecf-ui/contentediting/editors/_GridWithItemEditorMixin", [
    // dojo
    "dojo/_base/declare",
    // epi
    "epi-cms/core/ContentReference",
    "epi-ecf-ui/widget/CatalogContentSelectorDialog"
], function (
    // dojo
    declare,
    // epi
    ContentReference,
    CatalogContentSelectorDialog
) {
        return declare(null, {
            itemEditorType: CatalogContentSelectorDialog,

            _createItemEditor: function () {
                var itemEditor = new this.itemEditorType({
                    canSelectOwnerContent: false,
                    showButtons: false,
                    roots: this.roots,
                    allowedTypes: this.itemEditorTypes,
                    showAllLanguages: false
                });

                this._updateItemEditor(itemEditor);

                return itemEditor;
            },

            _updateItemEditor: function (itemEditor) {
                // summary:
                //      Add checking condition for the given item editor.
                //      The user will not able to add current content to the editor's content list.
                // itemEditor: [object]
                //      The current instance of item editor.
                // tags:
                //      protected

                var contextContentLink = new ContentReference(this.model.get("contentLink")).createVersionUnspecificReference().toString();
                declare.safeMixin(itemEditor, {
                    _setValueAttr: function (value) {
                        this.inherited(arguments);
                        // Store seleted item in order to compares it with the current context content.
                        this._currentSelectedItem = value;
                    },
                    _getValueAttr: function () {
                        var inherited = this.getInherited(arguments);
                        // Returns blank value in order to tell that editor's actions should not enabled.
                        return this._currentSelectedItem === contextContentLink ? "" : inherited.apply(this, arguments);
                    }
                });
            }
        });
    });