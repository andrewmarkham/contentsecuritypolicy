﻿define("epi-ecf-ui/widget/DiscountTree", [
// dojo 
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/promise/all",
// dijit
    "dijit/Tree",
// epi
    "epi-cms/core/ContentReference",
// epi-ecf-ui
    "../MarketingUtils",
    "./_DiscountTreeNode",
    "./viewmodel/DiscountTreeStoreModel"
],

function (
// dojo    
    array,
    declare,
    all,
// dijit
    Tree,
// epi
    ContentReference,
// epi-ecf-ui
    MarketingUtils,
    _DiscountTreeNode,
    DiscountTreeStoreModel
) {

    return declare([Tree], {
        // summary:
        //      Represents the tree which display all promotions available, and provides the ability of selecting multiple campaigns and discounts.
        // tags:
        //      internal

        // visibleCampaignNodes [protected] TreeNode Array
        //     Represents visible campaign nodes
        visibleCampaignNodes: null,

        postMixInProperties: function () {
            this.inherited(arguments);

            this.model = this.model || new DiscountTreeStoreModel({
                root: this.root,
                store: this.store
            });

            this.persist = false;

            // Disabling multiselect in tree
            this.dndController.singular = true;
        },

        setNodeChecked: function(itemData) {
            array.every(this.rootNode.getChildren(), function (campaignNode) {
                var found = false;
                if (MarketingUtils.isSalesCampaign(itemData.typeIdentifier) &&
                itemData.id === campaignNode.item.contentLink) { // item data is campaign and match the id
                    campaignNode.checkbox.set("checked", true); // check the campaign
                    campaignNode.onNodeClicked(); // trigger event to set model
                    campaignNode._updateChildrenNode(true);
                    this.focusNode(campaignNode);
                    found = true; // found the target, set true to break the loop
                } else if (MarketingUtils.isPromotionData(itemData.typeIdentifier) &&
                itemData.parentId === campaignNode.item.contentLink) { // item data is discount and parent matchs campaign id
                    this._expandNode(campaignNode).then(function() { // first expand campaign node
                        array.every(campaignNode.getChildren(), function (discountNode) {
                            if (itemData.id === discountNode.item.contentLink) {
                                discountNode.checkbox.set("checked", true); // check the discount
                                discountNode.onNodeClicked(); // trigger event to set model
                                this.focusNode(discountNode);
                                found = true; // found the target, set true to break the loop
                            }
                            return !found; // return true to continue loop, false to break the loop
                        }.bind(this));
                    }.bind(this));
                }
                return !found; // return true to continue loop, false to break the loop
            }.bind(this));
        },

        _onHomeKey: function(){
            // summary:
            //		Home key pressed; get first visible node, and set focus there
            var node = this.rootNode;
            if(node){
                this.focusNode(node);
            }
        },

        _onDownArrow: function (/*Object*/ message) {
            // summary:
            //		down arrow pressed; get next visible node, set focus there
            var node = message.node,
                nextNode = null;

            do {
                if (node.isExpandable && node.isExpanded && node.hasChildren()) {
                    nextNode = node.getChildren()[0];
                } else {
                    nextNode = node.getNextSibling() || node.getParent().getNextSibling();
                }

                node = nextNode;
            } while (node && node.item.hidden);

            if (node && node.isTreeNode) {
                this.focusNode(node);
            }
        },

        _onUpArrow: function (/*Object*/ message) {
            // summary:
            //		Up arrow pressed; move to previous visible node

            var node = message.node,
                previousSibling = null;

            do {
                previousSibling = node.getPreviousSibling();

                if (previousSibling) {
                    node = previousSibling;
                    // if the previous node is expanded, dive in deep
                    if (node.isExpandable && node.isExpanded && node.hasChildren()) {
                        // move to the last child
                        var children = node.getChildren();
                        node = children[children.length - 1];
                    }
                } else {
                    // if this is the first child, return the parent
                    // unless the parent is the root of a tree with a hidden root
                    var parent = node.getParent();
                    if (this.showRoot || parent !== this.rootNode) {
                        node = parent;
                    }
                }
            } while (node && node.isTreeNode && node.item.hidden);

            if (node && node.isTreeNode) {
                this.focusNode(node);
            }
        },

        _onNodeSelectChanged: function (node) {
            var rootNode = this.rootNode;

            if (node === rootNode) {
                // if checked the root return all option, else return empty
                this.model.set("checkedItems", node.get("checked") ? [node.item] : []);
                return;
            }

            // get all checked options from campaigns and discounts
            var checkedItems = [];
            var isCampaignUnchecked = false;
            array.forEach(rootNode.getChildren(), function (campaignNode) {
                if (campaignNode.get("checked")) {
                    checkedItems.push(campaignNode.item);
                } else {
                    isCampaignUnchecked = true;
                    array.forEach(campaignNode.getChildren(), function (discountNode) {
                        if (discountNode.get("checked")) {
                            checkedItems.push(discountNode.item);
                        }
                    });
                }
            });

            // In case there is no unchecked campaign, should return all option
            this.model.set("checkedItems", isCampaignUnchecked ? checkedItems : [this.rootNode.item]);
        },

        _setCheckedItemsAttr: function (items) {
            // reset load def function, to refresh the getchildren query
            var rootNode = this.rootNode;
            rootNode._loadDeferred = null;
            rootNode.collapse().then(function() {
                all(array.map(rootNode.getChildren(), function (campaignNode) {
                    campaignNode._loadDeferred = null;
                    return campaignNode.collapse();
                })).then(function() {
                    this._expandNode(rootNode);
                }.bind(this));
            }.bind(this));
            
            if (items.length === 1 && ContentReference.compareIgnoreVersion(items[0].contentLink, this.root)) {
                // when checked all option
                this.rootNode.checkbox.set("checked", true);
                this.rootNode._updateChildrenNode(true); // update all children are checked
            } else {
                // reset checkbox all nodes
                this.rootNode.checkbox.set("checked", false);
                this.rootNode._updateChildrenNode(false);
                array.forEach(items, function (item) { // loop all items
                    array.every(this.rootNode.getChildren(), function (campaignNode) {
                        var found = false;
                        if (item.contentLink === campaignNode.item.contentLink) {
                            campaignNode.checkbox.set("checked", true);
                            campaignNode._updateChildrenNode(true); // checked campaign matched and all discounts
                            found = true;
                        } else if (MarketingUtils.isPromotionData(item.typeIdentifier)) {
                            array.every(campaignNode.getChildren(), function (discountNode) {
                                if (item.contentLink === discountNode.item.contentLink) {
                                    discountNode.checkbox.set("checked", true); // checked discount matched
                                    found = true;
                                }
                                return !found;
                            });
                        }
                        return !found;
                    });
                }.bind(this));
            }

            this.model.set("checkedItems", items); // set model
        },

        _getCheckedItemsAttr: function () {
            return this.model.get("checkedItems");
        },
        
        _createTreeNode: function (/*Object*/args) {
            // summary:
            //      Overridable function to create tree node.
            // args: Object
            //      Tree node creation arguments
            // tags:
            //      extension

            var node = new _DiscountTreeNode(args);
            this.own(node, node.on("nodeSelectChanged", function () {
                this._onNodeSelectChanged(node);
            }.bind(this)));

            return node;
        }
    });

});