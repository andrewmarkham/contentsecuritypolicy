define("epi-ecf-ui/widget/CmsPageTreeGadget", [
    // Dojo
        "dojo/_base/declare",
    // EPi CMS
        "epi-cms/component/ContentNavigationTree",
    ], function (
    // Dojo
        declare,
    // EPi CMS
        ContentNavigationTree
    ) {
        return declare([ContentNavigationTree], {
            // summary:
            //    Customized Content tree to removed context menu and every commands for cms page tree gadget.
            // tags:
            //    public
    
            // overrided: disable context menu.
            hasContextMenu: false,

            postMixInProperties: function () {
                // summary:
                //      Remove every commands available in cms page tree gadget.
                // tags:
                //      overrided

                this.inherited(arguments);

                this.commands = [];
            }
        });
    });
    