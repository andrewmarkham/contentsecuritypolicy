require({cache:{
'url:epi-ecf-ui/widget/templates/FilterDropDownButton.html':"<span class=\"dijit dijitReset dijitInline\">\r\n    <span class='dijitReset dijitInline dijitButtonNode' data-dojo-attach-event=\"ondijitclick:_onClick\" data-dojo-attach-point=\"_buttonNode\">\r\n        <span class=\"dijitReset dijitStretch dijitButtonContents\" data-dojo-attach-point=\"focusNode,titleNode,_arrowWrapperNode,_popupStateNode\" role=\"button\" aria-haspopup=\"true\" aria-labelledby=\"${id}_label\">\r\n            <span class=\"dijitReset dijitInline dijitIcon\" data-dojo-attach-point=\"iconNode\"></span>\r\n            <span class=\"epi-marketing-facet-filter-label\">\r\n                <span class=\"dijitReset dijitInline dijitButtonText epi-marketing-facet-filter-label--small dojoxEllipsis\" data-dojo-attach-point=\"containerNode\" id=\"${id}_label\"></span>\r\n                <span class=\"dijitReset dijitInline dijitButtonText epi-marketing-facet-filter-label--large dojoxEllipsis\" data-dojo-attach-point=\"labelValueNode\" id=\"${id}_value\"></span>\r\n            </span>\r\n            <span class=\"dijitReset dijitInline dijitArrowButtonInner\"></span>\r\n            <span class=\"dijitReset dijitInline dijitArrowButtonChar\"></span>\r\n        </span>\r\n    </span>\r\n    <input ${!nameAttrSetting} type=\"${type}\" value=\"${value}\" class=\"dijitOffScreen\" tabIndex=\"-1\" data-dojo-attach-point=\"valueNode\" role=\"presentation\"/>\r\n</span>\r\n"}});
define("epi-ecf-ui/widget/FilterDropDownButton", [
    "dojo/_base/declare",
    "dijit/form/DropDownButton",
    "dijit/popup",
    "dojo/text!./templates/FilterDropDownButton.html"
], function (declare, DropDownButton, popup, template) {

    return declare(DropDownButton, {
        // summary:
        //		A customize dropdown button like axiom
        //
        // tags:
        //      internal product

        // templateString: String
        //      The widget template string.
        templateString: template,

        autoWidth: false,

        _setLabelValueAttr: function(content) {
            this._set("labelValue", content);
            this.labelValueNode.innerHTML = content;
        },
        _onBlur: function() {
            
            // summary:
            //		Called magically when focus has shifted away from this widget and it's dropdown

            // Don't focus on button if the user has explicitly focused on something else (happens
            // when user clicks another control causing the current popup to close)..
            // But if focus is inside of the drop down then reset focus to me, because IE doesn't like
            // it when you display:none a node with focus.
            this._closeDropDown();
        },

        closeDropDown: function () {
            // Overwrite, we only close popup when it losts focus.
        },

        _closeDropDown: function (/*Boolean*/ focus) {
            // summary:
            //		Closes the drop down on this widget
            // focus:
            //		If true, refocuses the button widget
            // tags:
            //		protected

            if (this._focusDropDownTimer) {
                this._focusDropDownTimer.remove();
                delete this._focusDropDownTimer;
            }

            if (this._opened) {
                this._popupStateNode.setAttribute("aria-expanded", "false");
                if (focus) { this.focus(); }
                popup.close(this.dropDown);
                this._opened = false;
            }
        }
    });
});
