define([
    "dojo/_base/declare",
    "dijit/form/CheckBox",
    "epi/shell/form/Field",
    "epi/shell/form/formFieldRegistry"
], function (
    declare,
    CheckBox,
    Field,
    formFieldRegistry
) {
    var factory;

    formFieldRegistry.add({
        type: formFieldRegistry.type.field,
        hint: "bulk-edit",
        factory: function (widget, parent) {
            if (!factory) {
                factory = formFieldRegistry.get(formFieldRegistry.type.field, "");
            }
            var wrapper = factory(widget, parent);

            var checkboxContainer = document.createElement("div");

            wrapper.domNode.prepend(checkboxContainer);

            var checkBox = new CheckBox({
                name: "checkBox-set-active-field",
                checked: false,
                onClick: function () {
                    var isChecked = checkBox.get("value");
                    wrapper.domNode.classList.toggle("field-active", isChecked);
                    widget.set("readOnly", !isChecked);
                    widget.set("disabled", !isChecked);
                    widget.focus();
                }.bind(this)
            }, checkboxContainer);
            checkBox.domNode.classList.add("select-field-checkbox");

            wrapper.own(checkBox);

            widget.set("readOnly", true);
            widget.set("disabled", true);

            //TODO: EDITING remove required property, only when property value is empty
            if (widget.required) {
                delete widget.required;
            }

            return wrapper;
        }
    });
});
