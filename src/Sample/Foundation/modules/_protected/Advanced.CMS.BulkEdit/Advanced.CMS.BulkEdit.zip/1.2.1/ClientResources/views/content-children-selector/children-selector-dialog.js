define([
    "dojo/_base/declare",
    "dojo/Deferred",
    "dojo/on",
    "dojo/when",

    "dijit/_Widget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",

    "epi/dependency",
    "epi/shell/widget/dialog/Dialog",
    "epi-cms/ApplicationSettings",

    "./children-selector-grid",

    // used in template
    "dijit/form/RadioButton",
    "dijit/form/Select"
], function (
    declare,
    Deferred,
    on,
    when,

    _Widget,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,

    dependency,
    Dialog,
    ApplicationSettings,

    ChildrenSelectorGrid
) {
    var template = `<div class="bulk-edit-dialog-content">
    <div data-dojo-attach-point="contentUpdateNotification" class="update-notification"></div>
    <form data-dojo-attach-point="selectionForm">
        <div class="form-field">
            <label>Query type</label>
            <label>
                <input type="radio" data-dojo-type="dijit/form/RadioButton" name="queryType" data-dojo-attach-event="onClick:onQueryTypeChanged" checked value="Children" checked" />
                <span>Children</span></label>
            <label>
            <input type="radio" data-dojo-type="dijit/form/RadioButton" name="queryType" data-dojo-attach-event="onClick:onQueryTypeChanged" value="Descendants"/>
            <span>Descendants</span></label>
        </div>
        <div class="form-field">
            <label>Types:</label>
            <div data-dojo-attach-point="contentTypes" data-dojo-type="dijit/form/Select" name="contentType"  data-dojo-attach-event="onChange:onContentTypeChanged" value="EMPTY"></div>
        </div>
        <div class="form-field">
            <label>Selection</label>
            <input type="radio" data-dojo-type="dijit/form/RadioButton" name="selection" id="selectionAll" data-dojo-attach-event="onClick:onUserSelectionChanged" checked value="All" />
            <label for="selectionAll">All</label>
            <input type="radio" data-dojo-type="dijit/form/RadioButton" name="selection" id="selectionUser" data-dojo-attach-event="onClick:onUserSelectionChanged" value="Selected"/>
            <label for="selectionUser">Selected</label>
        </div>
    </form>
    <div data-dojo-attach-point="gridOverlay" class="grid-overlay"></div>
    <div data-dojo-attach-point="grid"></div>
</div>`;

    class SelectionState {
        constructor() {
            this.selection = [];
        }

        isSelected(contentLink) {
            return this.selection.some(function (content) {
                return content.contentLink === contentLink;
            });
        }

        setSelected(content, isSelected) {
            if (isSelected) {
                this.selection.push(content);
            } else {
                var itemIndex = this.selection.findIndex(function (item) {
                    return item.contentLink === content.contentLink;
                });
                this.selection.splice(itemIndex, 1);
            }
        }

        getSelection() {
            return this.selection;
        }
    }

    var DialogContent = declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin], {
        templateString: template,

        parentContentLink: null,

        buildRendering: function () {
            this.inherited(arguments);
            this.contentTypes.addOption({ value: "EMPTY", label: "Include all types" });

            this._selectionStorage = new SelectionState();
            this._grid = new ChildrenSelectorGrid({
                selectionStorage: this._selectionStorage
            }, this.grid);

            this.own(on(this._grid.grid, "dgrid-refresh-complete", function (e){
                when(e.results.total).then(function (value) {
                    this._lastGridTotalItems = value;
                    this._refreshUpdateItemsMessage();
                }.bind(this));
            }.bind(this)));

            this.own(on(this._grid, "grid-selection-changed", function (){
                this._refreshUpdateItemsMessage();
            }.bind(this)));
        },

        _setParentContentLinkAttr: function (value) {
            this._set("parentContentLink", value);
            this.refreshContentTypes();
        },

        startup: function () {
            if (this._started) {
                return;
            }

            this.inherited(arguments);

            this._grid.startup();

            this._reloadGridData();
        },

        refreshContentTypes: function () {
            var loadDescendants = (new FormData(this.selectionForm)).get("queryType") === "Descendants";

            this.store = this.store || dependency.resolve("epi.storeregistry").get("advanced.cms.bulkEditContent");
            return this.store.query({ parentLink: this.parentContentLink, loadDescendants: loadDescendants }).then(function (result) {
                if (this._contentTypes) {
                    this._contentTypes.forEach(function (item) {
                        this.contentTypes.removeOption(item.value);
                    }, this);
                }

                this._contentTypes = result.map(function (contentType) {
                    return {
                        value: contentType.key.toString(),
                        label: contentType.value
                    }
                });
                this._contentTypes.forEach(function (item) {
                    this.contentTypes.addOption(item);
                }, this);
            }.bind(this));
        },

        onQueryTypeChanged: function () {
            this.refreshContentTypes().then(this._reloadGridData.bind(this));

        },

        onUserSelectionChanged: function () {
            var loadAll = (new FormData(this.selectionForm)).get("selection") === "All";

            this.gridOverlay.classList.toggle("dijitHidden", !loadAll);
            this._refreshUpdateItemsMessage();
        },

        onContentTypeChanged: function () {
            this._reloadGridData();
        },

        getQueryParams: function () {
            var formData = new FormData(this.selectionForm);
            var loadDescendants = formData.get("queryType") === "Descendants";
            var contentTypeId = formData.get("contentType");
            if (contentTypeId === "EMPTY") {
                contentTypeId = undefined;
            }
            var loadAll = formData.get("selection") === "All";

            return {
                loadDescendants: loadDescendants,
                contentTypeId: contentTypeId,
                loadAll: loadAll
            };
        },

        _reloadGridData: function () {
            var queryParams = this.getQueryParams();
            this._grid.fetchData(this.parentContentLink, queryParams.loadDescendants, queryParams.contentTypeId);
        },

        _refreshUpdateItemsMessage: function () {
            var params = this.getQueryParams();
            var itemsCount;
            if (params.loadAll) {
                itemsCount = this._lastGridTotalItems;
            } else {
                itemsCount = this._selectionStorage.getSelection().length;
            }

            this.contentUpdateNotification.innerText = itemsCount + " content items will be updated";

            this.emit("grid-items-count-changed", { itemsCount });

            var showNitificationWarning = itemsCount > ApplicationSettings.bulkEditOptions.maximumSafeContentItemsToUpdate;
            this.contentUpdateNotification.classList.toggle("notification-warning", showNitificationWarning);
        }
    });

    return declare([Dialog], {
        buildRendering: function () {
            this.dialogClass = "bulk-edit-settings-dialog";

            this.inherited(arguments);

            this.title = "Bulk edit";
            this.confirmActionText = "Next";

            var content = new DialogContent();
            this.own(content);

            this.content = content;

            this.own(on(this.content, "grid-items-count-changed", function (data) {
                this.definitionConsumer.setItemProperty(this._okButtonName, "disabled", data.itemsCount > 0 ? "" : "disabled");
            }.bind(this)));
        },

        show: function () {
            this.inherited(arguments);

            this.content._grid.layout();
            this.content._grid.resize();
        },

        _getSelectedContents: function (parentContentLink, selectionForm) {
            var result = new Deferred();

            var queryParams = this.content.getQueryParams();

            // only values selected in grid
            if (queryParams.loadAll === false) {
                return result.resolve(this.content._selectionStorage.getSelection());
            }

            var registry = dependency.resolve("epi.storeregistry");
            store = registry.get("advanced.cms.bulkEditContent");
            var query = {
                loadContents: true,
                parentLink: parentContentLink,
                loadDescendants: queryParams.loadDescendants
            };

            if (queryParams.contentTypeId) {
                query.contentTypeId = queryParams.contentTypeId;
            }
            store.query(query).then(function (items) {
                result.resolve(items);
            });

            return result.promise;
        },

        /**
         * Deferred function that returns list of selected children
         * @param {any} parentContentLink
         */
        selectContentLinks: function (parentContentLink) {
            var result = new Deferred();

            this.content.set("parentContentLink", parentContentLink);

            var isOkClicked = false;
            this.own(on.once(this, "execute", function () {
                isOkClicked = true;
                this._getSelectedContents(parentContentLink).then(function (contentIds) {
                    result.resolve(contentIds);
                });
            }.bind(this)));

            this.own(on(this, "hide", function () {
                if (!isOkClicked) {
                    result.resolve(null);
                }
            }.bind(this)))

            this.show();
            return result.promise;
        }
    });
});

//TODO: EDITING allow to publish from dialog

//TODO: EDITING do not update when item did not changed

//TODO: Add CSV export

//TODO: EDITING export all values to excel

//TODO: EDITING check styles for grid selection

//TODO: EDITING issue with virtual scroll for many items

//TODO: EDITING update from excel

//TODO: EDITING add resources
