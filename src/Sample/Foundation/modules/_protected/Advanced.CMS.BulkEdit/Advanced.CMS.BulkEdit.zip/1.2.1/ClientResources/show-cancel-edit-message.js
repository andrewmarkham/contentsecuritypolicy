define([
    "epi/shell/widget/dialog/Alert"
], function (
    Alert
) {
    return function showCancelEditMessage(lastProgressStatus) {
        var dialog = new Alert({
            content: `<div>Editing cancelled. Updated ${lastProgressStatus.updatedCount} from ${lastProgressStatus.totalCount} content items.</div>`
        });
        dialog.show();
    }   
});
