define([
    "dojo/_base/declare",
    "dijit/Destroyable",
    "epi/shell/command/_Command",
    "advanced-cms-bulk-edit/views/content-children-selector/children-selector-dialog",
    "epi-cms/contentediting/DialogPositionAdjust",
    "advanced-cms-bulk-edit/show-bulk-edit-dialog",
    "epi/i18n!epi/cms/nls/bulkediting.contentreecommand"
], function (
    declare,
    Destroyable,
    _Command,
    ChildrenSelectorDialog,
    DialogPositionAdjust,
    showBulkEditDialog,
    res
) {
    return declare([_Command, Destroyable], {
        label: res.label,

        iconClass: "epi-iconForms",

        postscript: function () {
            this.inherited(arguments);

            this._dialogPositionAdjust = new DialogPositionAdjust();
            this.own(this._dialogPositionAdjust);
        },

        _execute: function () {
            var dialog = new ChildrenSelectorDialog();
            dialog.selectContentLinks(this._getParentContentLink()).then(function (contents) {
                if (contents) {
                    showBulkEditDialog(this._dialogPositionAdjust, contents).then(function () {

                    }.bind(this));
                }
            }.bind(this));
        },

        _getParentContentLink: function () {
            return this.model.contentLink;
        },

        _onModelChange: function () {
            this.inherited(arguments);

            if (this.model === null) {
                this.set("canExecute", false);
                this.set("isAvailable", false);
                return;
            }

            this.set("isAvailable", this.model.hasChildren);
            this.set("canExecute", this.model.hasChildren);
        }
    });
});
