define([
    "dojo/_base/declare",
    "dijit/Destroyable",
    "epi/dependency",
    "epi/shell/command/_Command",
    "epi-cms/contentediting/DialogPositionAdjust",
    "advanced-cms-bulk-edit/show-bulk-edit-dialog",
], function (
    declare,
    Destroyable,
    dependency,
    _Command,
    DialogPositionAdjust,
    showBulkEditDialog,
) {
    return declare([_Command, Destroyable], {
        label: "Bulk edit",

        category: "publishmenu",

        iconClass: "epi-iconForms",

        postscript: function () {
            this.inherited(arguments);

            this.projectService = this.projectService || dependency.resolve("epi.cms.ProjectService");
            this.projectItemStore = this.projectItemStore || dependency.resolve("epi.storeregistry").get("epi.cms.project.item");

            this.set("isAvailable", true);
            this.set("canExecute", true);

            this._dialogPositionAdjust = new DialogPositionAdjust();
            this.own(this._dialogPositionAdjust);
        },

        _execute: function () {
            this.projectService.getCurrentProject().then(function (project) {
                if (project) {
                    this.projectItemStore.query({ projectId: project.id }).then(function (items) {
                        showBulkEditDialog(this._dialogPositionAdjust, items).then(function () {

                        }.bind(this));
                    }.bind(this));
                }
            }.bind(this));
        }
    });
});
