define([
    "dojo/_base/declare",

    "dijit/_Widget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/ProgressBar",

    "epi/shell/widget/dialog/Dialog",

    "advanced-cms-bulk-edit/views/bulk-edit-progress"
], function (
    declare,

    _Widget,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
    ProgressBar,

    Dialog,
    BulkEditProgress
) {
    /*var ContentStatus = declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin], {
        templateString: `<div class="update-content-item">
        <a data-dojo-attach-point="contentNameEl" target="_blank" class="content-name"></a>
        <span data-dojo-attach-point="statusOk" class="dijitReset dijitInline dijitArrowButtonInner" title="Content updated" ></span>
        <div data-dojo-attach-point="errorText" class="error-message dijitHidden"></div>
</div>`,

        _setContentNameAttr: function (value) {
            this.contentNameEl.innerText = value;
        },

        _setUriAttr: function (value) {
            var url = new URL(window.location);
            url.hash = "context=" + value;
            this.contentNameEl.href = url;
        },

        _setErrorsAttr: function (value) {
            if (value && value.length > 0) {
                this.statusOk.classList.add("dijitHidden");
                this.errorText.classList.remove("dijitHidden");
                this.errorText.innerText = value.map(function (x) {
                    return x.errorMessage;
                }).join(", ");

                this.domNode.classList.add("update-error");
            }
        }
    });


    var template = `<div>
    
    <div data-dojo-attach-point="progressBarContainer" class="progress-bar-container">
        <div data-dojo-type="dijit/ProgressBar" data-dojo-attach-point="progressBar"></div>
    </div>
    <h3 data-dojo-attach-point="updatedStatusInfo" class="updated-status-info dijitHidden">Items update complete</h3>
    <ul data-dojo-attach-point="updatedItemsList" class="updated-items-list"></ul>
</div>`;

    var DialogContent = declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin], {
        templateString: template,

        updateProgress: function (updatedCount, totalCount, content) {
            if (!this.progressBar) {
                return;
            }
            if (updatedCount === totalCount) {
                this.progressBarContainer.classList.add("dijitHidden");
                this.updatedStatusInfo.classList.remove("dijitHidden");
            } else {
                this.progressBar.set("maximum", totalCount);
                this.progressBar.set("value", updatedCount);
            }

            this._addContentStatus(content);            
        },

        _addContentStatus: function (contentStatus) {
            var li = document.createElement("li");
            this.updatedItemsList.appendChild(li);
            var div = document.createElement("div");
            li.appendChild(div);

            var contentStatusWidget = new ContentStatus({
                contentName: contentStatus.name,
                errors: contentStatus.errors,
                uri: contentStatus.uri
            }, div);
            this.own(contentStatusWidget);
        }
    });*/

    return declare([Dialog], {
        buildRendering: function () {
            this.closeIconVisible = false;
            this.dialogClass = "bulk-edit-progress-dialog";
            this.defaultActionsVisible = false;

            this.inherited(arguments);

            this.title = "Updating content";

            this.updateProgressWidget = new BulkEditProgress();
            this.own(this.updateProgressWidget);

            this.content = this.updateProgressWidget;
        },

        getActions: function () {
            var buttons = this.inherited(arguments);

            var okButton = {
                name: this._okButtonName,
                label: "Cancel",
                title: null,
                settings: { type: "submit" }
            };
            okButton.settings["class"] = "Salt";
            buttons.push(okButton);

            return buttons;
        },

        updateProgress: function (updatedCount, totalCount, contentStatus) {
            this.updateProgressWidget.updateProgress(updatedCount, totalCount, contentStatus);

            if (updatedCount === totalCount) {
                this.definitionConsumer.setItemProperty(this._okButtonName, "label", "Close");
            }
        }
    });
});
