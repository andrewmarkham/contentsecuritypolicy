define([
    "dojo/_base/declare",
    "epi/shell/MetadataTransformer",
    "epi-cms/contentediting/inline-editing/BlockEditFormContainer",
    "./form-field"
], function (
    declare,
    MetadataTransformer,
    BlockEditFormContainer,
    FormField
) {
    //
    //  Metadata transformer with overriden "hint" value
    //
    var BulkEditMetadataTransformer = declare([MetadataTransformer], {
        transformPropertySettings: function () {
            var editor = this.inherited(arguments);

            editor.settings._hint = "bulk-edit";

            return editor;
        }
    });

    //
    //  Custom FormContainer with different MetadataTransformer and CSS class name
    //
    return declare([BlockEditFormContainer], {
        isInlineCreateEnabled: true,

        postCreate: function () {
            this.inherited(arguments);

            this.domNode.classList.add("bulk-edit-form");
        },

        _setupUI: function () {
            this.metadataTransformer = new BulkEditMetadataTransformer({ propertyFilter: this.propertyFilter })

            this.inherited(arguments);
        }
    });
});
