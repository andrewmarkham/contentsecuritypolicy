define([
    "dojo/_base/declare",

    "epi/_Module",
    "epi/dependency",
    "epi/routes",

    "epi/shell/store/JsonRest",
    "epi-cms/plugin-area/navigation-tree",
    "epi-cms/plugin-area/project-overview",
    "epi-cms/plugin-area/assets-pane",
    "epi-cms/ApplicationSettings",
    "advanced-cms-bulk-edit/commands/bulk-edit-command",
    "advanced-cms-bulk-edit/commands/project-bulk-edit-command",
    "advanced-cms-bulk-edit/commands/assets-bulk-edit-command",

    "xstyle/css!./bulk-edit.css"
], function (
    declare,

    _Module,
    dependency,
    routes,

    JsonRest,
    pluginArea,
    projectOverviewPluginArea,
    assetsPanePluginArea,
    ApplicationSettings,
    BulkEditCommand,
    ProjectBulkEditCommand,
    AssetsBulkEditCommand
) {
    function initializeStore() {
        var registry = dependency.resolve("epi.storeregistry");
        registry.add("advanced.cms.bulkEditContent",
            new JsonRest({
                target: routes.getRestPath({ moduleArea: "advanced.cms.bulkedit", storeName: "bulkEditContent" })
            })
        );
    }

    return declare([_Module], {
        initialize: function () {
            if (this._settings.bulkEdit.pageTreeCommandEnabled) {
                pluginArea.add(BulkEditCommand);
            }

            if (this._settings.bulkEdit.assetsPaneCommandEnabled) {
                assetsPanePluginArea.add(AssetsBulkEditCommand);
            }

            if (this._settings.bulkEdit.projectCommandEnabled) {
                projectOverviewPluginArea.add(ProjectBulkEditCommand);
            }

            ApplicationSettings.bulkEditOptions = this._settings.bulkEdit;

            initializeStore();
        }
    });
});
