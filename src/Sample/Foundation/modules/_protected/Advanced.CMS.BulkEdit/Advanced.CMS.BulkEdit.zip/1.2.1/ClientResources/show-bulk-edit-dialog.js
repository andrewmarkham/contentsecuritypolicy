define([
    "dojo/Deferred",
    "dojo/on",
    "epi/shell/command/_Command",
    "epi-cms/contentediting/inline-editing/InlineEditBlockDialog",
    "./bulk-edit-form-container",
    "./metadata-intersection-loader",
    "./form-changes-loader",
    "./form-save",
    "./views/content-update-dialog",
    "./initial-values-loader",
    "./show-cancel-edit-message"
], function (
    Deferred,
    on,
    _Command,
    InlineEditBlockDialog,
    BulkEditFormContainer,
    metadataIntersectionLoader,
    formChangesLoader,
    formSave,
    ContentUpdateDialog,
    initialValuesLoader,
    showCancelEditMessage
 ) {
        function toggleMainButtonEnabled (dialog, enabled) {
            dialog.definitionConsumer.setItemProperty(dialog._okButtonName, "disabled", enabled ? "" : "disabled");
        };

        return function (dialogPositionAdjust, selectedContent) {
            var result = new Deferred();

            var dialog = new InlineEditBlockDialog({
                title: "Bulk edit",
                mainCommand: null,
                suppressOverlayAdjustments: false,
                confirmActionText: "Update",
                saveLabel: "Update properties"
            });

            var form = new BulkEditFormContainer({}, dialog.content, "last");

            dialog.own(on(form, "isDirty", function () {
                var value = form.get("value");
                var activeFieldCheckbox = value["checkBox-set-active-field"];
                toggleMainButtonEnabled(dialog, activeFieldCheckbox && activeFieldCheckbox.length > 0);
            }));

            metadataIntersectionLoader(selectedContent).then(function (metadata) {
                initialValuesLoader(selectedContent[0].contentLink, metadata).then(function (metadata) {
                    var initialFormValues;
                    dialog.own(on(form, "FormCreated", function () {
                        initialFormValues = form.get("value");
                    }.bind(this)));
                    form.set("metadata", metadata);

                    dialog.own(on.once(dialog, "execute", function () {
                        var changedProperties = formChangesLoader(initialFormValues, form);
                        var updateDialog = new ContentUpdateDialog();
                        updateDialog.show();

                        var lastProgressState;
                        function upadateProgress(progressState) {
                            lastProgressState = progressState;

                            if (updateDialog._destroyed) {
                                progressState.cancel = true;
                                return;
                            }
                            updateDialog.updateProgress(progressState.updatedCount, progressState.totalCount, progressState.contentStatus);
                        }

                        formSave(selectedContent, changedProperties, upadateProgress).then(function () {
                            if (lastProgressState && lastProgressState.cancel) {
                                showCancelEditMessage(lastProgressState);
                            }
                        });

                        result.resolve(true);
                    }.bind(this)));

                    dialog.own(on(dialog, "hide", function () {
                        dialogPositionAdjust.cleanup();
                        if (!result.isResolved()) {
                            result.resolve(false);
                        }
                    }.bind(this)));

                    dialog.show();

                    toggleMainButtonEnabled(dialog, false);

                    dialogPositionAdjust.adjustDialogPosition(dialog);
                }.bind(this));
            }.bind(this));

            return result.promise;
        }
    });
