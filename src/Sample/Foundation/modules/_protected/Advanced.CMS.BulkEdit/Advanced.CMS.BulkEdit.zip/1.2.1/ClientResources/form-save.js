/**
 * Save list of contents and returns updatePRogress for each item
 */
define([
    "dojo/Deferred",
    "epi/dependency",
    "epi/UriParser",
    "epi-cms/contentediting/ContentViewModel"
], function (
    Deferred,
    dependency,
    UriParser,
    ContentViewModel
) {
    function saveContent(properties, contentItem) {
        var result = new Deferred();

        var registry = dependency.resolve("epi.storeregistry");
        var enhancedStore = registry.get("epi.cms.latestcontentversion");
        var contextStore = registry.get("epi.shell.context");

        enhancedStore.query({ id: contentItem.contentLink, keepVersion: true }).then(function (latestContent) {
            contextStore.query({ uri: "epi.cms.contentdata:///" + latestContent.contentLink }).then(function (context) {
                var uri = new UriParser(context.uri);

                var model = new ContentViewModel({
                    contentLink: uri.getId(),
                    enableAutoSave: false,
                    isInQuickEditMode: true
                });

                //TODO: EDITING handle scenario when content should not be saved

                model.onContentLinkChange = function () { };
                model.reload(true).then(function () {
                    Object.keys(properties).forEach(function (propertyName) {
                        model.setProperty(propertyName, properties[propertyName]);
                        model.save().then(function () {
                            result.resolve({
                                name: latestContent.name,
                                errors: model.validationErrors,
                                url: latestContent.uri,
                                success: (model.validationErrors || []).length === 0
                            });
                        });
                    });
                });
            });
        });

        return result.promise;
    }

    function updateContents(contentItems, properties, onProgressUpdated, currentUpdateIndex, promise) {
        saveContent(properties, contentItems[currentUpdateIndex]).then(function (contentStatus) {
            currentUpdateIndex++;
            var progressState = {
                updatedCount: currentUpdateIndex,
                totalCount: contentItems.length,
                contentStatus,
                cancel: false
            };
            onProgressUpdated(progressState);

            if (progressState.cancel) {
                promise.resolve();
                return;
            }

            if (currentUpdateIndex < contentItems.length) {
                updateContents(contentItems, properties, onProgressUpdated, currentUpdateIndex, promise);
            } else {
                promise.resolve();
            }
        })
    }

    return function (contentItems, properties, onProgressUpdated) {
        var result = new Deferred();

        updateContents(contentItems, properties, onProgressUpdated, 0, result);

        return result.promise;
    };
});
