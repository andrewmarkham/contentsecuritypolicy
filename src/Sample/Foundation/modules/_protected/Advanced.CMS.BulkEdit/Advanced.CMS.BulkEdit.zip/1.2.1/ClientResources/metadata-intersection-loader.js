define([
    "dojo/Deferred",
    "dojo/promise/all",
    "epi/dependency"
], function (
    Deferred,
    all,
    dependency   
) {
    //
    //    Loading form metadata from list of ContentLinks
    //    Calculates intersection of all fields and remove system fields like "Name", "Name in URL"
    //

    function _compareProperties (prop1, prop2) {
        var cleanProp1 = _cleanProperty(prop1);
        var cleanProp2 = _cleanProperty(prop2);

        return cleanProp1 === cleanProp2;
    }

    /**
     * Remove all settings that should not be compared
     * @param {any} prop
     */
    function _cleanProperty (prop) {
        prop = Object.assign({}, prop);
        if (prop.hasOwnProperty("initialValue")) {
            delete prop.initialValue;
        }
        if (prop.hasOwnProperty("displayOrder")) {
            delete prop.displayOrder;
        }

        return JSON.stringify(prop);
    }

    function _deletePropertyByName (metadata, propertiesNameToRemove) {
        propertiesNameToRemove.forEach(function (property) {
            var index = metadata.properties.findIndex(function (p) {
                return p.name === property;
            });
            if (index !== -1) {
                metadata.properties.splice(index, 1);
            }
        });
    }

    /**
     * Remove all system properties that should not be editied using bulk edit
     * @param {any} metadata
     */
    function _removeSystemProperties(metadata) {
        var systemProperties = ["icontent_name", "icontent_contentlink", "iroutable_routesegment", "PageExternalURL"];
        _deletePropertyByName(metadata, systemProperties);
    }

    /**
     * Function that filter out all ReadOnly properties
     * @param {any} metadata
     */
    function _removeReadOnlyProperties(metadata) {
        var readOnlyProperties = metadata.properties
            .filter(function (property) { return property.settings.readOnly })
            .map(function (property) { return property.name });
        _deletePropertyByName(metadata, readOnlyProperties);
    }

    /**
     * Function that filter out all properties that has AllowBulkEdit
     * attribute with edit set to false
     * @param {any} metadata
     */
    function _removePropertiesNotSupportedByAttribute(metadata) {
        var notSupportedProperties = metadata.properties.filter(function (property) {
            return property.settings.allowBulkEdit === false;
        }).map(function (property) {
            return property.name;
        });
        _deletePropertyByName(metadata, notSupportedProperties);
    }

    function _buildMetadata(metadataList) {
        var metadata = Object.assign({}, metadataList[0]);
        _removeReadOnlyProperties(metadata);
        _removeSystemProperties(metadata);
        _removePropertiesNotSupportedByAttribute(metadata);

        metadata.properties.forEach(function (prop) {
            prop.initialValue = null;
        });

        if (metadataList.length === 1) {
            return metadata;
        }

        for (var i = 1; i < metadataList.length; i++) {
            var anotherMetadata = Object.assign({}, metadataList[i]);
            _removePropertiesNotSupportedByAttribute(metadata);

            var propertiesToRemove = [];
            metadata.properties.forEach(function (property) {
                var matchProperty = anotherMetadata.properties.find(function (p) {
                    return p.name === property.name;
                })
                if (!matchProperty) {
                    propertiesToRemove.push(property.name);
                    return;
                }
                if (!_compareProperties(matchProperty, property)) {
                    propertiesToRemove.push(property.name);
                    return;
                }
            });

            _deletePropertyByName(metadata, propertiesToRemove);
        }

        return metadata;
    }

    function _getDistinctContentLinks(selectedContent) {
        var contentLinks = [];
        var typeIdentifiers = [];

        selectedContent.forEach(function (x) {
            if (typeIdentifiers.indexOf(x.typeIdentifier) === -1) {
                contentLinks.push(x.contentLink);
                typeIdentifiers.push(x.typeIdentifier);
            }
        });

        return contentLinks;
    }

    var metadataManager;
    return function (selectedContentLinks) {
        var result = new Deferred();

        metadataManager = metadataManager || dependency.resolve("epi.shell.MetadataManager");
        var contentLinks = _getDistinctContentLinks(selectedContentLinks);

        var metadataPromises = [];
        contentLinks.forEach(function (contentLink) {
            var promise = metadataManager.getMetadataForType("EPiServer.Core.ContentData", { contentLink: contentLink });
            metadataPromises.push(promise);
        });

        all(metadataPromises).then(function (metadataList) {
            var metadata = _buildMetadata(metadataList);
            metadata.customEditorSettings.inlineBlock.showCategoryProperty = true;
            result.resolve(metadata);
        });

        return result.promise;
    };
});
