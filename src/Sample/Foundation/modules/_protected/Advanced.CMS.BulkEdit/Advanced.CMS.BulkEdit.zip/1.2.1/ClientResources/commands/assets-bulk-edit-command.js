define([
    "dojo/_base/declare",
    "advanced-cms-bulk-edit/commands/bulk-edit-command"
], function (
    declare,
    BulkEditCommand
) {
    return declare([BulkEditCommand], {
        _getParentContentLink: function () {
            return this.model[0].contentLink;
        },

        _onModelChange: function () {
            this.inherited(arguments);

            if (this.get("canExecute")) {
                return;
            }

            if (Array.isArray(this.model) && this.model.length === 1) {
                var model = this.model[0];
                var isFolder = model.typeIdentifier === "episerver.core.contentfolder" ||
                    model.typeIdentifier === "episerver.core.contentassetfolder";
                this.set("isAvailable", isFolder);
                this.set("canExecute", isFolder);
            }
        }
    });
});
