define([], function () {
    function getValueToCompare(object) {
        if (!object) {
            return object;
        }
        return JSON.stringify(object);
    }

    return function (initialFormValues, form) {
        var formValue = form.get("value");
        delete formValue["checkBox-set-active-field"];

        var valuesToUpdate = {};
        Object.keys(formValue).forEach(function (propertyName) {
            var initialValue = getValueToCompare(initialFormValues[propertyName]);
            var value = getValueToCompare(formValue[propertyName]);

            if (initialValue !== value) {
                valuesToUpdate[propertyName] = formValue[propertyName];
            }
        });

        return valuesToUpdate;
    };
});
