define([
    "dojo/Deferred",
    "dojo/when",
    "epi/dependency"
], function (
    Deferred,
    when,
    dependency   
) {   
    //
    //    Set form initial values from specified content link
    //

    function findPropertyName(contentData, propertyName) {
        propertyName = propertyName.toLowerCase();

        return Object.keys(contentData.properties).find(function (propertyKey) {
            return propertyKey.toLowerCase() === propertyName;
        });
    }

    var registry;
    var contentDataStore;
    var enhancedStore;
    return function (contentLink, metadata) {
        var result = new Deferred();

        //TODO: EDITING add option to not load the initial data

        registry = registry || dependency.resolve("epi.storeregistry")
        enhancedStore = enhancedStore || registry.get("epi.cms.latestcontentversion");
        contentDataStore = contentDataStore || registry.get("epi.cms.contentdata");
        when(enhancedStore.get(contentLink)).then(function (content) {
            when(contentDataStore.get(content.contentLink)).then(function (contentData) {
                metadata.properties.forEach(function (property) {
                    var propertyName = findPropertyName(contentData, property.name);
                    if (propertyName) {
                        property.initialValue = contentData.properties[propertyName];
                    }
                });
                result.resolve(metadata);
            });
        });

        return result.promise;
    };
});
