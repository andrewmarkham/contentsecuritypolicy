define([
    "dojo/_base/declare",

    "dijit/form/CheckBox",

    "dgrid/OnDemandGrid",
    "dgrid/Selection",

    "epi-cms/widget/_GridWidgetBase"
], function (
    declare,

    CheckBox,

    OnDemandGrid,
    Selection,

    _GridWidgetBase
) {
    return declare([_GridWidgetBase], {
        postMixInProperties: function () {
            this.storeKeyName = "advanced.cms.bulkEditContent";
            this.ignoreVersionWhenComparingLinks = false;
            this.forceContextReload = true;
            this.contextChangeEvent = "";

            this.inherited(arguments);
        },

        buildRendering: function () {
            this.inherited(arguments);

            var self = this;

            this.domNode.classList.add("form-content-list");

            var customGridClass = declare([OnDemandGrid, Selection]);
            this.grid = new customGridClass({
                columns: {
                    selection: {
                        label: " ",
                        className: "selection-column",
                        renderCell: function (object, value, node, options) {
                            var elem = document.createElement("div");
                            node.appendChild(elem);

                            var checkBox = new CheckBox({
                                name: "checkBox",
                                checked: self.selectionStorage.isSelected(object.contentLink),
                                onClick: function () {
                                    self.selectionStorage.setSelected(object, this.get("value"));
                                    self.emit("grid-selection-changed");
                                }
                            }, elem);
                            self.own(checkBox);
                        }
                    },
                    name: {
                        label: "Name"
                    },
                    language: {
                        label: "Language",
                        className: "selection-column",
                    },
                    contentTypeName: {
                        label: "Content type"
                    }
                },
                selectionMode: "single",
                selectionEvents: "click,dgrid-cellfocusin",
                sort: [{ attribute: "savedDate", descending: true }]
            }, this.domNode);
        },

        fetchData: function (parentLink, loadDescendants, contentTypeId) {
            var query = {
                loadContents: true,
                parentLink: parentLink,
                loadDescendants: loadDescendants
            };

            if (contentTypeId) {
                query.contentTypeId = contentTypeId;
            }

            this.grid.set("query", query);

            if (!this.grid.store) {
                this.grid.set("store", this.store);
            }
        }
    });
});
