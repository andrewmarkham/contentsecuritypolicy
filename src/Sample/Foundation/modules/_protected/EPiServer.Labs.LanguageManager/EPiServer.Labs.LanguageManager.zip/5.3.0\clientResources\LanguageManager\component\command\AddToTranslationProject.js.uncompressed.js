﻿define("epi-languagemanager/component/command/AddToTranslationProject", [
// dojo
    "dojo/_base/declare",
    "dojo/Deferred",
    "dojo/when",
    // epi
    "epi/shell/widget/dialog/Dialog",
    "epi-cms/core/ContentReference",
    "epi-cms/project/CreateNewDraftConfirmationDialog",
    "epi/dependency",
    // add-ons
    "epi-languagemanager/component/command/CommandBase",
    "epi-languagemanager/widget/AddToTranslationOptions",
    // resource
    "epi/i18n!epi/cms/nls/languagemanager"
],

function (
// dojo
    declare,
    Deferred,
    when,
    // epi
    Dialog,
    ContentReference,
    CreateNewDraftConfirmationDialog,
    dependency,
    // add-ons
    CommandBase,
    AddToTranslationOptions,
    // resource
    res
) {

    return declare([CommandBase], {

        // label: [public] String
        //      The action text of the command to be used in visual elements.
        label: res.gadget.addtotranslationproject,

        category: "context",

        // projectStore: [readonly] Store
        //      A REST store for interacting with projects.
        projectStore: null,

        constructor: function (params) {
            this.inherited(arguments);
            this.set("isAvailable", true);
            this.set("canExecute", true);
        },

        _onModelChange: function () {
            // summary:
            //      Updates canExecute and isAvailable after the model has been updated.
            // tags:
            //      protected

            var item = this.model.currentItemData;
            if (!item) {
                this.set("canExecute", false);
                this.set("isAvailable", false);
                return;
            }

            var commandAvailable = item.canActivate && item.canEdit && item.isActive;

            when(this.model.hasAnyProject()).then(function (hasProject) {
                this.set("canExecute", commandAvailable && item.isCreated && hasProject);
                this.set("isAvailable", commandAvailable);
            }.bind(this));
        },

        _execute: function () {
            // summary:
            //      Send to translation project.
            // tags:
            //      protected

            var addToTranslationOptions = new AddToTranslationOptions(),
                projectSelector = addToTranslationOptions.projectSelector,
                projectStore = this.projectStore || dependency.resolve("epi.storeregistry").get("epi.cms.project");

            projectSelector.set("store", projectStore);

            this._sendToProjectDialog = new Dialog({
                destroyOnHide: true,
                dialogClass: "epi-dialog-confirm",
                title: res.addtoproject.heading,
                description: res.addtoproject.description,
                content: addToTranslationOptions
            });

            projectSelector.watch("value", this._projectSelectorValueChanged.bind(this));

            this._sendToProjectDialog.on("execute", this._onDialogExecute.bind(this));

            this._sendToProjectDialog.show();

            this._setOkButtonEnabled(false);
        },

        _onDialogExecute: function () {
            // summary:
            //      Performs send to translation process when dialog's "execute" even fired
            // tags:
            //      private

            if (!this._sendToProjectDialog || !this._sendToProjectDialog.content) {
                return;
            }

            var def = new Deferred(),
                currentItemData = this.model.currentItemData;
            if (!this.model.currentItemData.isCreated) {
                when(this.model.duplicateContent()).then(function () {
                    def.resolve();
                }.bind(this));
            } else {
                def.resolve();
            }

            when(def).then(function () {
                var dialogContent = this._sendToProjectDialog.content,
                    projectSelector = dialogContent.projectSelector;
                if (projectSelector) {
                    var selectedProject = dialogContent.projectSelector.get("value");
                    if (selectedProject && selectedProject.id) {
                        var targetProject = selectedProject.id,
                            model = this.model;

                        //Callback method to execute when the canAddContent promise gets resolved
                        var addContent = function (result) {
                            if (result.existingProjectItems.length !== 0) {
                                var dialog = new CreateNewDraftConfirmationDialog({
                                    projectItems: result.existingProjectItems,
                                    contentReferences: result.contentReferences,
                                    onAction: function (dialogResult) {
                                        if (dialogResult) {
                                            model.addProjectItems(targetProject, result.contentReferencesToAdd, currentItemData.languageID);
                                        }
                                    }
                                });

                                dialog.show();

                            } else if (result.contentReferencesToAdd.length > 0) {
                                model.addProjectItems(targetProject, result.contentReferencesToAdd, currentItemData.languageID);
                            }
                        };

                        // 1. Get all content need to translate
                        //      - Checked all children option: Get all descendents of the content
                        //      - Checked related blocks option: Get reference to related blocks of the content (Content Area, Main Area, ...)
                        // 2. Validate the contents can be add/not.
                        //      - Display dialog to show list content has existed in other project
                        return when(model.getContentsToProject(targetProject,
                            dialogContent.addAllChildrenOption && dialogContent.addAllChildrenOption.checked,
                            dialogContent.addRelatedBlocksOption && dialogContent.addRelatedBlocksOption.checked)
                        ).then(function (contentReferences) {

                            var ids = contentReferences.map(function (item) {
                                var reference = ContentReference(item);
                                // TECH NOTE: we DONT know the version of current content when user add content to project from LM context menu,
                                // so that we send content ID and LanguageId, the ProjectStore will add the draff version of that language.
                                reference.workId = 0;

                                return reference.toString();
                            });

                            model.canAddContent(targetProject, ids).then(addContent);
                        });
                    }
                }
            }.bind(this));
        },

        _projectSelectorValueChanged: function (/*String*/propertyName, /*Object*/oldValue, /*Object*/newValue) {
            // summary:
            //      Watchs any change of the Project Selector widget.
            //      If a project selected from list, the "OK" button will be active.
            // propertyName: [String]
            //      The property that watching
            // oldValue: [Object]
            //      The previous selection data
            // newValue: [Object]
            //      The new selection data
            // tags:
            //      private

            if (!newValue) {
                return;
            }
            this._setOkButtonEnabled(true);

            var projectId = newValue.id,
                contentReference = this.model.contentData.contentLink,
                languageId = this.model.currentItemData.languageID;
            when(this.model.isContentExistingInProject(projectId, contentReference, languageId)).then(function (/*Boolean*/existing) {
                this._toggleNotification(existing);
            }.bind(this));
        },

        _toggleNotification: function (/*Boolean*/visible) {
            // summary:
            //      Toggle display of the notification bar.
            // visible: [Boolean]
            //      Flag indicate that the notification bar should display or not.
            // tags:
            //      private

            var dialogContent = this._sendToProjectDialog.content;
            if (dialogContent) {
                if (visible) {
                    (typeof dialogContent.showNotification === "function") && dialogContent.showNotification(res.addtoproject.notification.existingcontent);
                } else {
                    (typeof dialogContent.hideNotification === "function") && dialogContent.hideNotification();
                }
            }
        },

        _setOkButtonEnabled: function (enabled) {
            this._sendToProjectDialog.definitionConsumer.setItemProperty(this._sendToProjectDialog._okButtonName, "disabled", !enabled);
        }
    });

});
