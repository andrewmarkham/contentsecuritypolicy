﻿define("epi-languagemanager/component/viewmodel/UploadTranslationPackagesViewModel", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/Stateful",

    // epi
    "epi/dependency",
    "epi/routes",
    "epi/shell/widget/dialog/Dialog",
    "epi-cms/widget/MultipleFileUpload",
    "epi-cms/widget/viewmodel/MultipleFileUploadViewModel",

    // resources
    "epi/i18n!epi/cms/nls/languagemanager.gadget"
],
function (
// dojo
    declare,
    lang,
    Stateful,
    // epi
    dependency,
    routes,
    Dialog,
    MultipleFileUpload,
    MultipleFileUploadViewModel,

    // resources
    res
) {

    return declare([Stateful], {
        // resources
        res: res,

        postscript: function () {
            // summary:
            //      Initialize for upload
            // tags:
            //      public, extensions

            this.inherited(arguments);
        },

        uploadTranslationPackages: function (/*Array*/fileCollection) {
            // summary:
            //      Uploads translation package(s) to an indicated folder on server
            // fileCollection: [Array]
            //      List files to upload.
            //      When null, only show upload form to select files for uploading.
            //      Otherwise, upload files in list.
            // tags:
            //      public

            // Only create diaglog if it is not available, otherwise, re-use it.
            var uploader = new MultipleFileUpload({
                model: new MultipleFileUploadViewModel()
            });

            // Set the action path for upload form
            uploader.uploaderInput.uploadUrl = routes.getActionPath({
                moduleArea: "EPiServer.Labs.LanguageManager",
                controller: "TranslationPackageUpload",
                action: "Upload"
            });

            uploader.on("beforeUploaderChange", lang.hitch(this, function () {
                this._uploading = true;
            }));

            // Close multiple files upload dialog when stop uploading
            uploader.on("close", lang.hitch(this, function (uploading) {
                this._dialog && (uploading ? this._dialog.hide() : this._dialog.destroy());
            }));

            uploader.on("uploadComplete", lang.hitch(this, function (/*Array*/uploadFiles) {
                if (this._dialog && !this._dialog.open) {
                    this._dialog.destroy();
                }

                this._uploading = false;
            }));

            this._dialog = new Dialog({
                title: this.res.uploadtranslationpackages,
                dialogClass: "epi-dialog-upload",
                content: uploader,
                autofocus: true,
                defaultActionsVisible: false,
                closeIconVisible: false
            });

            // Only show close button for multiple files upload dialog
            this._dialog.definitionConsumer.add({
                name: "close",
                label: epi.resources.action.close, /* eslint-disable-line */
                action: function () {
                    uploader.close();
                }
            });

            this._dialog.resize({ w: 700 });
            this._dialog.show();

            uploader.upload(fileCollection);
        }
    });
});
