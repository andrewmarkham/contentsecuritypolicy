﻿define("epi-languagemanager/component/viewmodel/LanguageManagerViewModelWrapper", [
    // dojo
    "dojo/_base/lang",
    "dojo/_base/array",

    "dojo/aspect",
    "dojo/Deferred",
    "dojo/when",

    "epi/dependency",
    "epi/shell/widget/dialog/Dialog",

    "epi-languagemanager/widget/SourceLanguageOptions",
    // resource
    "epi/i18n!epi/cms/nls/languagemanager"
],
function (
    // dojo
    lang,
    array,

    aspect,
    Deferred,
    when,

    dependency,
    Dialog,

    SourceLanguageOptions,
    // resource
    res
) {
    return function (model) {
        var showSourceLanguageSelectorDialog = function (title, confirmationMessage) {
            var deferred = new Deferred();
            var registry = dependency.resolve("epi.storeregistry"),
                lmStore = registry.get("epi-languagemanager.language-manager");

            when(lmStore.query({ contentLink: model.contentData.contentLink }), function (branches) {
                var existingLanguageBranches = array.filter(branches, function (item) {
                    return item.isCreated && model.currentItemData && item.languageID !== model.currentItemData.languageID;
                });

                when(confirmationMessage, function (message) {
                    var sourceLanguageOptions = new SourceLanguageOptions({
                        languageBranches: existingLanguageBranches,
                        isBlock: model.contentData.capabilities.isBlock
                    });
                    var dialog = new Dialog({
                        destroyOnHide: true,
                        dialogClass: "epi-dialog-confirm",
                        title: title,
                        description: message,
                        content: sourceLanguageOptions
                    });

                    dialog.on("execute", lang.hitch(this, function () {
                        deferred.resolve([
                            dialog.content.languageSources.value, 
                            dialog.content.addAllChildrenOption.checked, 
                            dialog.content.addRelatedBlocksOption.checked,
                            dialog.content.publishChildrenContent.checked
                        ]);
                    }));
                    
                    dialog.on("cancel", lang.hitch(this, function () {
                        deferred.cancel();
                    }));

                    dialog.show();
                });
            });
            return deferred;
        };

        var autoTranslate = function (originalMethod) {
            var confirmation = showSourceLanguageSelectorDialog(res.translatecontent.heading, res.translatecontent.description);

            return when(confirmation, function (selectedLanguageOptions) {
                // Call pasteItem of the model
                return originalMethod.apply(model, selectedLanguageOptions);
            }, function () {
                return false;
            });
        };

        var duplicateContent = function (originalMethod) {
            var confirmation = showSourceLanguageSelectorDialog(res.dulicatecontent.heading, res.dulicatecontent.description);

            return when(confirmation, function (selectedLanguageOptions) {
                // Call pasteItem of the model
                return originalMethod.apply(model, selectedLanguageOptions);
            }, function () {
                return false;
            });
        };

        aspect.around(model, "autoTranslate", function (originalMethod) {
            return function () {
                return autoTranslate(originalMethod, arguments);
            };
        });

        aspect.around(model, "duplicateContent", function (originalMethod) {
            return function () {
                return duplicateContent(originalMethod, arguments);
            };
        });

        return model;
    };
});