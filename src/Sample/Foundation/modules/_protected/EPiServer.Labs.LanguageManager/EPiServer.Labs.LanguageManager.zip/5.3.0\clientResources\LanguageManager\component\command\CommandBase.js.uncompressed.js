﻿define("epi-languagemanager/component/command/CommandBase", [
// Dojo base
    "dojo/_base/declare",

    // Epi Framework
    "epi/shell/command/_Command",

    // Language mangager
    "epi-languagemanager/component/_ExtensionContextMixin"

], function (
// Dojo base
    declare,

    // Epi Framework
    _Command,

    // Language mangager
    _ExtensionContextMixin

) {


    return declare([_Command, _ExtensionContextMixin], {

        isPage: function (context) {
            // summary:
            //		Check the input context is Page or not.
            // tags:
            //		protected

            return context && context.capabilities && context.capabilities.isPage;
        }
    });
});
