﻿define("epi-languagemanager/component/command/ManageWebsiteLanguages", [
    "dojo/_base/declare",
    "epi-languagemanager/component/command/CommandBase",

    // Resource
    "epi/i18n!epi/cms/nls/languagemanager.gadget"

], function (
    declare,
    CommandBase,
    res) {

    return declare([CommandBase], {

        // label: [public] String
        //		The action text of the command to be used in visual elements.
        label: res.managewebsitelanguages,

        // category: [readonly] String
        //		A category which provides a hint about how the command could be displayed.
        category: "setting",

        postscript: function () {
            this.inherited(arguments);
        },

        getDialogParams: function () {
            // summary:
            //		Override to provide title for the dialog.

            return { dialogTitle: res.managewebsitelanguages };
        },

        _onModelChange: function () {
            // summary:
            //		Updates canExecute and isAvailable after the model has been updated.
            // tags:
            //		protected

            this.set("canExecute", this.model.isInAdminRole);
        },

        _execute: function () {
            // summary:
            //		Navigate to Manage Website Setting Page
            // tags:
            //		protected

            window.location = this.model.settings.urlToManageWebsiteLanguage;
        }
    });
});