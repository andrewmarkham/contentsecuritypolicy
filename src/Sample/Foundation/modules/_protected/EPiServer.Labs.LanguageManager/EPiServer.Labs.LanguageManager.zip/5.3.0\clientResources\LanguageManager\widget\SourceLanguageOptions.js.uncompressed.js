require({cache:{
'url:epi-languagemanager/widget/templates/SourceLanguageOptions.html':"﻿<section class=\"epi-languageManager-optionsSelector\">\n    <div class=\"option-list\" data-dojo-attach-point=\"languageSources\" data-dojo-type=\"dijit/form/Select\" data-dojo-props=\"maxHeight:-1\"></div>\n    <div data-dojo-attach-point=\"translationContainerNode\">\n        <hr>\n        <ul class=\"translation-option-list\">\n            <li class=\"translation-option-list-item\" data-dojo-attach-point=\"addAllChildrenOptionContainerNode\">\n                <input data-dojo-attach-point=\"addAllChildrenOption\" id=\"option-addAllChildren\" data-dojo-type=\"dijit/form/CheckBox\" />\n                <label for=\"option-addAllChildren\">${res.options.addallchildren}</label>\n            </li>\n            <li class=\"translation-option-list-item\">\n                <input data-dojo-attach-point=\"addRelatedBlocksOption\" id=\"option-addRelatedBlocks\" data-dojo-type=\"dijit/form/CheckBox\" />\n                <label for=\"option-addRelatedBlocks\">${res.options.addrelatedblocks}</label>\n            </li>\n            <li class=\"translation-option-list-item dijitHidden\" data-dojo-attach-point=\"publishChildrenContentContainer\">\n                <input data-dojo-attach-point=\"publishChildrenContent\" id=\"option-publishChildrenContent\" data-dojo-type=\"dijit/form/CheckBox\" />\n                <label for=\"option-publishChildrenContent\">${res.options.publishchildrencontent}</label>\n            </li>\n        </ul>\n    </div>\n</section>"}});
﻿define("epi-languagemanager/widget/SourceLanguageOptions", [
    // dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/dom-class",
    "dojo/_base/array",
    "dojo/dom-construct",
    // dijit
    "dijit/_TemplatedMixin",
    "dijit/_Widget",
    "dijit/_WidgetsInTemplateMixin",
    // epi
    "epi/shell/widget/dialog/_DialogContentMixin",
    //epi-languagemanager
    "./LanguageOption",
    // template
    "dojo/text!./templates/SourceLanguageOptions.html",
    // resources
    "epi/i18n!epi/cms/nls/languagemanager.addtoproject",
    "dijit/form/Select"
],
function (
    // dojo
    declare,
    lang,
    domClass,
    array,
    domConstruct,
    // dijit
    _TemplatedMixin,
    _Widget,
    _WidgetsInTemplateMixin,
    // epi
    _DialogContentMixin,
    //epi-languagemanager
    LanguageOption,
    // template
    template,
    // resources
    resources
) {
    return declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin, _DialogContentMixin], {

        templateString: template,

        res: resources,

        buildRendering: function () {
            this.inherited(arguments);
            domClass.toggle(this.addAllChildrenOptionContainerNode, "dijitHidden", this.isBlock);
        },

        postCreate: function () {
            this.inherited(arguments);

            this.renderListOptions();

            this.own(
                this.addAllChildrenOption.on("click", function (e) {
                    this._togglePublishChildren(!e.target.checked && !this.addRelatedBlocksOption.checked);
                }.bind(this)),

                this.addRelatedBlocksOption.on("click", function (e) {
                    this._togglePublishChildren(!e.target.checked && !this.addAllChildrenOption.checked);
                }.bind(this))
            );

        },

        renderListOptions: function () {
            if (!this.languageBranches || !this.languageBranches.length) {
                return;
            }

            var masterLangID = "";
            var languageOptions = this.languageBranches.map(function (language) {
                var itemSetting = new LanguageOption({ item: language })
                if (language.isMaster) {
                    masterLangID = language.languageID;
                }
                return { label: itemSetting.domNode.outerHTML, value: language.languageID };
            });

            this.languageSources.set("options", languageOptions);
            this.languageSources.set("value", masterLangID);
            
        },

        _togglePublishChildren: function (hide) {
            domClass.toggle(this.publishChildrenContentContainer, "dijitHidden", hide);
            if (hide) {
                this.publishChildrenContent.set("checked", false);
            }
        }
    });
});