define("epi-languagemanager/contentediting/editors/CreateLanguageBranch", [
// dojo
    "dojo/_base/declare",
    "dojo/when",
    // epi
    "epi/Url",
    "epi/dependency",
    "epi-cms/contentediting/CreateLanguageBranch"
],

function (
// dojo
    declare,
    when,
    // epi
    Url,
    dependency,
    CreateLanguageBranch
) {

    return declare([CreateLanguageBranch], {

        postCreate: function () {
            // summary:
            //		Post widget creation handler.
            // tags:
            //		protected

            this.inherited(arguments);

            this.profile = this.profile || dependency.resolve("epi.shell.Profile");
        },

        _changeContext: function (contentLink) {
            // summary:
            //    Redirect the newly created content to editmode with language context.
            //
            // contentLink:
            //    The content link.

            var self = this;
            var host = window.location.host;

            // click on the language branch under a site (root node)
            when(this.profile.setContentLanguage(this.model.languageBranch, host)).then(function () {
                var currentItemLanguage = self.model.languageBranch;
                var uri = "#context=epi.cms.contentdata:///" + contentLink,
                    currentUrl = new Url(window.location.href),
                    currentUrlPath = currentUrl.scheme + "://" + currentUrl.authority + currentUrl.path,
                    urlToNavigate = currentUrlPath + "?language=" + currentItemLanguage + uri;

                window.location.replace(urlToNavigate);
            });
        }
    });
});
