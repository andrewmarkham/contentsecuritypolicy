﻿define("epi-languagemanager/component/viewmodel/LanguageManagerViewModel", [
// Dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/array",
    "dojo/_base/Deferred",
    "dojo/promise/all",
    "dojo/when",
    "dojo/Stateful",
    "dojo/topic",
    "dojox/html/entities",

    //EPi
    "epi/epi",
    "epi/dependency",
    "epi/shell/command/withConfirmation",
    "epi/shell/command/_CommandProviderMixin",
    "epi/shell/TypeDescriptorManager",
    "epi/Url",
    "epi/shell/widget/dialog/Alert",

    //CMS
    "epi-cms/_ContentContextMixin",
    "epi-cms/core/ContentReference",

    // Language Manager commands
    "epi-languagemanager/component/command/CompareWithMasterLanguage",
    "epi-languagemanager/component/command/DeleteLanguageBranch",
    "epi-languagemanager/component/command/ManageWebsiteLanguages",
    "epi-languagemanager/component/command/OpenLanguageSettings",
    "epi-languagemanager/component/command/Settings",
    "epi-languagemanager/component/command/ToggleEditingLanguageBranch",
    "epi-languagemanager/component/command/CreateLanguageBranch",
    "epi-languagemanager/component/command/ReplaceLanguageBranch",
    "epi-languagemanager/component/command/AddToTranslationProject",

    // Resources
    "epi/i18n!epi/cms/nls/languagemanager.gadget"
],

function (
// Dojo
    declare,
    lang,
    array,
    Deferred,
    all,
    when,
    Stateful,
    topic,
    entities,

    // EPi
    epi,
    dependency,
    withConfirmation,
    _CommandProviderMixin,
    TypeDescriptorManager,
    Url,
    Alert,

    //CMS
    _ContentContextMixin,
    ContentReference,

    // Language Manager commands
    CompareWithMasterLanguageCommand,
    DeleteLanguageBranchCommand,
    ManageWebsiteLanguagesCommand,
    OpenLanguageSettingsCommand,
    SettingsCommand,
    ToggleEditingLanguageBranchCommand,
    CreateLanguageBranchCommand,
    ReplaceLanguageBranch,
    AddToTranslationProject,

    // Resources
    res

) {

    // summary:
    //      View model object for the LanguageManager widget.
    return declare([Stateful, _CommandProviderMixin, _ContentContextMixin], {

        // store: [protected] Object
        //      Rest store for manipulate model data.
        store: null,

        // projectItemStore: [readonly] Store
        //      A REST store for interacting with projects item.
        projectItemStore: null,

        // projectService: [readonly] ProjectService
        //      A service for interacting with projects
        projectService: null,

        // contentVersionStore: [readonly] Store
        //      A REST store for interacting with content versions.
        contentVersionStore: null,

        res: null,

        _commandRegistry: null,

        _hashWrapper: null,

        _commandsReady: null,

        _currentItemDataReady: null,

        _hasProject: null,

        currentItemData: null,

        target: null,

        // deleteLanguageBranchSettings: Object
        //      Settings for DeleteLanguageBranch command
        _deleteLanguageBranchSettings: null,

        postscript: function () {
            // summary:
            //      Initialize store and data displayed for page.
            // tags:
            //      protected

            this.inherited(arguments);

            this.res = this.res || res;
            this._hashWrapper = dependency.resolve("epi.shell.HashWrapper");
            this._commandsReady = new Deferred();
            this._currentItemDataReady = new Deferred();

            //resolve _viewSettingsManager
            this._viewSettingsManager = dependency.resolve("epi.viewsettingsmanager");

            var registry = dependency.resolve("epi.storeregistry");
            this.set("store", this.store || registry.get("epi-languagemanager.language-manager"));
            this.set("settings", this.settings || registry.get("epi-languagemanager.settings"));
            this.contentVersionStore = this.contentVersionStore || registry.get("epi.cms.contentversion");
            this.projectStore =  this.projectStore || dependency.resolve("epi.storeregistry").get("epi.cms.project");
            this.projectService = this.projectService || dependency.resolve("epi.cms.ProjectService");
            this.projectItemStore = this.projectItemStore || registry.get("epi-languagemanager.project.item");
            this.own(
                this.projectService.on("project-removed", lang.hitch(this, this._onProjectChanged)),
                this.projectService.on("project-updated", lang.hitch(this, this._onProjectChanged)),
                this.projectService.on("project-item-removed", lang.hitch(this, this._onProjectItemChanged)),
                this.projectService.on("project-item-updated", lang.hitch(this, this._onProjectItemChanged))
            );

            all({
                currentContext: this.getCurrentContext(),
                isInAdminRole: this.store.executeMethod("IsCurrentUserInAdminRole", null, null),
                isTranslatingSystemAvailable: this.store.executeMethod("IsTranslatingServiceAvailable", null, null),
                hasAnyLanguageAvailable: this.store.executeMethod("HasAnyLanguageAvailable", null, null)
            }).then(lang.hitch(this, function (result) {
                var currentContext = result.currentContext,
                    isInAdminRole = result.isInAdminRole,
                    isTranslatingSystemAvailable = result.isTranslatingSystemAvailable,
                    hasAnyLanguageAvailable = result.hasAnyLanguageAvailable;

                this.set("context", currentContext);
                this.set("isInAdminRole", isInAdminRole);
                this.set("isTranslatingSystemAvailable", isTranslatingSystemAvailable);
                this.set("hasAnyLanguageAvailable", hasAnyLanguageAvailable);
                this._refreshCurrentContent(currentContext);
                this._commandsReady.resolve();
            }));
        },

        contextChanged: function (context, callerData) {
            // summary:
            //      Context change event.
            // tags:
            //      event
            this.inherited(arguments);
            this.set("context", context);
            this._refreshCurrentContent(context);
        },

        contextUpdated: function (context) {
            this.inherited(arguments);
            this._refreshCurrentContent(context);
        },

        hasAnyProject: function () {
            // summary:
            //      Check if there is any project.
            // tags:
            //      public

            if (!this._hasProject) {
                this._hasProject = new Deferred();
                var store = dependency.resolve("epi.storeregistry").get("epi-languagemanager.project");
                when(store.query({ preventCache: true }), lang.hitch(this, function (projects) {
                    this._hasProject.resolve(projects.length > 0);
                }));
            }

            return this._hasProject;
        },

        _onProjectChanged: function () {
            // summary:
            //      Listen to update project when there is a change.
            // tags:
            //      private

            // assign null to mark as need to resolve later
            this._hasProject = null;
        },

        _onProjectItemChanged: function () {
            // summary:
            //      Clear cache of projectItemStore when there is any changes.
            // tags:
            //      private

            this.projectItemStore.evict();
        },

        _refreshCurrentContent: function (context) {
            // summary:
            //      Gets current content data and setup commands.
            // tags:
            //      private

            if (!this._isContentContext(context)) {
                this.set("contentData", null);
                this.set("commands", null);
                return;
            }
            this.getCurrentContent().then(lang.hitch(this, function (contentData) {
                this._setupMasterLanguage(contentData);
                this.set("contentData", contentData);
                this._setupCommands();
                this.updateCommandModel(this);
            }));
        },

        getCommand: function (commandName) {
            // summary:
            //      Gets a command by command name
            // tags:
            //      protected

            return this._commandRegistry && this._commandRegistry[commandName] ? this._commandRegistry[commandName].command : null;
        },

        getAvailableCommands: function (category) {
            // summary:
            //      Gets available commands by category
            // tags:
            //      public

            var commands = this.get("commands");
            return commands.filter(function (cmd) {
                return cmd.category === category && cmd.get("isAvailable") === true;
            }, this);
        },

        onItemSelected: function (itemData) {
            // summary:
            //      Call when user choose a row on the grid.
            // tags:
            //      public

            this.set("currentItemData", itemData);
            this.updateCommandModel(this);

            // Update text contents of the confirmation dialog for DeleteLanguageBranch command
            var content = this.contentData;
            if (itemData && content) {
                var heading = lang.replace(res.deletelanguagebranch, itemData),
                    description = TypeDescriptorManager.getResourceValue(content.typeIdentifier, "deletelanguagebranchdescription");

                lang.mixin(this._deleteLanguageBranchSettings, {
                    confirmActionText: heading,
                    description: lang.replace(description, [entities.encode(content.name), itemData.name]),
                    title: heading
                });
            }

            if (this._currentItemDataReady) {
                this._currentItemDataReady.resolve();
                this._currentItemDataReady = null;
            }
        },

        autoTranslate: function (sourcelanguage, includeDescendents, includeRelatedContents, publishChildrenContent) {
            // summary:
            //      Replace content by translating from a source language branch.
            // tags:
            //      pubic
            var params = { 
                includeRelatedContents: includeRelatedContents,
                includeDescendents: includeDescendents,
                sourcelanguage: sourcelanguage,
                publishChildrenContent: publishChildrenContent
            }
            this._executeAction("TranslateAndCopyDataLanguageBranch", params, this._autotranslationCompleteHandler);
        },

        duplicateContent: function (sourceLanguage, includeDescendents, includeRelatedContents, publishChildrenContent) {
            // summary:
            //      Copy and replace content from a source language branch.
            // tags:
            //      pubic
            var params = { 
                includeRelatedContents: includeRelatedContents,
                includeDescendents: includeDescendents,
                sourcelanguage: sourceLanguage,
                publishChildrenContent: publishChildrenContent
            }
            this._executeAction("CopyDataLanguageBranch", params, this._duplicateContentCompleteHandler);
        },

        deleteLanguageBranch: function () {
            // summary:
            //      Delete a language branch.
            // tags:
            //      pubic

            var onComplete = function (result) {

                if (!result) {
                    var dialog = new Alert({
                        heading: res.deletefailedalert.heading,
                        description: res.deletefailedalert.message
                    });
                    dialog.show();
                    //if delete language branch fails, show alert dialog and turn off standby widget without page refresh
                    this.set("actionExecuted", {});
                    return false;
                }

                var contentReference = new ContentReference(this.contentData.contentLink);
                topic.publish("/epi/shell/context/request",
                    { uri: "epi.cms.contentdata:///" + contentReference.createVersionUnspecificReference().toString() },
                    { sender: this, forceContextChange: true });

                topic.publish("/epi/cms/contentdata/updated", {
                    contentLink: contentReference.createVersionUnspecificReference().toString(),
                    recursive: true
                });

                return true;
            };
            this._executeAction("DeleteLanguageBranch", null, onComplete);
        },

        toggleLanguageBranchActivation: function () {
            // summary:
            //      Activate/Deactivate a language branch.
            // tags:
            //      pubic

            var onComplete = function () {
                var contentReference = new ContentReference(this.contentData.contentLink);
                var id = contentReference.createVersionUnspecificReference().toString();
                topic.publish("/epi/shell/context/request",
                    { uri: "epi.cms.contentdata:///" + id },
                    { sender: this, forceContextChange: true }
                );

                // update context, this section is similar to the CloseButton of LanguageSetting legacy dialog
                // publish this event, so when we use LanguageManager's context menu to enable, disable a language,
                // SiteGadget can be changed to refresh the available LanguageList
                topic.publish("/epi/cms/contentdata/updated", {
                    contentLink: id,
                    recursive: true
                });

                return true;
            };

            this._executeAction("ToggleLanguageBranchActivation",
                {
                    twoLetterISOLanguageName: this.currentItemData.twoLetterISOLanguageName
                }, onComplete);
        },

        isContentExistingInProject: function (/*Int*/projectId, /*Object*/contentReference, /*String*/languageId) {
            // summary:
            //      Verifies the existing of the given content reference in the selected project.
            // projectId: [Int]
            //      Selected project identification.
            // contentReference: [Object]
            //      Content reference that want to add to the selected project.
            // languageId: [String]
            //      Language code of the given content reference.
            // returns: [Boolean]
            //      Flag indicates that the given content reference is existing in the selected project or not.
            // tags:
            //      public

            var deferred = new Deferred();

            // Do nothing if the given project id or content link is not valid
            if (projectId <= 0 || !contentReference) {
                deferred.resolve(true);

                return deferred;
            }

            // We need to send ProviderName and set the workdId = 0 to return all the project items that associated with the content.
            var contentRef = new ContentReference(contentReference);
            contentRef.workId = 0;

            when(this.projectService.getProjectItemsForContent(contentRef), function (projectItems) {
                if (projectItems instanceof Array && projectItems.length > 0) {
                    var i = 0,
                        totalItems = projectItems.length,
                        projectItem = null;
                    for (; i < totalItems; i++) {
                        projectItem = projectItems[i];
                        if (projectItem && projectItem.projectId === projectId && projectItem.contentLanguage === languageId) {
                            deferred.resolve(true);

                            return;
                        }
                    }
                }

                deferred.resolve(false);
            });

            return deferred;
        },

        addProjectItems: function (projectId, contentReferences, languageId) {
            // summary:
            //      Adds the given content references as items of the project.
            //
            // projectId: Number
            //      The target project for adding items to.
            // contentReferences: ContentReference[]
            //      An array of references to content items to add to the project.
            // languageID: String
            //      Language ID to add to the project
            // tags:
            //      public

            // Ensure the content reference we received are valid.
            contentReferences = contentReferences.filter(function (reference) {
                if (ContentReference.isContentReference(reference)) {
                    return true;
                }
                // eslint-disable-next-line no-console
                console.warn("epi-cms/project/ProjectService: the given value '" + reference + "' is not a valid content reference.");
            });

            return this.projectItemStore.executeMethod("addItems", projectId, { id: projectId, contentLinks: contentReferences, languageId: languageId, modifyHeader: true });
        },

        canAddContent: function (projectId, contentLinks) {
            // summary:
            //      Verifies that the given content links can be added to the project
            //
            // projectId: Number
            //      The project id to check
            // contentLinks: Array
            //      The content links to add
            // returns: Promise
            //      A promise with the result from the server
            // tags:
            //      internal

            return this.projectService.canAddContent(projectId, contentLinks, this.currentItemData.languageID);
        },

        getContentsToProject: function (/*Object*/targetProject, /*bool*/ addDescendents, /*bool*/ addRelateContents) {
            // summary:
            //      Gets all children of the given content reference
            // targetProject: [Object]
            //      The current target project
            // tags:
            //      public

            var params = {
                contentLink: this.contentData.contentLink,
                languageId: this.currentItemData.languageID,
                includeDescendents: addDescendents,
                includeRelatedContents: addRelateContents
            };

            return this.store.executeMethod("GetContentsToProject", null, params);
        },

        _executeAction: function (actionName, params, onComplete) {
            // summary:
            //      Execute an action.
            // tags:
            //      private

            this.set("actionExecuting", true);

            var defaultParams = {
                contentLink: this.contentData.contentLink,
                languageID: this.currentItemData.languageID
            };
            when(this.store.executeMethod(actionName, null, lang.mixin(defaultParams, params)),
                lang.hitch(this, function (result) {
                    var needSetActionExecutedAttr = false;
                    
                    if (onComplete) {
                        needSetActionExecutedAttr = onComplete.call(this, lang.mixin({ isSuccess: result.isSuccess }, params));
                    }
                     //In the case onComplete method return false, we dont need to set the attribute actionExecuted,
                     //because the page will be refreshed. See bug: https://jira.ep.se/browse/LM-190
                        needSetActionExecutedAttr && this.set("actionExecuted", result);
                }));
        },

        _fireContextRequest: function (forceReload) {
            // summary:
            //      public event to force context change.
            // tags:
            //      private

            // Set flag to force Iframe reload data
            this._forceIframeReload = true;
            var currentItemLanguage = this.currentItemData.languageID;
            var currentContentLanguage = new Url(window.location.href).query.language;
            
            // reload context with new language branch
            var currentUrl = new Url(window.location.href),
                currentUrlPath = currentUrl.scheme + "://" + currentUrl.authority + currentUrl.path,
                reloadUrl = currentUrlPath + this.currentItemData.linkFragment;

            // should not reload if current content language is current item language
            if (currentItemLanguage === currentContentLanguage) {
                // reload context
                var id = new ContentReference(this.contentData.contentLink).createVersionUnspecificReference().toString();
                topic.publish("/epi/shell/context/request",
                    { uri: "epi.cms.contentdata:///" + id },
                    { sender: this, forceContextChange: true });
                if (forceReload) {
                    window.location.reload();
                }
                return true;
            }

            window.location.assign(reloadUrl);
            
            return false;
        },

        _setupMasterLanguage: function (contentData) {
            // summary:
            //      Set masterLanguage property when context change.
            // tags:
            //      private

            if (contentData && contentData.existingLanguageBranches && contentData.existingLanguageBranches.length > 0) {
                var masterLanguage = contentData.existingLanguageBranches.filter(function (languageBranch) {
                    return languageBranch.isMasterLanguage === true;
                }, this);

                // TODO: Need to get the correct master language.
                // Workaround to get the master language.
                if (masterLanguage.length === 0) {
                    masterLanguage = contentData.existingLanguageBranches;
                }

                this.set("masterLanguage", masterLanguage[0].name);
            }
        },

        _setupCommands: function () {
            // summary:
            //      Setup commands for the widget.
            // tags:
            //      private

            this._deleteLanguageBranchSettings = {
                cancelActionText: epi.resources.action.cancel,
                setFocusOnConfirmButton: false
            };

            var commands = {
                /* Commands for context menu */
                createContextMenu: {
                    command: new CreateLanguageBranchCommand({ category: "contextMenu", model: this }),
                    order: 10
                },
                compareContextMenu: {
                    command: new CompareWithMasterLanguageCommand({ category: "contextMenu", iconClass: null }),
                    order: 20
                },
                replaceContextMenu: {
                    command: new ReplaceLanguageBranch({ category: "contextMenu", model: this }),
                    order: 30
                },
                addToTranslationProjectContextMenu: {
                    command: new AddToTranslationProject({ category: "contextMenu", model: this }),
                    order: 40
                },
                toggleContextMenu: {
                    command: new ToggleEditingLanguageBranchCommand({ category: "contextMenu" }),
                    order: 40
                },
                deleteContextMenu: {
                    command: withConfirmation(new DeleteLanguageBranchCommand({ category: "contextMenu" }), null, this._deleteLanguageBranchSettings),
                    order: 50
                },

                /* Commands for toolbar default position */
                compare: {
                    command: new CompareWithMasterLanguageCommand({ model: this })
                },

                /* Commands for toolbar context position */
                open: {
                    command: new OpenLanguageSettingsCommand(),
                    order: 10
                },
                create: {
                    command: new CreateLanguageBranchCommand({ model: this }),
                    order: 20
                },
                replace: {
                    command: new ReplaceLanguageBranch({ model: this }),
                    order: 30
                },
                addToTranslationProject: {
                    command: new AddToTranslationProject({ model: this }),
                    order: 40
                },
                toggle: {
                    command: new ToggleEditingLanguageBranchCommand(),
                    order: 40
                },
                "delete": {
                    command: withConfirmation(new DeleteLanguageBranchCommand(), null, this._deleteLanguageBranchSettings),
                    order: 50
                },

                /* Commands for toolbar settings position */
                manage: {
                    command: new ManageWebsiteLanguagesCommand()
                },

                setting: {
                    command: new SettingsCommand()
                },

                sort: function () {
                    var commands = [];
                    for (var key in this) {
                        if (key !== "toArray" && key !== "sort" && this.hasOwnProperty(key)) {
                            var index = this[key].order;
                            if (!index) {
                                index = 100;
                            }
                            commands.push([index, this[key].command]);
                        }
                    }

                    commands.sort(function (a, b) {
                        return a[0] - b[0];
                    });

                    return commands;
                },
                toArray: function () {
                    var sortedCommand = this.sort();
                    var commands = [];
                    array.forEach(sortedCommand, function (key) {
                        commands.push(key[1]);
                    });

                    return commands;
                }
            };

            this._commandRegistry = lang.mixin(this._commandRegistry, commands);

            this.set("commands", this._commandRegistry.toArray());
        },

        _autotranslationCompleteHandler: function (result) {
            // summary:
            //      Handle auto translation complete action if translation content saving fails, refer https://jira.ep.se/browse/LM-317
            // tags:
            //      private

            //if auto translation fails, show alert dialog and turn off standby widget without page refresh
            if (!result.isSuccess) {
                  var dialog = new Alert({
                            heading: res.autotranslationalert.heading,
                            description: res.autotranslationalert.message
                        });
                dialog.show();
                this.set("actionExecuted", {});
                return false;
            }
            //return to keep things going
            return this._fireContextRequest(result.includeDescendents || result.includeRelatedContents);
        
        },

        _duplicateContentCompleteHandler: function (result) {
            // summary:
            //      Handle duplicate content complete action if duplicated content saving fails, refer https://jira.ep.se/browse/LM-317
            // tags:
            //      private

            //if duplicate content fails, show alert dialog and turn off standby widget without page refresh
            if (!result.isSuccess) {
                var dialog = new Alert({
                    heading: res.duplicatecontentalert.heading,
                    description: res.duplicatecontentalert.message
                });
                dialog.show();
                this.set("actionExecuted", {});
                return false;
            }
            //return to keep things going
            return this._fireContextRequest(result.includeDescendents || result.includeRelatedContents);

        }
    });
});
