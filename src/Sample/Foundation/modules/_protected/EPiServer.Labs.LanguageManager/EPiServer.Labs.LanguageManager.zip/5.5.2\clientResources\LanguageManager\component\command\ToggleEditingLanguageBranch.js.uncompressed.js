﻿define("epi-languagemanager/component/command/ToggleEditingLanguageBranch", [
// Dojo base
    "dojo/_base/declare",
    "dojo/_base/lang",

    // Language manager
    "epi-languagemanager/component/command/CommandBase",

    // Resource
    "epi/i18n!epi/cms/nls/languagemanager.gadget"

], function (
// Dojo base
    declare,
    lang,

    // Language manager
    CommandBase,

    // Resource
    res

) {
    return declare([CommandBase], {

        // label: [public] String
        //		The action text of the command to be used in visual elements.
        label: "",

        // category: [readonly] String
        //		A category which provides a hint about how the command could be displayed.
        category: "context",

        postscript: function () {
            this.inherited(arguments);

            this.set("canExecute", false);
        },

        _onModelChange: function () {
            // summary:
            //		Updates canExecute and isAvailable after the model has been updated.
            // tags:
            //		protected

            var item = this.model.currentItemData;
            if (!item) {
                this.set("canExecute", false);
                this.set("isAvailable", false);

                return;
            }

            var languageSettings = this.model.contentData.capabilities.languageSettings,
                // Do nothing (command disabled) if the content is Wastebasket or Root or has been deleted
                disabled = this.isWastebasket(this.model.contentData) || this.isRoot(this.model.contentData) || this.model.contentData.isDeleted;

            this.set("canExecute",
                item.canActivate
                && item.canEdit
                && !disabled
                && languageSettings);
            this.set("isAvailable", item.canActivate && item.canEdit && languageSettings
                //hide menu "Enable/Disable Editting for {language}" for Catalog in Commerce, because Catalog content is saved in table [Catalog] of Commerce db.
                && this.model.contentData.typeIdentifier !== "episerver.commerce.catalog.contenttypes.catalogcontent");

            var resourceKey = item.isActive ? "disableediting" : "enableediting";
            this.set("label", lang.replace(res[resourceKey], item));
        },

        _execute: function () {
            // summary:
            // tags:
            //		protected

            this.model.toggleLanguageBranchActivation();
        }
    });
});
