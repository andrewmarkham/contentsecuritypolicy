require({cache:{
'url:epi-languagemanager/widget/templates/LanguageOption.html':"﻿<div class=\"language-option-list-item\" data-dojo-attach-point=\"optionWrapper\">\n    <label data-dojo-attach-point=\"optionLabel\" for=\"rdb-${item.languageID}\">${item.name}</label>\n</div>"}});
﻿define("epi-languagemanager/widget/LanguageOption", [
// dojo
    "dojo/_base/declare",
    "dojo/dom-class",
    "dojo/dom-construct",
    // dijit
    "dijit/_TemplatedMixin",
    "dijit/_Widget",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/form/RadioButton",
    // template
    "dojo/text!./templates/LanguageOption.html",
    // Resources
    "epi/i18n!epi/cms/nls/languagemanager.gadget"
],
function (
// dojo
    declare,
    domClass,
    domConstruct,
    // dijit
    _TemplatedMixin,
    _Widget,
    _WidgetsInTemplateMixin,
    RadioButton, // used in template
    // template
    template,
    // Resources
    res
) {
    return declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin], {
        templateString: template,

        buildRendering: function () {
            this.inherited(arguments);
            var span = null;
            if (this.item && this.item.isMaster) {
                domClass.add(this.optionWrapper, "master");
                span = domConstruct.toDom("<span> (" + res.master + ")</span>");
                domConstruct.place(span, this.optionLabel, "last");
            }

            if (this.item && this.item.systemIconPath) {
                span = domConstruct.toDom("<span class='systemIcon' style='background-image:url(" + this.item.systemIconPath + ")'" + " ></span>");
                domConstruct.place(span, this.optionLabel, "first");
            }
        },

        postCreate: function () {
            this.inherited(arguments);
        },

        _onChanged: function (selected) {
            this.onChange(this.item, selected);
        },

        onChange: function () {

        }
    });
});
