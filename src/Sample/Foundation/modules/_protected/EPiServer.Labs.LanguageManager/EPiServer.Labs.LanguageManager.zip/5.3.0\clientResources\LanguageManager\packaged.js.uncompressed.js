require({cache:{
'epi-languagemanager/LanguageManagerModule':function(){
﻿define("epi-languagemanager/LanguageManagerModule", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    // epi
    "epi/_Module",
    "epi/routes",
    "epi/dependency",
    "epi/shell/request/mutators",
    // epi-cms
    "epi-cms/_ContentContextMixin",
    "epi-cms/project/viewmodels/_ProjectViewModel",
    "epi-cms/project/ProjectItemQueryEngine",

    // language manager
    "epi-languagemanager/ModuleSettings",
    "epi-languagemanager/component/command/DownloadTranslationPackage",
    "epi-languagemanager/component/command/UploadTranslationPackages",
    "epi-languagemanager/component/viewmodel/UploadTranslationPackagesViewModel",
    "epi-languagemanager/request/LanguageManagerContentLanguage",
    "epi-languagemanager/request/LanguageManagerProjectMode"    
],
function (
// dojo
    declare,
    lang,

    // epi
    _Module,
    routes,
    dependency,
    mutators,

    // epi-cms
    _ContentContextMixin,
    _ProjectViewModel,
    projectItemQueryEngine,

    // language manager
    ModuleSettings,
    DownloadTranslationPackage,
    UploadTranslationPackages,

    UploadTranslationPackagesViewModel,
    languageManagerContentLanguage,
    languageManagerProjectMode
) {

    return declare([_Module], {

        // _settings: [private] Object
        //      Information which sent by LanguageManager module (in module.config file). We can read helpPath, moduleDependencies, routes, ... from here
        _settings: null,

        constructor: function (settings) {
            this._settings = settings;
        },

        initialize: function () {
            // summary:
            //      Initialize module
            //
            // description:
            //      Dependencies registered by this module are: 'LanguageManage application'

            this.inherited(arguments);

            mutators.add(languageManagerProjectMode);
            mutators.add(languageManagerContentLanguage);

            declare.safeMixin(ModuleSettings, this._settings);

            // Initialize stores
            var registry = this.resolveDependency("epi.storeregistry"),
                route = this._getRestPath("language-manager");

            this._hashWrapper = dependency.resolve("epi.shell.HashWrapper");

            registry.add("epi-languagemanager.settings", this._settings);
            registry.create("epi-languagemanager.language-manager", route, { idProperty: "id" });
            // We need to create projectItemStore ourself to inject X-EPiContentLanguage as header param later
            registry.create("epi-languagemanager.project.item", this._getCMSRestPath("project-item"), { queryEngine: projectItemQueryEngine });
            registry.create("epi-languagemanager.project", this._getCMSRestPath("project"));

            this._injectCommandsToProjectView();

            // Register route for "epi.cms.languagemanager.compareediting" context
            var contextService = this.resolveDependency("epi.shell.ContextService");
            contextService.registerRoute("epi.cms.languagemanager.compareediting", lang.hitch(this, this._redirectContext));

            //      We change the context to "epi.cms.languagemanager.compareediting",
            //      so we need to override _ContentContextMixin._isContentContext
            _ContentContextMixin.prototype._isContentContext = function (ctx) {
                return ctx && (ctx.type === "epi.cms.contentdata" || ctx.type === "epi.cms.languagemanager.compareediting");
            }
        },

        _redirectContext: function (/*Object*/context, /*Object*/callerData) {
            // summary:
            //      Redirect context
            // tags:
            //      private

            this._hashWrapper.onContextChange(context, callerData);
        },

        _getCMSRestPath: function (name) {
            return routes.getRestPath({ moduleArea: "cms", storeName: name });
        },

        _getRestPath: function (name) {
            // summary:
            //      Get the rest path to a specified store.
            // prameters:
            //      name: The name of the store to get.
            // tags:
            //      private

            return routes.getRestPath({ moduleArea: "EPiServer.Labs.LanguageManager", storeName: name });
        },

        _injectCommandsToProjectView: function () {
            // summary:
            //      HACK: inject menu items [Download Translation Package] and [Upload Translation Package] into Project view
            // tags:
            //      private

            var exportingUrl = this._settings.exportingUrl;

            var orgMethod = _ProjectViewModel.prototype.postscript;

            lang.mixin(_ProjectViewModel.prototype, {
                postscript: function () {

                    orgMethod.call(this);

                    var commands = this.get("commands");
                    commands.push(
                        new DownloadTranslationPackage({
                            category: "publishmenu",
                            model: this,
                            sortOrder: 400,
                            exportingUrl: exportingUrl
                        }),
                        new UploadTranslationPackages({
                            category: "publishmenu",
                            model: new UploadTranslationPackagesViewModel(),
                            sortOrder: 500
                        })
                    );
                }
            });
        }
    });

});

},
'epi-cms/project/ProjectItemQueryEngine':function(){
define("epi-cms/project/ProjectItemQueryEngine", [
    "epi-cms/core/ContentReference",
    "epi/shell/store/queryUtils"
], function (
    ContentReference,
    queryUtils
) {
    return function (query, options) {
        // summary:
        //      A QueryEngine configured to work with project items.
        //
        // query: Object
        //
        // options: dojo/store/api/Store.QueryOptions?
        //      An object that contains optional information such as sort, start, and count
        //
        // tags:
        //      internal xproduct
        //
        // returns: Function
        //		A QueryEngine matching the queries sent to the ProjectItemStore

        options = options || {};

        options.comparers = {
            contentLinks: function (queryValue, instance) {
                return queryValue.some(function (link) {
                    return ContentReference.compareIgnoreVersion(link, instance.contentLink);
                });
            }
        };

        return queryUtils.createEngine(query, options);
    };
});

},
'epi/shell/store/queryUtils':function(){
define("epi/shell/store/queryUtils", [], function () {

    function validSortOptions(sortOptions) {
        return sortOptions instanceof Array && sortOptions.length > 0;
    }

    var module =  {
        // summary:
        //      A QueryEngine configured to work with project items
        // tags:
        //      internal

        createFilter: function (query, options) {
            // summary:
            //      A factory usable for when creating filters for store queryEngines.
            //
            // query: Object
            //
            // options: dojo/store/api/Store.QueryOptions?
            //		An object that contains optional information such as sort, start, and count.
            //      It also supports having an array of ignore key values for query parts that
            //      should not be used in the filter and a compare dictionary for custom
            //      filtering logic.
            //
            //          {
            //              ignore: ["query", "prop2"],
            //              comparers: {
            //                  "prop3": function (queryPart, instance) { return true; }
            //              }
            //          }
            //
            // returns: Function
            //		A filter function

            var filter;

            options = options || {};

            // create our matching query function
            switch (typeof query) {

                case "object" :
                case "undefined" :
                    filter = function (item) {

                        return !query || Object.keys(query).every(function (key) {

                            var ignoreKeys = options.ignore,
                                comparer = options.comparers && options.comparers[key],
                                queryValue = query[key];

                            // Check if the query value should be ignored by the filter
                            if (ignoreKeys && ignoreKeys.indexOf(key) !== -1) {
                                return true;
                            }

                            // If there is a special comparer function registered for the query key then use that
                            if (comparer) {
                                return comparer(queryValue, item);
                            }

                            // Default to equality comparison of the query value and what's in in the items property
                            return queryValue === item[key];
                        });
                    };

                    break;
                default:
                    throw new Error("Can not query with a " + typeof query);
            }

            return filter;
        },

        createSorter: function (sortOptions) {
            // summary:
            //      A factory usable when creating sorters for store queryEngines.
            //
            // sortOptions: Object[]
            //          [
            //              { attribute: "name", descending: false },
            //              { attribute: "startDate", descending: true }
            //          ]
            //
            // returns: Function
            //		A sort function

            if (!validSortOptions(sortOptions)) {
                throw new Error("Argument must be an array containing sortOptions");
            }

            return function (a, b) {

                var aValue, bValue;

                for (var sort, i = 0; (sort = sortOptions[i]); i++) {
                    aValue = a[sort.attribute];
                    bValue = b[sort.attribute];

                    if (typeof aValue === "string" && typeof bValue === "string") {
                        aValue = aValue.toLowerCase();
                        bValue = bValue.toLowerCase();
                    }

                    if (aValue !== bValue) {
                        return sort.descending === (aValue > bValue) ? -1 : 1;
                    }
                }

                return 0;
            };
        },

        createExecuter: function (filter, sorter, start, count) {
            // summary:
            //      A factory usable for when creating the execute function of a queryEngines.
            //
            // filter: Function?
            //      A function capable of matching objects against a query
            //
            // sorter: Function?
            //      A function capable of sorting a collection
            //
            // start: Number?
            //      If used with pagination the starting point of the result collection
            //
            // count: Number?
            //      If used with pagination the number of items to return from the result collection
            //
            // returns: Function
            //		An execute function

            var begin = start || 0,
                end = count ? begin + count : Infinity;

            return function (results) {

                var total;

                // Make sure to create a new array
                results = filter ? results.filter(filter) : results.slice(0);

                sorter && results.sort(sorter);

                if (start || count) {
                    total = results.length;
                    results = results.slice(begin, end);
                    results.total = total;
                }

                return results;
            };
        },

        createEngine: function (query, options) {
            // summary:
            //      A factory for creating store queryEngines.
            //
            // query: Object
            //
            // options: dojo/store/api/Store.QueryOptions?
            //		An object that contains optional information such as sort, start, and count.
            //      It also supports having an array of ignore key values for query parts that
            //      should not be used in the filter and a compare dictionary for custom
            //      filtering logic.
            //
            //          {
            //              ignore: ["query", "prop2"],
            //              comparers: {
            //                  "prop3": function (queryPart, instance) { return true; }
            //              }
            //          }
            //
            // returns: Function
            //		A queryEngine function

            var filter,
                sorter,
                engine;

            options = options || {};

            filter = module.createFilter(query, options);
            sorter = validSortOptions(options.sort) ? module.createSorter(options.sort) : null;
            engine = module.createExecuter(filter, sorter, options.start, options.count);
            engine.matches = filter;

            return engine;
        }
    };

    return module;
});

},
'epi-languagemanager/ModuleSettings':function(){
﻿define("epi-languagemanager/ModuleSettings", [],
    function () {

        // module:
        //      epi-languagemanager/ModuleSettings
        // summary:
        //      Module settings for EPiServer LanguageManager.
        //      Stores shared settings, constants for entire module.
        // tags:
        //      public

        return {
        };

    });

},
'epi-languagemanager/component/command/DownloadTranslationPackage':function(){
﻿define([
// dojo
    "dojo/_base/declare",
    // epi
    "epi/shell/Downloader",

    // ep cms
    "epi-cms/project/command/_ProjectCommand",

    // language manager
    "epi-languagemanager/ModuleSettings",
    // resources
    "epi/i18n!epi/cms/nls/languagemanager.gadget"
],
function (
// dojo
    declare,
    // epi
    Downloader,
    // epi cms
    _ProjectCommand,

    // language manager
    ModuleSettings,
    // resources
    res
) {

    return declare([_ProjectCommand], {

        // label: [public] String
        //      The action text of the command to be used in visual elements.
        label: res.downloadtranslationpackage,

        // category: [readonly] String
        //      A category which provides a hint about how the command could be displayed.
        category: "publishmenu",

        // iconClass: [public] String
        //      The icon class of the command to be used in visual elements.
        iconClass: "epi-iconPackage",

        postscript: function () {
            this.inherited(arguments);
        },

        // propertiesToWatch: [public] Array
        //      A list of properties to watch for changes.
        propertiesToWatch: ["selectedProject"],

        _onPropertyChanged: function () {
            // summary:
            //      Sets canExecute, isAvailable based on the state of the model.
            // tags:
            //      protected

            if (!this.model.selectedProject) {
                return;
            }

            var hasProjectItems = this.model && this._hasProjectItem(this.model.selectedProject),
                isProjectPublished = this.model.selectedProject && this.model.selectedProject.status === "published";

            // set canExecute and isAvailable depend on project item count and status
            this.set("canExecute", !isProjectPublished && hasProjectItems);
            this.set("isAvailable", !isProjectPublished);
        },

        _hasProjectItem: function (project) {
            // summary:
            //      Check if the project contains any project items.
            // tags:
            //      protected

            // itemStatusCount is null outside Project Overview
            // as an effect from CMS - 7977
            if (!project.itemStatusCount) {
                return false;
            }

            return Object.keys(project.itemStatusCount).some(function (key) {
                if (project.itemStatusCount[key] > 0) {
                    return true;
                }
            });
        },

        _execute: function () {
            // summary:
            //      Gets selected project and pass its identification to server in order to get its translation package.
            // tags:
            //      protected

            var selectedProject = this.model && this.model.get("selectedProject");
            if (!selectedProject || !selectedProject.id) {
                return;
            }

            if (!this.exportingUrl) {
                this.exportingUrl = ModuleSettings.exportingUrl;
            }

            // Builds request translation package url that used to send to server
            var exportingUrl = this.exportingUrl + "?projectId=" + selectedProject.id;

            Downloader.download(exportingUrl, selectedProject.name);
        }
    });
});

},
'epi-languagemanager/component/command/UploadTranslationPackages':function(){
﻿define([
// dojo
    "dojo/_base/declare",

    // language manager
    "epi-languagemanager/component/command/CommandBase",
    // resources
    "epi/i18n!epi/cms/nls/languagemanager.gadget"
],
function (
    // dojo
    declare,

    // language manager
    CommandBase,
    // resources
    res
) {

    return declare([CommandBase], {

        // label: [public] String
        //      The action text of the command to be used in visual elements.
        label: res.uploadtranslationpackages,

        category: "context",

        // fileCollection: [public] Array
        //      An array of files to upload.
        //      When null, only show upload form to select files for uploading; otherwise, upload files in list.
        fileCollection: null,

        // iconClass: [public] String
        //      The icon class of the command to be used in visual elements.
        iconClass: "epi-iconUpload",

        constructor: function () {
            // summary:
            //      Sets initialize values for this command.
            // tags:
            //      public, extensions

            this.inherited(arguments);

            this.set("isAvailable", true);
            this.set("canExecute", true);
        },

        _execute: function () {
            // summary:
            //      Executes this command. Call upload method from model.
            // tags:
            //      protected, extensions

            if (!this.model || typeof this.model.uploadTranslationPackages !== "function") {
                return;
            }

            this.model.uploadTranslationPackages(this.fileCollection);

            // Clear fileCollection after uploading, to avoid of displaying last uploaded item on upload dialog.
            this.fileCollection = null;
        }
    });
});

},
'epi-languagemanager/component/command/CommandBase':function(){
﻿define([
// Dojo base
    "dojo/_base/declare",

    // Epi Framework
    "epi/shell/command/_Command",

    // Language mangager
    "epi-languagemanager/component/_ExtensionContextMixin"

], function (
// Dojo base
    declare,

    // Epi Framework
    _Command,

    // Language mangager
    _ExtensionContextMixin

) {


    return declare([_Command, _ExtensionContextMixin], {

        isPage: function (context) {
            // summary:
            //		Check the input context is Page or not.
            // tags:
            //		protected

            return context && context.capabilities && context.capabilities.isPage;
        }
    });
});

},
'epi-languagemanager/component/_ExtensionContextMixin':function(){
﻿define([
// Dojo base
    "dojo/_base/declare",

    // EPi CMS
    "epi-cms/ApplicationSettings",
    "epi-cms/core/ContentReference"

], function (
// Dojo base
    declare,

    // Epi CMS
    ApplicationSettings,
    ContentReference

) {


    return declare(null, {

        isWastebasket: function (contentData) {
            // summary:
            //		Check the current context is Wasterbasket page or not.
            // contentData: [Object]
            //      The content data model
            // tags:
            //		protected

            return contentData && new ContentReference(contentData.contentLink).id === ApplicationSettings.wastebasketPage;
        },

        isRoot: function (contentData) {
            // summary:
            //		Check the current context is Root page or not.
            // contentData: [Object]
            //      The content data model
            // tags:
            //		protected

            return contentData && new ContentReference(contentData.contentLink).id === ApplicationSettings.rootPage;
        },

        isSupportedType: function (contentData) {
            // summary:
            //		Check the contentData's type is supported or not.
            // contentData: [Object]
            //      The content data model
            // tags:
            //		protected

            return this.model.settings.restrictedTypes.indexOf(contentData.typeIdentifier) === -1;
        }
    });
});

},
'epi-languagemanager/component/viewmodel/UploadTranslationPackagesViewModel':function(){
﻿define([
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/Stateful",

    // epi
    "epi/dependency",
    "epi/routes",
    "epi/shell/widget/dialog/Dialog",
    "epi-cms/widget/MultipleFileUpload",
    "epi-cms/widget/viewmodel/MultipleFileUploadViewModel",

    // resources
    "epi/i18n!epi/cms/nls/languagemanager.gadget"
],
function (
// dojo
    declare,
    lang,
    Stateful,
    // epi
    dependency,
    routes,
    Dialog,
    MultipleFileUpload,
    MultipleFileUploadViewModel,

    // resources
    res
) {

    return declare([Stateful], {
        // resources
        res: res,

        postscript: function () {
            // summary:
            //      Initialize for upload
            // tags:
            //      public, extensions

            this.inherited(arguments);
        },

        uploadTranslationPackages: function (/*Array*/fileCollection) {
            // summary:
            //      Uploads translation package(s) to an indicated folder on server
            // fileCollection: [Array]
            //      List files to upload.
            //      When null, only show upload form to select files for uploading.
            //      Otherwise, upload files in list.
            // tags:
            //      public

            // Only create diaglog if it is not available, otherwise, re-use it.
            var uploader = new MultipleFileUpload({
                model: new MultipleFileUploadViewModel()
            });

            // Set the action path for upload form
            uploader.uploaderInput.uploadUrl = routes.getActionPath({
                moduleArea: "EPiServer.Labs.LanguageManager",
                controller: "TranslationPackageUpload",
                action: "Upload"
            });

            uploader.on("beforeUploaderChange", lang.hitch(this, function () {
                this._uploading = true;
            }));

            // Close multiple files upload dialog when stop uploading
            uploader.on("close", lang.hitch(this, function (uploading) {
                this._dialog && (uploading ? this._dialog.hide() : this._dialog.destroy());
            }));

            uploader.on("uploadComplete", lang.hitch(this, function (/*Array*/uploadFiles) {
                if (this._dialog && !this._dialog.open) {
                    this._dialog.destroy();
                }

                this._uploading = false;
            }));

            this._dialog = new Dialog({
                title: this.res.uploadtranslationpackages,
                dialogClass: "epi-dialog-upload",
                content: uploader,
                autofocus: true,
                defaultActionsVisible: false,
                closeIconVisible: false
            });

            // Only show close button for multiple files upload dialog
            this._dialog.definitionConsumer.add({
                name: "close",
                label: epi.resources.action.close, /* eslint-disable-line */
                action: function () {
                    uploader.close();
                }
            });

            this._dialog.resize({ w: 700 });
            this._dialog.show();

            uploader.upload(fileCollection);
        }
    });
});

},
'epi-languagemanager/request/LanguageManagerContentLanguage':function(){
﻿define([
    "dojo/Deferred"
], function (Deferred) {

    return {
        beforeSend: function (params) {
            // summary:
            //      Request mutator for adding the currently selected content language to a xhr request
            //      By the default, the [project-item] store always use current language (ContentLanguage.PreferredCulture),
            //      This module will chain the request and change the header key "x-EPiContentLanguage" with our custom language id.
            // params: Object
            //      The request parameters
            // tags: internal

            var options = params.options;
            if (options.postData) {
                var data;
                try {
                    data = JSON.parse(options.postData);
                } catch (e) { /*quiet*/ }

                if (data && data.modifyHeader === true && data.languageId) {
                    options.headers["X-EPiContentLanguage"] = data.languageId;
                }
            }

            var result = new Deferred();
            result.resolve(params);

            return result.promise;
        }
    };

});

},
'epi-languagemanager/request/LanguageManagerProjectMode':function(){
﻿define([
    "dojo/Deferred"
], function (Deferred) {

    return {
        beforeSend: function (params) {
            // summary:
            //      Request mutator for adding the currently selected project to a xhr request
            //      By the default, the Cms UI always sends the header key "x-EPiCurrentProject" with value is the current active project.
            //      This header value will take over the custom projectId which we want to add item to.
            //      This module will chain the request and change the header key "x-EPiCurrentProject" with our custom project-Id.
            // params: Object
            //      The request parameters
            // tags: internal

            var options = params.options;
            if (options.postData) {
                var data;
                try {
                    data = JSON.parse(options.postData);
                } catch (e) { /*quiet*/ }

                if (data && data.modifyHeader === true && data.id) {
                    options.headers["X-EPiCurrentProject"] = data.id;
                }
            }

            var result = new Deferred();
            result.resolve(params);

            return result.promise;
        }
    };

});

},
'epi-languagemanager/component/LanguageManager':function(){
﻿define([
// Dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/aspect",
    "dojo/when",
    "dojo/topic",
    "dojo/json",
    "dojo/dom-construct",
    "dojo/dom-style",
    "dojo/dom-class",
    "dojo/dom-geometry",
    "dojo/dom-attr",
    "dojo/html",
    "dojo/store/Memory",
    "dojo/store/Observable",
    "dojo/on",
    "dojo/promise/all",
    "dojo/query",

    // Dijit
    "dijit/_TemplatedMixin",
    "dijit/_WidgetBase",
    "dijit/_Container",
    "dijit/layout/_LayoutWidget",
    "dgrid/OnDemandGrid",
    "dgrid/Selection",

    // Dojox
    "dojox/widget/Standby",

    // EPi Framework
    "epi/dependency",
    "epi/Url",
    "epi/shell/widget/_ModelBindingMixin",
    "epi/shell/command/_WidgetCommandProviderMixin",
    "epi/shell/dgrid/util/misc",
    "epi/shell/widget/_FocusableMixin",
    "epi/shell/widget/dialog/Dialog",
    "epi/shell/widget/dialog/Alert",
    "epi/datetime",
    "epi/shell/command/withConfirmation",
    "epi/shell/widget/ContextMenu",
    "epi/shell/TypeDescriptorManager",

    // CMS
    "epi-cms/_ContentContextMixin",
    "epi-cms/core/ContentReference",
    "epi-cms/component/command/DeleteLanguageBranch",

    // Language Manager
    "epi-languagemanager/component/viewmodel/LanguageManagerViewModel",
    "epi-languagemanager/component/viewmodel/LanguageManagerViewModelWrapper",
    "epi-languagemanager/component/_ExtensionContextMixin",

    // Resources
    "epi/i18n!epi/cms/nls/languagemanager.gadget"
],
function (
// Dojo
    declare,
    lang,
    aspect,
    when,
    topic,
    json,
    domConstruct,
    domStyle,
    domClass,
    domGeometry,
    domAttr,
    html,
    Memory,
    Observable,
    on,
    all,
    query,

    // Dijit
    _TemplatedMixin,
    _WidgetBase,
    _Container,
    _LayoutWidget,
    OnDemandGrid,
    Selection,

    // Dojox
    Standby,

    // EPi Framework
    dependency,
    Url,

    _ModelBindingMixin,
    _WidgetCommandProviderMixin,
    GridMiscUtil,
    _FocusableMixin,
    Dialog,
    Alert,
    epiDate,
    withConfirmation,
    ContextMenu,
    TypeDescriptorManager,

    // CMS
    _ContentContextMixin,
    ContentReference,
    DeleteLanguageBranch,

    // Language Manager
    LanguageManagerViewModel,
    LanguageManagerViewModelWrapper,
    _ExtensionContextMixin,

    // Resources
    res
) {

    return declare([_Container, _LayoutWidget, _TemplatedMixin, _ModelBindingMixin, _WidgetCommandProviderMixin, _FocusableMixin, _ContentContextMixin, _ExtensionContextMixin], {

        modulePath: null,
        isTranslatingSystemAvailable: null, // Determines whether current TranslatingService available

        model: null,
        context: null,
        contentData: null,
        store: null,

        grid: null,
        standby: null,

        commandProvider: null,
        commandProviderInitialized: null,

        _messageClassName: "epi-languageManagerMessage",

        // _hashWrapper: epi.shell.HashWrapper
        //    The hash wrapper instance.
        _hashWrapper: null,

        _inactiveCssClass: "inactive",
        _currentLanguageCssClass: "currentLanguage",
        _disabledCssClass: "disabled",
        _preferLanguageCssClass: "preferLanguage",
        _mouseOverCssClass: "epi-dgrid-mouseover",

        modelBindingMap: {
            context: ["context"],
            contentData: ["contentData"],
            store: ["store"],
            actionExecuted: ["actionExecuted"],
            actionExecuting: ["actionExecuting"]
        },

        templateString: '<div class="epi-languagemanager"></div>',

        postscript: function () {
            // summary:
            //      Initialize view model, setting up the grid and register events as well.
            // tags:
            //      protected

            this.inherited(arguments);

            this._hashWrapper = dependency.resolve("epi.shell.HashWrapper");

            var customGridClass = declare([OnDemandGrid, Selection]);
            this.grid = new customGridClass({
                columns: {
                    name: {
                        renderCell: lang.hitch(this, this._setupLanguageCollumn)
                    },
                    contentStatus: {
                        renderCell: lang.hitch(this, this._setupContentStatusCollumn)
                    },
                    existence: {
                        renderCell: lang.hitch(this, this._setupExistenceCollumn)
                    },
                    contextmenu: {
                        renderCell: function (item, value, node, options) {
                            var format = "<div class='epi-languageManagerEditAction' title='{0}'>\
                                            <span class='dijitInline dijitIcon epi-iconContextMenu epi-floatRight' title ='{1}'>&nbsp;</span>\
                                          <div>";
                            // TODO: make localization for tooltip
                            node.innerHTML = lang.replace(format, ["Context Menu", "Context Menu"]);
                        }
                    }
                },
                selectionMode: "single",
                showHeader: false
            }, this.domNode);

            when(this.getCurrentContext(), lang.hitch(this, function (ctx) {
                // set the query associate with current context
                this.grid.set("query", { contentLink: ctx.id });
                // init model for the widget
                this.set("model", this.model || new LanguageManagerViewModel({ modulePath: this.modulePath }));
                this.model = this._wrapModel(this.model);
            }));

            this._setupEvents();
            this._createContextMenu();

            // Save current states of the tools and navigation panes each time changed.
            // This data will be used to restore states of each pane after close compare mode of language manager addon.
            // We should listen and save each time one of pane changed.
            topic.subscribe("/epi/layout/pinnable/navigation/toggle", this._savePinnablePanesState);
            topic.subscribe("/epi/layout/pinnable/tools/toggle", this._savePinnablePanesState);
        },

        startup: function () {

            this.inherited(arguments);

            this.standby = new Standby({ target: "applicationContainer" });
            document.body.appendChild(this.standby.domNode);
            this.standby.startup();
        },

        _wrapModel: function (model) {
            // summary:
            //      Wraps the model with a confirmation
            // tags:
            //      protected
            return LanguageManagerViewModelWrapper(this.model);
        },

        _langIDFromUrl: new Url(window.location.href).query.language,

        _aroundInsertRow: function (/*Object*/original) {
            // summary:
            //      Called 'around' the insertRow method to fix the grids less than perfect selection.
            // tags:
            //      private

            return lang.hitch(this, function (object, parent, beforeNode, i, options) {

                // Call original method
                var row = original.apply(this.grid, arguments),
                    languageContext = this.context.languageContext;

                if (object.languageID === this._langIDFromUrl) {
                    this.grid.clearSelection();
                    this.grid.select(object);
                    this.model.onItemSelected(object);
                }

                if (!object.isActive) {
                    domClass.add(row, this._inactiveCssClass);  // add the inactive class to the whole row
                }
                if (languageContext && object.languageID === languageContext.preferredLanguage) {
                    domClass.add(row, this._preferLanguageCssClass);
                }

                row.title =
                    object.isActive && (languageContext && object.languageID !== languageContext.preferredLanguage)
                    && this.model.contentData.capabilities.languageSettings
                        ? res.clicktoswitchlanguage : !object.isActive ? res.editingforlanguageisdisabled : "";

                return row;
            });
        },

        _setContextAttr: function (context) {
            if (context) {
                this._set("context", context);
                if (!this._langIDFromUrl) {
                    this._langIDFromUrl = context.language;
                }
            }

        },

        _setContentDataAttr: function (contentData) {
            if (contentData) {
                // initiliaze command provider only it has not been initiliazed
                if (!this.commandProviderInitialized) {
                    // Re-initiliaze command provider
                    this.commandProviderInitialized = true;

                    this.commandProvider = this.model;
                    this._consumer = this.getConsumer();

                    this._consumer.addProvider(this.commandProvider);
                    this.contextMenu.addProvider(this.commandProvider);
                    this.contextMenu.startup();

                    var self = this;

                    this.own(
                        this.commandProvider,
                        aspect.around(this._consumer.toolbar, "_getCurrentPosition", function (originalMethod) {
                            return function (currentCategory) {
                                if (currentCategory === "default") {
                                    return 0;
                                }
                                // Need to wait because "_getCurrentPosition" method sometime has exception on IE
                                setTimeout(function () {
                                    return originalMethod.apply(self._consumer.toolbar, [currentCategory]);
                                }, 0);
                            };
                        })
                    );
                }

                this.grid.set("query", { contentLink: contentData.contentLink });

            }

            // also based on context.languageContext (context available only when contentData available), e.g: Root & Trash
            // and dataType, e.g: "episerver.commerce.catalog.contenttypes.rootcontent" to show/hide message
            if (contentData && contentData.existingLanguageBranches && contentData.existingLanguageBranches.length > 0
                && this.context.languageContext
                && this.isSupportedType(contentData)) {
                this._hideMessage();
            } else {
                this._showMessage(res.contentnotsupport);
            }
        },

        _setActionExecutingAttr: function (value) {
            if (!value) {
                return;
            }
            this.standby.show();
        },

        _setActionExecutedAttr: function (result) {
            if (!result) {
                return;
            }
            this.grid.refresh();
            this.standby.hide();
        },

        _setStoreAttr: function (/*Object*/store) {
            // summary:
            //      Set the store associatated with the grid.
            // parameters:
            //      store: Rest store object.
            // tags:
            //      private

            this._set("store", store);
            this.grid.set("store", store);
        },

        _setupLanguageCollumn: function (item, value, node, options) {
            // summary:
            //      Setup for the Language collumn of dgrid.
            // param:
            //  item: LanguageInfo item of LanguageManager Rest Store
            //  node: grid cell element

            var canActivateOrDeactivate = (item.canActivate && this.model.contentData.capabilities.languageSettings);

            var systemIconString = lang.replace("<span class='systemIcon' {backgroundIconStyle}></span>",
                {
                    backgroundIconStyle: item.systemIconPath != null ? "style='background-image:url(" + item.systemIconPath + ")'" : ""
                });

            var languageName = lang.replace("<span class='languageName rowTextElement'>{languageName}{suffix}</span>",
                {
                    languageName: value,
                    suffix: item.isMaster ? " (" + res.master + ")" : ""
                });

            node.innerHTML = systemIconString + languageName;

            if (item.isCurrent) {
                domClass.add(node, this._currentLanguageCssClass);
            }

            if (!item.isActive) {
                domClass.add(node, this._inactiveCssClass);
            }

            if (!canActivateOrDeactivate) {
                domClass.add(node, this._disabledCssClass);
            }
        },

        _setupContentStatusCollumn: function (item, value, node, options) {
            // summary:
            // param:
            //  item: LanguageInfo item of LanguageManager Rest Store
            //  node: grid cell element

            var contentStatus = item.isCreated ? (item.isPublished ? res.published : res.draft) : res.notcreatedyet;
            var contentHtml = lang.replace("<span class='rowTextElement' >{0}</span>", [contentStatus]);
            node.innerHTML = contentHtml;
        },

        _setupExistenceCollumn: function (item, value, node, options) {
            // summary:
            // param:
            //  item: LanguageInfo item of LanguageManager Rest Store
            //  node: grid cell element

            var contentHtml = "";

            if (item.isActive && item.canCreate && !item.isCreated) {
                contentHtml = lang.replace("<a class='lmLanguageBranchAction createLanguageBranch rowTextElement epi-visibleLink' >{0}</a>", [res.create]);
            } else if (item.isCreated) {
                contentHtml = lang.replace("<span class='lmDateTime rowTextElement' >{0}</span>", [epiDate.toUserFriendlyString(item.publishedDateTime ? item.publishedDateTime : item.savedDateTime)]);
            }

            node.innerHTML = contentHtml;
        },

        _onCreateLanguageBranch: function (e) {
            // summary:
            //    Create a language branch.
            // tags:
            //    private

            e.stopImmediatePropagation();

            this.model.set("target", e);

            // TODO: Select row that was clicked
            this.model.onItemSelected(this.grid.row(e).data);
            var command = this.model.getCommand("create");
            command.execute();
        },

        _onSwitchLanguage: function (evt) {
            // summary:
            //    Handle event for switching between languages.
            // tags:
            //    private

            var cell = this.grid.cell(evt);
            var row = this.grid.row(evt);
            // Do not redirect to the language branch if it is not active,
            // or it is prefer language
            if (domClass.contains(row.element, this._inactiveCssClass)
                || domClass.contains(cell.element, this._preferLanguageCssClass)) {
                return;
            }
            var hash = this._hashWrapper.getHash(),
                currentUrl = new Url(window.location.href),
                currentUrlPath = currentUrl.scheme + "://" + currentUrl.authority + currentUrl.path;
            // TECHNOTE: consider to use topic.publish changerequest.
            window.location.replace(currentUrlPath + row.data.linkFragment);

            // force to refresh page if url is the same language, but different hash (of view setting)
            if (hash && hash.viewsetting) {
                if (new Url(window.location.href).query.language === row.data.languageID) {
                    window.location.reload();
                }
            }
        },

        _createContextMenu: function () {
            // summary:
            //      Creates the context menu for the grid.
            // tags:
            //      private

            this.contextMenu = new ContextMenu({ category: "contextMenu" });
            this.own(this.contextMenu);
        },

        _setupEvents: function () {
            // summary:
            //      Initialization of events on the grid.
            // tags:
            //      protected

            var self = this;

            this.own(
                this.grid.on(".createLanguageBranch:click", lang.hitch(this, "_onCreateLanguageBranch")),
                this.grid.on(".epi-iconContextMenu:click", lang.hitch(this, "_onContextMenuClick")),

                //When mouse is over a row, show the context menu node
                this.grid.on(".dgrid-row:mouseover", function (event) {
                    domClass.add(this, self._mouseOverCssClass);
                }),
                //When mouse is out of an unselected row, hide the context menu node
                this.grid.on(".dgrid-row:mouseout", function (event) {
                    domClass.remove(this, self._mouseOverCssClass);
                }),

                /* click on row (except buttons, contextmenu) will switch */
                this.grid.on(".dgrid-row:click", lang.hitch(this, "_onSwitchLanguage")),

                //When mouse is out of an unselected row, hide the context menu node
                this.grid.on("dgrid-select", lang.hitch(this, function (event) {
                    this.model.onItemSelected(event.rows[0].data);
                })),

                // update the grid when user close language setting dialog, or manage website language dialog
                topic.subscribe("/epi/cms/contentdata/updated", function () {
                    self.grid.refresh();
                }),

                // Overide base method from grid to set selected item
                aspect.around(this.grid, "insertRow", lang.hitch(this, this._aroundInsertRow))
            );
        },

        _onContextMenuClick: function (e) {
            // summary:
            //    Handle event click of context menu node.
            //
            // tags:
            //    private

            e.stopImmediatePropagation();

            var availableCommands = this.model.getAvailableCommands("contextMenu");
            if (availableCommands && availableCommands instanceof Array && availableCommands.length > 0) {
                this.contextMenu.scheduleOpen(this, null, {
                    x: e.pageX,
                    y: e.pageY
                });
            }
        },


        _keepMenuItemUncheck: function (original) {
            // summary:
            //      Replace _setCheckedAttr method to keep menu item always uncheck.
            // tags:
            //      private

            return lang.hitch(this, function (value) {
                // do nothing
            });
        },

        _showMessage: function (/*String*/message) {
            // summary:
            //      Create a message to display inside the gadget
            // tags:
            //      private

            var messageContainer = query("." + this._messageClassName);
            if (messageContainer.length === 0) {
                messageContainer = domConstruct.create("span", { "class": this._messageClassName }, this.grid.domNode, "before");
            }

            messageContainer.innerHTML = message;

            domStyle.set(this.grid.domNode, "display", "none");
        },

        _hideMessage: function () {
            // summary:
            //      Destroy the message
            // tags:
            //      private

            var messageContainer = query("." + this._messageClassName);
            if (messageContainer.length > 0) {
                domConstruct.destroy(messageContainer[0]);
            }
            domStyle.set(this.grid.domNode, "display", "");
        },

        _savePinnablePanesState: function () {
            // summary:
            //      Saves current state of the pinnable panes
            // tags:
            //      private

            var profile = dependency.resolve("epi.shell.Profile");

            all({
                toolsSettings: profile.get("tools"),
                navigationSettings: profile.get("navigation")
            }).then(function (results) {
                var toolsPinned = results && results.toolsSettings && results.toolsSettings.pinned,
                    navigationPinned = results && results.navigationSettings && results.navigationSettings.pinned;

                profile.set("addons-language-manager-settings", {
                    toolsPinned: toolsPinned,
                    navigationPinned: navigationPinned
                });
            });
        }
    });
});

},
'epi-languagemanager/component/viewmodel/LanguageManagerViewModel':function(){
﻿define([
// Dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/array",
    "dojo/_base/Deferred",
    "dojo/promise/all",
    "dojo/when",
    "dojo/Stateful",
    "dojo/topic",
    "dojox/html/entities",

    //EPi
    "epi/epi",
    "epi/dependency",
    "epi/shell/command/withConfirmation",
    "epi/shell/command/_CommandProviderMixin",
    "epi/shell/TypeDescriptorManager",
    "epi/Url",
    "epi/shell/widget/dialog/Alert",

    //CMS
    "epi-cms/_ContentContextMixin",
    "epi-cms/core/ContentReference",

    // Language Manager commands
    "epi-languagemanager/component/command/CompareWithMasterLanguage",
    "epi-languagemanager/component/command/DeleteLanguageBranch",
    "epi-languagemanager/component/command/ManageWebsiteLanguages",
    "epi-languagemanager/component/command/OpenLanguageSettings",
    "epi-languagemanager/component/command/Settings",
    "epi-languagemanager/component/command/ToggleEditingLanguageBranch",
    "epi-languagemanager/component/command/CreateLanguageBranch",
    "epi-languagemanager/component/command/ReplaceLanguageBranch",
    "epi-languagemanager/component/command/AddToTranslationProject",

    // Resources
    "epi/i18n!epi/cms/nls/languagemanager.gadget"
],

function (
// Dojo
    declare,
    lang,
    array,
    Deferred,
    all,
    when,
    Stateful,
    topic,
    entities,

    // EPi
    epi,
    dependency,
    withConfirmation,
    _CommandProviderMixin,
    TypeDescriptorManager,
    Url,
    Alert,

    //CMS
    _ContentContextMixin,
    ContentReference,

    // Language Manager commands
    CompareWithMasterLanguageCommand,
    DeleteLanguageBranchCommand,
    ManageWebsiteLanguagesCommand,
    OpenLanguageSettingsCommand,
    SettingsCommand,
    ToggleEditingLanguageBranchCommand,
    CreateLanguageBranchCommand,
    ReplaceLanguageBranch,
    AddToTranslationProject,

    // Resources
    res

) {

    // summary:
    //      View model object for the LanguageManager widget.
    return declare([Stateful, _CommandProviderMixin, _ContentContextMixin], {

        // store: [protected] Object
        //      Rest store for manipulate model data.
        store: null,

        // projectItemStore: [readonly] Store
        //      A REST store for interacting with projects item.
        projectItemStore: null,

        // projectService: [readonly] ProjectService
        //      A service for interacting with projects
        projectService: null,

        // contentVersionStore: [readonly] Store
        //      A REST store for interacting with content versions.
        contentVersionStore: null,

        res: null,

        _commandRegistry: null,

        _hashWrapper: null,

        _commandsReady: null,

        _currentItemDataReady: null,

        _hasProject: null,

        currentItemData: null,

        target: null,

        // deleteLanguageBranchSettings: Object
        //      Settings for DeleteLanguageBranch command
        _deleteLanguageBranchSettings: null,

        postscript: function () {
            // summary:
            //      Initialize store and data displayed for page.
            // tags:
            //      protected

            this.inherited(arguments);

            this.res = this.res || res;
            this._hashWrapper = dependency.resolve("epi.shell.HashWrapper");
            this._commandsReady = new Deferred();
            this._currentItemDataReady = new Deferred();

            //resolve _viewSettingsManager
            this._viewSettingsManager = dependency.resolve("epi.viewsettingsmanager");

            var registry = dependency.resolve("epi.storeregistry");
            this.set("store", this.store || registry.get("epi-languagemanager.language-manager"));
            this.set("settings", this.settings || registry.get("epi-languagemanager.settings"));
            this.contentVersionStore = this.contentVersionStore || registry.get("epi.cms.contentversion");
            this.projectStore =  this.projectStore || dependency.resolve("epi.storeregistry").get("epi.cms.project");
            this.projectService = this.projectService || dependency.resolve("epi.cms.ProjectService");
            this.projectItemStore = this.projectItemStore || registry.get("epi-languagemanager.project.item");
            this.own(
                this.projectService.on("project-removed", lang.hitch(this, this._onProjectChanged)),
                this.projectService.on("project-updated", lang.hitch(this, this._onProjectChanged)),
                this.projectService.on("project-item-removed", lang.hitch(this, this._onProjectItemChanged)),
                this.projectService.on("project-item-updated", lang.hitch(this, this._onProjectItemChanged))
            );

            all({
                currentContext: this.getCurrentContext(),
                isInAdminRole: this.store.executeMethod("IsCurrentUserInAdminRole", null, null),
                isTranslatingSystemAvailable: this.store.executeMethod("IsTranslatingServiceAvailable", null, null),
                hasAnyLanguageAvailable: this.store.executeMethod("HasAnyLanguageAvailable", null, null)
            }).then(lang.hitch(this, function (result) {
                var currentContext = result.currentContext,
                    isInAdminRole = result.isInAdminRole,
                    isTranslatingSystemAvailable = result.isTranslatingSystemAvailable,
                    hasAnyLanguageAvailable = result.hasAnyLanguageAvailable;

                this.set("context", currentContext);
                this.set("isInAdminRole", isInAdminRole);
                this.set("isTranslatingSystemAvailable", isTranslatingSystemAvailable);
                this.set("hasAnyLanguageAvailable", hasAnyLanguageAvailable);
                this._refreshCurrentContent(currentContext);
                this._commandsReady.resolve();
            }));
        },

        contextChanged: function (context, callerData) {
            // summary:
            //      Context change event.
            // tags:
            //      event
            this.inherited(arguments);
            this.set("context", context);
            this._refreshCurrentContent(context);
        },

        contextUpdated: function (context) {
            this.inherited(arguments);
            this._refreshCurrentContent(context);
        },

        hasAnyProject: function () {
            // summary:
            //      Check if there is any project.
            // tags:
            //      public

            if (!this._hasProject) {
                this._hasProject = new Deferred();
                var store = dependency.resolve("epi.storeregistry").get("epi-languagemanager.project");
                when(store.query({ preventCache: true }), lang.hitch(this, function (projects) {
                    this._hasProject.resolve(projects.length > 0);
                }));
            }

            return this._hasProject;
        },

        _onProjectChanged: function () {
            // summary:
            //      Listen to update project when there is a change.
            // tags:
            //      private

            // assign null to mark as need to resolve later
            this._hasProject = null;
        },

        _onProjectItemChanged: function () {
            // summary:
            //      Clear cache of projectItemStore when there is any changes.
            // tags:
            //      private

            this.projectItemStore.evict();
        },

        _refreshCurrentContent: function (context) {
            // summary:
            //      Gets current content data and setup commands.
            // tags:
            //      private

            if (!this._isContentContext(context)) {
                this.set("contentData", null);
                this.set("commands", null);
                return;
            }
            this.getCurrentContent().then(lang.hitch(this, function (contentData) {
                this._setupMasterLanguage(contentData);
                this.set("contentData", contentData);
                this._setupCommands();
                this.updateCommandModel(this);
            }));
        },

        getCommand: function (commandName) {
            // summary:
            //      Gets a command by command name
            // tags:
            //      protected

            return this._commandRegistry && this._commandRegistry[commandName] ? this._commandRegistry[commandName].command : null;
        },

        getAvailableCommands: function (category) {
            // summary:
            //      Gets available commands by category
            // tags:
            //      public

            var commands = this.get("commands");
            return commands.filter(function (cmd) {
                return cmd.category === category && cmd.get("isAvailable") === true;
            }, this);
        },

        onItemSelected: function (itemData) {
            // summary:
            //      Call when user choose a row on the grid.
            // tags:
            //      public

            this.set("currentItemData", itemData);
            this.updateCommandModel(this);

            // Update text contents of the confirmation dialog for DeleteLanguageBranch command
            var content = this.contentData;
            if (itemData && content) {
                var heading = lang.replace(res.deletelanguagebranch, itemData),
                    description = TypeDescriptorManager.getResourceValue(content.typeIdentifier, "deletelanguagebranchdescription");

                lang.mixin(this._deleteLanguageBranchSettings, {
                    confirmActionText: heading,
                    description: lang.replace(description, [entities.encode(content.name), itemData.name]),
                    title: heading
                });
            }

            if (this._currentItemDataReady) {
                this._currentItemDataReady.resolve();
                this._currentItemDataReady = null;
            }
        },

        autoTranslate: function (sourcelanguage, includeDescendents, includeRelatedContents, publishChildrenContent) {
            // summary:
            //      Replace content by translating from a source language branch.
            // tags:
            //      pubic
            var params = { 
                includeRelatedContents: includeRelatedContents,
                includeDescendents: includeDescendents,
                sourcelanguage: sourcelanguage,
                publishChildrenContent: publishChildrenContent
            }
            this._executeAction("TranslateAndCopyDataLanguageBranch", params, this._autotranslationCompleteHandler);
        },

        duplicateContent: function (sourceLanguage, includeDescendents, includeRelatedContents, publishChildrenContent) {
            // summary:
            //      Copy and replace content from a source language branch.
            // tags:
            //      pubic
            var params = { 
                includeRelatedContents: includeRelatedContents,
                includeDescendents: includeDescendents,
                sourcelanguage: sourceLanguage,
                publishChildrenContent: publishChildrenContent
            }
            this._executeAction("CopyDataLanguageBranch", params, this._duplicateContentCompleteHandler);
        },

        deleteLanguageBranch: function () {
            // summary:
            //      Delete a language branch.
            // tags:
            //      pubic

            var onComplete = function (result) {

                if (!result) {
                    var dialog = new Alert({
                        heading: res.deletefailedalert.heading,
                        description: res.deletefailedalert.message
                    });
                    dialog.show();
                    //if delete language branch fails, show alert dialog and turn off standby widget without page refresh
                    this.set("actionExecuted", {});
                    return false;
                }

                var contentReference = new ContentReference(this.contentData.contentLink);
                topic.publish("/epi/shell/context/request",
                    { uri: "epi.cms.contentdata:///" + contentReference.createVersionUnspecificReference().toString() },
                    { sender: this, forceContextChange: true });

                topic.publish("/epi/cms/contentdata/updated", {
                    contentLink: contentReference.createVersionUnspecificReference().toString(),
                    recursive: true
                });

                return true;
            };
            this._executeAction("DeleteLanguageBranch", null, onComplete);
        },

        toggleLanguageBranchActivation: function () {
            // summary:
            //      Activate/Deactivate a language branch.
            // tags:
            //      pubic

            var onComplete = function () {
                var contentReference = new ContentReference(this.contentData.contentLink);
                var id = contentReference.createVersionUnspecificReference().toString();
                topic.publish("/epi/shell/context/request",
                    { uri: "epi.cms.contentdata:///" + id },
                    { sender: this, forceContextChange: true }
                );

                // update context, this section is similar to the CloseButton of LanguageSetting legacy dialog
                // publish this event, so when we use LanguageManager's context menu to enable, disable a language,
                // SiteGadget can be changed to refresh the available LanguageList
                topic.publish("/epi/cms/contentdata/updated", {
                    contentLink: id,
                    recursive: true
                });

                return true;
            };

            this._executeAction("ToggleLanguageBranchActivation",
                {
                    twoLetterISOLanguageName: this.currentItemData.twoLetterISOLanguageName
                }, onComplete);
        },

        isContentExistingInProject: function (/*Int*/projectId, /*Object*/contentReference, /*String*/languageId) {
            // summary:
            //      Verifies the existing of the given content reference in the selected project.
            // projectId: [Int]
            //      Selected project identification.
            // contentReference: [Object]
            //      Content reference that want to add to the selected project.
            // languageId: [String]
            //      Language code of the given content reference.
            // returns: [Boolean]
            //      Flag indicates that the given content reference is existing in the selected project or not.
            // tags:
            //      public

            var deferred = new Deferred();

            // Do nothing if the given project id or content link is not valid
            if (projectId <= 0 || !contentReference) {
                deferred.resolve(true);

                return deferred;
            }

            // We need to send ProviderName and set the workdId = 0 to return all the project items that associated with the content.
            var contentRef = new ContentReference(contentReference);
            contentRef.workId = 0;

            when(this.projectService.getProjectItemsForContent(contentRef), function (projectItems) {
                if (projectItems instanceof Array && projectItems.length > 0) {
                    var i = 0,
                        totalItems = projectItems.length,
                        projectItem = null;
                    for (; i < totalItems; i++) {
                        projectItem = projectItems[i];
                        if (projectItem && projectItem.projectId === projectId && projectItem.contentLanguage === languageId) {
                            deferred.resolve(true);

                            return;
                        }
                    }
                }

                deferred.resolve(false);
            });

            return deferred;
        },

        addProjectItems: function (projectId, contentReferences, languageId) {
            // summary:
            //      Adds the given content references as items of the project.
            //
            // projectId: Number
            //      The target project for adding items to.
            // contentReferences: ContentReference[]
            //      An array of references to content items to add to the project.
            // languageID: String
            //      Language ID to add to the project
            // tags:
            //      public

            // Ensure the content reference we received are valid.
            contentReferences = contentReferences.filter(function (reference) {
                if (ContentReference.isContentReference(reference)) {
                    return true;
                }
                // eslint-disable-next-line no-console
                console.warn("epi-cms/project/ProjectService: the given value '" + reference + "' is not a valid content reference.");
            });

            return this.projectItemStore.executeMethod("addItems", projectId, { id: projectId, contentLinks: contentReferences, languageId: languageId, modifyHeader: true });
        },

        canAddContent: function (projectId, contentLinks) {
            // summary:
            //      Verifies that the given content links can be added to the project
            //
            // projectId: Number
            //      The project id to check
            // contentLinks: Array
            //      The content links to add
            // returns: Promise
            //      A promise with the result from the server
            // tags:
            //      internal

            return this.projectService.canAddContent(projectId, contentLinks, this.currentItemData.languageID);
        },

        getContentsToProject: function (/*Object*/targetProject, /*bool*/ addDescendents, /*bool*/ addRelateContents) {
            // summary:
            //      Gets all children of the given content reference
            // targetProject: [Object]
            //      The current target project
            // tags:
            //      public

            var params = {
                contentLink: this.contentData.contentLink,
                languageId: this.currentItemData.languageID,
                includeDescendents: addDescendents,
                includeRelatedContents: addRelateContents
            };

            return this.store.executeMethod("GetContentsToProject", null, params);
        },

        _executeAction: function (actionName, params, onComplete) {
            // summary:
            //      Execute an action.
            // tags:
            //      private

            this.set("actionExecuting", true);

            var defaultParams = {
                contentLink: this.contentData.contentLink,
                languageID: this.currentItemData.languageID
            };
            when(this.store.executeMethod(actionName, null, lang.mixin(defaultParams, params)),
                lang.hitch(this, function (result) {
                    var needSetActionExecutedAttr = false;
                    
                    if (onComplete) {
                        needSetActionExecutedAttr = onComplete.call(this, lang.mixin({ isSuccess: result.isSuccess }, params));
                    }
                     //In the case onComplete method return false, we dont need to set the attribute actionExecuted,
                     //because the page will be refreshed. See bug: https://jira.ep.se/browse/LM-190
                        needSetActionExecutedAttr && this.set("actionExecuted", result);
                }));
        },

        _fireContextRequest: function (forceReload) {
            // summary:
            //      public event to force context change.
            // tags:
            //      private

            // Set flag to force Iframe reload data
            this._forceIframeReload = true;
            var currentItemLanguage = this.currentItemData.languageID;
            var currentContentLanguage = new Url(window.location.href).query.language;
            
            // reload context with new language branch
            var currentUrl = new Url(window.location.href),
                currentUrlPath = currentUrl.scheme + "://" + currentUrl.authority + currentUrl.path,
                reloadUrl = currentUrlPath + this.currentItemData.linkFragment;

            // should not reload if current content language is current item language
            if (currentItemLanguage === currentContentLanguage) {
                // reload context
                var id = new ContentReference(this.contentData.contentLink).createVersionUnspecificReference().toString();
                topic.publish("/epi/shell/context/request",
                    { uri: "epi.cms.contentdata:///" + id },
                    { sender: this, forceContextChange: true });
                if (forceReload) {
                    window.location.reload();
                }
                return true;
            }

            window.location.assign(reloadUrl);
            
            return false;
        },

        _setupMasterLanguage: function (contentData) {
            // summary:
            //      Set masterLanguage property when context change.
            // tags:
            //      private

            if (contentData && contentData.existingLanguageBranches && contentData.existingLanguageBranches.length > 0) {
                var masterLanguage = contentData.existingLanguageBranches.filter(function (languageBranch) {
                    return languageBranch.isMasterLanguage === true;
                }, this);

                // TODO: Need to get the correct master language.
                // Workaround to get the master language.
                if (masterLanguage.length === 0) {
                    masterLanguage = contentData.existingLanguageBranches;
                }

                this.set("masterLanguage", masterLanguage[0].name);
            }
        },

        _setupCommands: function () {
            // summary:
            //      Setup commands for the widget.
            // tags:
            //      private

            this._deleteLanguageBranchSettings = {
                cancelActionText: epi.resources.action.cancel,
                setFocusOnConfirmButton: false
            };

            var commands = {
                /* Commands for context menu */
                createContextMenu: {
                    command: new CreateLanguageBranchCommand({ category: "contextMenu", model: this }),
                    order: 10
                },
                compareContextMenu: {
                    command: new CompareWithMasterLanguageCommand({ category: "contextMenu", iconClass: null }),
                    order: 20
                },
                replaceContextMenu: {
                    command: new ReplaceLanguageBranch({ category: "contextMenu", model: this }),
                    order: 30
                },
                addToTranslationProjectContextMenu: {
                    command: new AddToTranslationProject({ category: "contextMenu", model: this }),
                    order: 40
                },
                toggleContextMenu: {
                    command: new ToggleEditingLanguageBranchCommand({ category: "contextMenu" }),
                    order: 40
                },
                deleteContextMenu: {
                    command: withConfirmation(new DeleteLanguageBranchCommand({ category: "contextMenu" }), null, this._deleteLanguageBranchSettings),
                    order: 50
                },

                /* Commands for toolbar default position */
                compare: {
                    command: new CompareWithMasterLanguageCommand({ model: this })
                },

                /* Commands for toolbar context position */
                open: {
                    command: new OpenLanguageSettingsCommand(),
                    order: 10
                },
                create: {
                    command: new CreateLanguageBranchCommand({ model: this }),
                    order: 20
                },
                replace: {
                    command: new ReplaceLanguageBranch({ model: this }),
                    order: 30
                },
                addToTranslationProject: {
                    command: new AddToTranslationProject({ model: this }),
                    order: 40
                },
                toggle: {
                    command: new ToggleEditingLanguageBranchCommand(),
                    order: 40
                },
                "delete": {
                    command: withConfirmation(new DeleteLanguageBranchCommand(), null, this._deleteLanguageBranchSettings),
                    order: 50
                },

                /* Commands for toolbar settings position */
                manage: {
                    command: new ManageWebsiteLanguagesCommand()
                },

                setting: {
                    command: new SettingsCommand()
                },

                sort: function () {
                    var commands = [];
                    for (var key in this) {
                        if (key !== "toArray" && key !== "sort" && this.hasOwnProperty(key)) {
                            var index = this[key].order;
                            if (!index) {
                                index = 100;
                            }
                            commands.push([index, this[key].command]);
                        }
                    }

                    commands.sort(function (a, b) {
                        return a[0] - b[0];
                    });

                    return commands;
                },
                toArray: function () {
                    var sortedCommand = this.sort();
                    var commands = [];
                    array.forEach(sortedCommand, function (key) {
                        commands.push(key[1]);
                    });

                    return commands;
                }
            };

            this._commandRegistry = lang.mixin(this._commandRegistry, commands);

            this.set("commands", this._commandRegistry.toArray());
        },

        _autotranslationCompleteHandler: function (result) {
            // summary:
            //      Handle auto translation complete action if translation content saving fails, refer https://jira.ep.se/browse/LM-317
            // tags:
            //      private

            //if auto translation fails, show alert dialog and turn off standby widget without page refresh
            if (!result.isSuccess) {
                  var dialog = new Alert({
                            heading: res.autotranslationalert.heading,
                            description: res.autotranslationalert.message
                        });
                dialog.show();
                this.set("actionExecuted", {});
                return false;
            }
            //return to keep things going
            return this._fireContextRequest(result.includeDescendents || result.includeRelatedContents);
        
        },

        _duplicateContentCompleteHandler: function (result) {
            // summary:
            //      Handle duplicate content complete action if duplicated content saving fails, refer https://jira.ep.se/browse/LM-317
            // tags:
            //      private

            //if duplicate content fails, show alert dialog and turn off standby widget without page refresh
            if (!result.isSuccess) {
                var dialog = new Alert({
                    heading: res.duplicatecontentalert.heading,
                    description: res.duplicatecontentalert.message
                });
                dialog.show();
                this.set("actionExecuted", {});
                return false;
            }
            //return to keep things going
            return this._fireContextRequest(result.includeDescendents || result.includeRelatedContents);

        }
    });
});

},
'epi-languagemanager/component/command/CompareWithMasterLanguage':function(){
﻿define([
// Dojo base
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/topic",
    "dojo/promise/all",
    "dojo/when",

    // Epi Framework
    "epi/dependency",
    "epi/Url",
    "epi-cms/core/ContentReference",

    // Language mangager
    "epi-languagemanager/component/command/CommandBase",

    // Resource
    "epi/i18n!epi/cms/nls/languagemanager.gadget"
],
function (
// Dojo base
    declare,
    lang,
    topic,
    all,
    when,

    // Epi Framework
    dependency,
    Url,
    ContentReference,

    // Language manager
    CommandBase,

    // Resource
    res
) {

    return declare([CommandBase], {

        // label: [public] String
        //      The action text of the command to be used in visual elements.
        label: "Compare with {language} (Master)",

        iconClass: "epi-iconCompare",

        constructor: function (params) {
            this.inherited(arguments);

            if (params && params.model) {
                this.set("label", lang.replace(res.comparewithmasterlanguage, { name: params.model.masterLanguage }));
            }

            this.profile = dependency.resolve("epi.shell.Profile");
            this.set("isAvailable", true);
            this.set("canExecute", true);
        },

        _onModelChange: function () {
            // summary:
            //      Updates canExecute and isAvailable after the model has been updated.
            // tags:
            //      protected

            var item = this.model.currentItemData;

            if (!item) {
                this.set("canExecute", false);
                return;
            }

            // Do nothing (command disabled) if the content is Wastebasket or Root or has been deleted or is an unsupported type
            var disabled = this.isWastebasket(this.model.contentData) || this.isRoot(this.model.contentData)
                    || this.model.contentData.isDeleted || !this.isSupportedType(this.model.contentData);

            this.set("label", lang.replace(res.comparewithmasterlanguage, { name: this.model.masterLanguage }));

            this.set("isAvailable", !this.category || item.isCreated && item.canEdit && !item.isMaster && item.isActive);
            this.set("canExecute", item.canEdit && item.isCreated && !item.isMaster && item.isActive && !disabled);
        },

        execute: function (/*Mouse event*/evt, /*Boolean?*/isForced) {
            if (!this.model.currentItemData || !this.model.currentItemData.languageID) {
                return;
            }

            // currentItemData.canEdit = false means that the current user has not Edit access right on the language,
            // and he cannot access compare editing
            if (!this.model.currentItemData.canEdit) {
                // set actionExecuted to remove standby widget
                this.model.set("actionExecuted", {});
                return;
            }

            // Make it fullscreen, unpin left and right panel
            topic.publish("/epi/layout/pinnable/navigation/toggle", false);
            topic.publish("/epi/layout/pinnable/tools/toggle", false);

            // Save current pinnable state for restoring later
            var self = this;
            all({
                toolsSettings: self.profile.get("tools"),
                navigationSettings: self.profile.get("navigation")
            }).then(function (results) {
                var toolsPinned = results && results.toolsSettings && results.toolsSettings.pinned,
                    navigationPinned = results && results.navigationSettings && results.navigationSettings.pinned;

                self.profile.set("addons-language-manager-settings", {
                    toolsPinned: toolsPinned,
                    navigationPinned: navigationPinned
                });
            });

            // Switch to compare view
            var currentContentLanguage = new Url(window.location.href).query.language,
                currentItemLanguage = this.model.currentItemData.languageID,
                shouldReload = currentContentLanguage !== currentItemLanguage;

            // This is for getting the content id without WorkId (e.g. 6 instead of 6_1234).
            // The resolver on server will automatically get the latest version
            var contentReference = new ContentReference(this.model.context.id);
            var contentReferenceWithoutVersion = contentReference.createVersionUnspecificReference();

            if (shouldReload) {
                // If the comparing language is different from the current content language,
                // then we need to switch the content language to the comparing language before making comparison

                var currentUrl = new Url(window.location.href),
                    currentUrlPath = currentUrl.scheme + "://" + currentUrl.authority + currentUrl.path,
                    reloadUrl = currentUrlPath + "?language=" + currentItemLanguage + "#context=epi.cms.languagemanager.compareediting:///" + contentReferenceWithoutVersion;

                when(self.profile.setContentLanguage(currentItemLanguage, currentUrl.authority)).then(function () {
                    window.location.replace(reloadUrl);
                });
            } else {
                topic.publish("/epi/shell/context/request", { uri: "epi.cms.languagemanager.compareediting:///" + contentReferenceWithoutVersion }, { languageManagerAction: "compare", trigger: "internal" });
            }
        }
    });
});

},
'epi-languagemanager/component/command/DeleteLanguageBranch':function(){
﻿define([
// Dojo base
    "dojo/_base/declare",
    "dojo/_base/lang",

    // EPi CMS
    "epi-cms/ApplicationSettings",

    // Language Manager
    "epi-languagemanager/component/command/CommandBase",

    // Resource
    "epi/i18n!epi/cms/nls/languagemanager.gadget"
],
function (
// Dojo base
    declare,
    lang,

    // EPi CMS
    ApplicationSettings,

    // Language Manager
    CommandBase,

    // Resource
    res
) {

    return declare([CommandBase], {

        // label: [public] String
        //      The action text of the command to be used in visual elements.
        label: res.deletelanguagebranch,

        // category: [readonly] String
        //      A category which provides a hint about how the command could be displayed.
        category: "context",

        postscript: function () {
            this.inherited(arguments);

            this.set("canExecute", false);
        },

        _onModelChange: function () {
            // summary:
            //      Updates canExecute and isAvailable after the model has been updated.
            // tags:
            //      protected

            var item = this.model.currentItemData;

            if (!item) {
                this.set("canExecute", false);
                this.set("isAvailable", false);
                return;
            }

            var isActive = item.isActive && this.model.context.capabilities.deleteLanguageBranch, // check deleteLanguageBranch capability.
                // Do nothing (command disabled) if the content is Wastebasket or Root or has been deleted
                disabled = this.isWastebasket(this.model.contentData) || this.isRoot(this.model.contentData) || this.model.contentData.isDeleted;

            this.set("canExecute",
                item.canDelete
                && item.isCreated
                && !item.isMaster
                && isActive
                && !disabled
                && !ApplicationSettings.disableVersionDeletion
            );

            this.set("isAvailable", item.canDelete && item.isCreated && !item.isMaster && isActive && !ApplicationSettings.disableVersionDeletion);

            this.set("label", lang.replace(res.deletelanguagebranch, item));
        },

        _execute: function () {
            // summary:
            //      Delete a language branch.
            // tags:
            //      protected

            return this.model.deleteLanguageBranch();
        }

    });
});

},
'epi-languagemanager/component/command/ManageWebsiteLanguages':function(){
﻿define([
    "dojo/_base/declare",
    "epi-languagemanager/component/command/CommandBase",

    // Resource
    "epi/i18n!epi/cms/nls/languagemanager.gadget"

], function (
    declare,
    CommandBase,
    res) {

    return declare([CommandBase], {

        // label: [public] String
        //		The action text of the command to be used in visual elements.
        label: res.managewebsitelanguages,

        // category: [readonly] String
        //		A category which provides a hint about how the command could be displayed.
        category: "setting",

        postscript: function () {
            this.inherited(arguments);
        },

        getDialogParams: function () {
            // summary:
            //		Override to provide title for the dialog.

            return { dialogTitle: res.managewebsitelanguages };
        },

        _onModelChange: function () {
            // summary:
            //		Updates canExecute and isAvailable after the model has been updated.
            // tags:
            //		protected

            this.set("canExecute", this.model.isInAdminRole);
        },

        _execute: function () {
            // summary:
            //		Navigate to Manage Website Setting Page
            // tags:
            //		protected

            window.location = this.model.settings.urlToManageWebsiteLanguage;
        }
    });
});
},
'epi-languagemanager/component/command/OpenLanguageSettings':function(){
﻿define([
    "dojo/_base/declare",
    "epi-cms/contentediting/command/LanguageSettings",

    // Language mangager
    "epi-languagemanager/component/_ExtensionContextMixin",

    // Resource
    "epi/i18n!epi/cms/nls/languagemanager.gadget"
],

function (
    declare,
    _LanguageSettings,

    // Language mangager
    _ExtensionContextMixin,

    res) {

    // TODO: listen close dialog event to refresh the gadget.

    return declare([_LanguageSettings, _ExtensionContextMixin], {

        // label: [public] String
        //		The action text of the command to be used in visual elements.
        label: res.languagesettings,
        title: res.languagesettings,

        // category: [readonly] String
        //		A category which provides a hint about how the command could be displayed.
        category: "context",
        postscript: function () {
            this.inherited(arguments);
        },

        _onModelChange: function () {
            // summary:
            //		Updates canExecute and isAvailable after the model has been updated.
            // tags:
            //		protected

            var item = this.model.currentItemData;
            if (!item || !this.model.hasAnyLanguageAvailable) {
                this.set("canExecute", false);

                return;
            }

            var languageSettings = this.model.contentData.capabilities.languageSettings,
                // Do nothing (command disabled) if the content is Wastebasket or Root or has been deleted
                disabled = this.isWastebasket(this.model.contentData) || this.isRoot(this.model.contentData) || this.model.contentData.isDeleted;

            this.set("canExecute",
                item.canActivate
                && languageSettings
                && !disabled
            );
        }
    });
});

},
'epi-languagemanager/component/command/Settings':function(){
﻿define([
    // Dojo base
    "dojo/_base/declare",

    // Language manager
    "epi-languagemanager/component/command/CommandBase",

    // Resource
    "epi/i18n!epi/cms/nls/languagemanager.gadget"

], function (
    // Dojo base
    declare,

    // Language manager
    CommandBase,

    // Resource
    res

) {


    return declare([CommandBase], {

        // label: [public] String
        //		The action text of the command to be used in visual elements.
        label: res.settings,

        // category: [readonly] String
        //		A category which provides a hint about how the command could be displayed.
        category: "setting",

        postscript: function () {
            this.inherited(arguments);

            this.set("canExecute", false);
        },

        _onModelChange: function () {
            // summary:
            //		Updates canExecute and isAvailable after the model has been updated.
            // tags:
            //		protected

            this.set("canExecute", this.model.isInAdminRole);
        },

        _execute: function () {
            // summary:
            //		Navigate to Settings Panel
            // tags:
            //		protected

            window.location = this.model.settings.urlToSettingsPage;
        }
    });
});

},
'epi-languagemanager/component/command/ToggleEditingLanguageBranch':function(){
﻿define([
// Dojo base
    "dojo/_base/declare",
    "dojo/_base/lang",

    // Language manager
    "epi-languagemanager/component/command/CommandBase",

    // Resource
    "epi/i18n!epi/cms/nls/languagemanager.gadget"

], function (
// Dojo base
    declare,
    lang,

    // Language manager
    CommandBase,

    // Resource
    res

) {
    return declare([CommandBase], {

        // label: [public] String
        //		The action text of the command to be used in visual elements.
        label: "",

        // category: [readonly] String
        //		A category which provides a hint about how the command could be displayed.
        category: "context",

        postscript: function () {
            this.inherited(arguments);

            this.set("canExecute", false);
        },

        _onModelChange: function () {
            // summary:
            //		Updates canExecute and isAvailable after the model has been updated.
            // tags:
            //		protected

            var item = this.model.currentItemData;
            if (!item) {
                this.set("canExecute", false);
                this.set("isAvailable", false);

                return;
            }

            var languageSettings = this.model.contentData.capabilities.languageSettings,
                // Do nothing (command disabled) if the content is Wastebasket or Root or has been deleted
                disabled = this.isWastebasket(this.model.contentData) || this.isRoot(this.model.contentData) || this.model.contentData.isDeleted;

            this.set("canExecute",
                item.canActivate
                && item.canEdit
                && !disabled
                && languageSettings);
            this.set("isAvailable", item.canActivate && item.canEdit && languageSettings
                //hide menu "Enable/Disable Editting for {language}" for Catalog in Commerce, because Catalog content is saved in table [Catalog] of Commerce db.
                && this.model.contentData.typeIdentifier !== "episerver.commerce.catalog.contenttypes.catalogcontent");

            var resourceKey = item.isActive ? "disableediting" : "enableediting";
            this.set("label", lang.replace(res[resourceKey], item));
        },

        _execute: function () {
            // summary:
            // tags:
            //		protected

            this.model.toggleLanguageBranchActivation();
        }
    });
});

},
'epi-languagemanager/component/command/CreateLanguageBranch':function(){
﻿define([
// Dojo base
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/aspect",

    // Dijit
    "dijit/popup",
    "dijit/focus",
    "dijit/registry",

    // Language manager
    "epi-languagemanager/component/command/_CommandWithOptions",
    "epi-languagemanager/widget/command/DuplicateContent",
    "epi-languagemanager/widget/command/StartBlank",
    "epi-languagemanager/widget/command/AutoTranslate",

    // Resources
    "epi/i18n!epi/cms/nls/languagemanager.gadget"
],
function (
// Dojo base
    declare,
    lang,
    aspect,

    // Dijit
    popupManager,
    focusUtil,
    registry,

    // Language manager
    _CommandWithOptions,
    DuplicateContent,
    StartBlank,
    AutoTranslate,

    // Resources
    res
) {

    return declare([_CommandWithOptions], {

        label: res.create,

        // For create link
        _internalPopup: null,

        _setupPopup: function (/*Object*/popup) {

            this.inherited(arguments);
            // Set new header label
            popup.set("headingText", lang.replace(res.createpagein, this.model.currentItemData));
        },

        _setupInternalPopup: function (/*Boolean*/commandAvailable) {
            // summary:
            //      Create an independent popup that used to display everywhere
            // tags:
            //      private

            // Close current open popup if command is not available
            if (!commandAvailable) {
                if (this._internalPopup) {
                    var focusNode = focusUtil.get("curNode");
                    popupManager.close(this._internalPopup);
                    this._setEditorFocus(focusNode);
                }

                return;
            }

            if (!this._internalPopup) {
                this._internalPopup = new this.popupClass();
                this._setupEvent(this._internalPopup);
            }
            this._setupPopup(this._internalPopup);
        },

        _onModelChange: function () {
            // summary:
            //      Updates canExecute and isAvailable after the model has been updated.
            // tags:
            //      protected

            this.inherited(arguments);

            var item = this.model.currentItemData;

            if (!item) {
                this.set("canExecute", false);
                this.set("isAvailable", false);
                return;
            }

            var commandAvailable = item.isActive && item.canCreate && !item.isCreated,
                // Do nothing (command disabled) if the content is Wastebasket or Root or has been deleted
                disabled = this.isWastebasket(this.model.contentData) || this.isRoot(this.model.contentData) || this.model.contentData.isDeleted;

            this.set("isAvailable", commandAvailable);
            this.set("canExecute", commandAvailable && !disabled);

            this._setupInternalPopup(commandAvailable && !disabled);
        },

        execute: function (evt) {
            this._execute(evt);
        },

        getSubCommands: function (model) {
            // summary:
            //      Setup sub menu items when user click to create language branch.
            // tags:
            //      public

            var isTranslatingSystemAvailable = model.isTranslatingSystemAvailable;

            var autoTranslate = new AutoTranslate({ model: model }),
                duplicateContent = new DuplicateContent({ model: model }),
                startWithBlank = new StartBlank({ model: model }),
                createLanguageBranchCommands = [
                    {
                        label: autoTranslate.label,
                        value: autoTranslate,
                        disabled: isTranslatingSystemAvailable === false ? "disabled" : false
                    },
                    {
                        label: duplicateContent.label,
                        value: duplicateContent,
                        disabled: false
                    },
                    {
                        label: startWithBlank.label,
                        value: startWithBlank,
                        disabled: false
                    }
                ];

            return createLanguageBranchCommands;
        },

        _execute: function (evt) {
            // summary:
            //      Executes this command assuming canExecute has been checked. Subclasses should override this method.
            // tags:
            //      protected

            var self = this,
                target = this.model.get("target"),
                mouseEvent = evt || target;

            if (!mouseEvent) {
                return;
            }

            var popup = this._internalPopup,
                prevFocusNode = focusUtil.get("prevNode"),
                curFocusNode = focusUtil.get("curNode"),
                focusNode = popup.domNode,
                savedFocusNode = prevFocusNode ? prevFocusNode : curFocusNode;

            var popupBlurHanlder = aspect.after(popup, "onBlur", function () {
                popupBlurHanlder.remove();

                self.model.set("target", null);
                popupManager.close(popup);
                self._setEditorFocus(savedFocusNode);
            });

            focusUtil.focus(focusNode);

            popupManager.open({
                around: mouseEvent.target,
                popup: popup,
                onCancel: function () {
                    popupManager.close(popup);
                }
            });
        },

        _setEditorFocus: function (nodeToFocus) {
            // summary:
            //      Set focus for given dom node and enclosing editor.
            // tags:
            //      private

            if (!nodeToFocus) {
                return;

            }
            nodeToFocus.focus();

            // call _onFocus to make TinyMCE editor active and auto save work
            var parentWidget = registry.getEnclosingWidget(nodeToFocus);
            if (parentWidget && parentWidget._onFocus) {
                parentWidget._onFocus();
            }
        }
    });
});

},
'epi-languagemanager/component/command/_CommandWithOptions':function(){
﻿define([
// Dojo base
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/aspect",

    // Dijit
    "dijit/popup",
    "dijit/Destroyable",

    // Language manager
    "epi-languagemanager/component/command/CommandBase",
    "epi-languagemanager/widget/CommandSelector"
],
function (
// Dojo base
    declare,
    lang,
    aspect,

    // Dijit
    popupManager,
    Destroyable,

    // Language manager
    CommandBase,
    CommandSelector
) {

    return declare([CommandBase, Destroyable], {

        // label: [public] String
        //      The action text of the command to be used in visual elements.
        label: "",

        category: "context",

        // For contextMenu
        popup: null,
        popupClass: CommandSelector,

        constructor: function (params) {
            this.set("isAvailable", true);
            this.set("canExecute", true);
        },

        _popupSetter: function (/*Object*/popup) {
            // summary:
            //      Customize set method to setting up on the popup
            // tags:
            //      public override

            this.popup = popup;
            this._setupPopup(this.popup);
            this._setupEvent(this.popup);
        },

        _setupPopup: function (/*Object*/popup) {
            // summary:
            //      Initialize popup sub items and do something else.
            // tags:
            //      private

            // Create sub items
            this._setupSubItems(this.model, popup);
        },

        _setupEvent: function (/*Object*/popup) {
            // summary:
            //      Bind event's listeners on the popup
            // tags:
            //      private

            this.own(
                aspect.after(popup, "onItemSelected", lang.hitch(this, function (command) {
                    var parentMenu = popup.parentMenu;
                    if (parentMenu) {
                        parentMenu._cleanUp();
                        popupManager.close(parentMenu);
                    } else {
                        popupManager.close(popup);
                    }

                    this.onItemSelected(command);
                }), true)
            );
        },

        _onModelChange: function () {
            // summary:
            //      Updates the command and sub commands when the model has been updated.
            // tags:
            //      protected

            if (this.popup) {
                this._setupPopup(this.popup);
            }
        },

        _setupSubItems: function (model, popup) {
            // summary:
            //      Setup sub menu items when user click to the command.
            // tags:
            //      protected

            var subCommands = this.getSubCommands(model);

            popup.set("items", subCommands);
        },

        getSubCommands: function (model) {
            // summary:
            //      Get sub menu items
            // tags:
            //      public
        },

        onItemSelected: function (command) {
            // summary:
            //      Callback when a subcommand is selected
            // tags:
            //      public

            command.execute(true);
        }
    });
});

},
'epi-languagemanager/widget/CommandSelector':function(){
﻿define([
// Dojo
    "dojo/_base/declare",
    "dojo/_base/array",
    "dojo/_base/lang",
    "dojo/dom-style",

    // Dojox
    "dojox/html/entities",

    // Dijit
    "dijit/registry",
    "dijit/MenuItem",
    "dijit/_TemplatedMixin",

    // EPi CMS
    "epi-cms/widget/SelectorMenuBase",

    // Resouces
    "dojo/text!./templates/CommandSelector.html"

], function (
// Dojo
    declare,
    array,
    lang,
    domStyle,

    // Dojox
    htmlEntities,

    // Dijit
    registry,
    MenuItem,
    _TemplatedMixin,

    // EPi CMS
    SelectorMenuBase,

    // Resouces
    template
) {
    // module:
    //      "epi-languagemanager/widget/CommandSelector"
    // summary:
    //      Used for selecting command options

    return declare([SelectorMenuBase, _TemplatedMixin], {

        // templateString: [protected] String
        //      Html template for the slector
        templateString: template,

        itemClass: MenuItem,

        _setHeaderDisplayAttr: function (visible) {
            domStyle.set(this.headerNode, "display", visible ? "" : "none");
        },

        _setHeadingTextAttr: function (text) {
            this._set("headingText", text);
            this.header.innerHTML = text;
        },

        _setItemsAttr: function (items) {
            this._set("items", items);
            this._setup();
        },

        _setup: function () {

            if (!this.items) {
                return;
            }

            //Destroy the old menu items
            this._removeMenuItems();

            array.forEach(this.items, function (itemData) {

                var menuItem = new this.itemClass({
                    label: htmlEntities.encode(itemData.label),
                    value: itemData.value,
                    _setSelected: this._setSelected,
                    onClick: lang.hitch(this, function (evt) {
                        var target = evt.srcElement || evt.target;
                        if (registry.getEnclosingWidget(target) instanceof this.itemClass) {
                            this.onItemSelected(menuItem.value);
                        }
                    })
                });

                if (itemData.disabled === "disabled") {
                    menuItem.set("disabled", "disabled");
                }

                this.addChild(menuItem);
            }, this);
        },

        onItemSelected: function (item) {
            // summary:
            //   Raised when a item is selected, it will fire the view setting change.
            //
            // tags:
            //    event
        },

        _removeMenuItems: function () {
            var items = this.getChildren();
            items.forEach(function (item) {
                this.removeChild(item);
                item.destroy();
            }, this);
        },

        _setSelected: function (selected) {
            // fix js error when blur menu item. Need to improve later.
        }
    });
});

},
'url:epi-languagemanager/widget/templates/CommandSelector.html':"﻿<div class=\"epi-menu--inverted\">\n    <div class=\"epi-dijitTooltipContainer\">\n        <div data-dojo-attach-point=\"headerNode\" class=\"epi-invertedTooltip\">\n            <div class=\"epi-tooltipDialogTop\">\n                <span data-dojo-attach-point=\"header\"></span>\n                <div class=\"dijitTooltipConnector\"></div>\n            </div>\n        </div>\n        <div class=\"epi-tooltipDialogContent--max-height\">\n            <table class=\"dijitReset dijitMenu epi-tooltipDialogMenu epi-menuInverted epi-mediumMenuItem\" style=\"width: 100%\" cellspacing=\"0\">\n                <tbody data-dojo-attach-point=\"containerNode\"></tbody>\n            </table>\n        </div>\n    </div>\n</div>",
'epi-languagemanager/widget/command/DuplicateContent':function(){
﻿define([
// Dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/array",
    "dojo/dom-style",

    // Dojox
    "dojox/html/entities",

    // EPi Framework
    "epi/shell/command/_Command",
    "epi/shell/widget/dialog/Dialog",

    // Resource
    "epi/i18n!epi/cms/nls/languagemanager.gadget"

], function (
// Dojo
    declare,
    lang,
    array,
    domStyle,

    // Dojox
    entities,

    // EPi Framework
    _Command,
    Dialog,

    // Resource
    res
) {

    // module:
    //      "epi-languagemanager/widget/command/DuplicateContent"
    // summary:
    //      Used for selecting create language branch options for a page

    return declare([_Command], {

        label: "Duplicate {language} content",

        constructor: function (params) {
            if (params && params.model) {
                var existingLanguageBranches = array.filter(params.model.contentData.existingLanguageBranches, function (item) {
                    return params.model.currentItemData && item.languageId !== params.model.currentItemData.languageID;
                }, this);

                this.label = (existingLanguageBranches && existingLanguageBranches.length > 1) ? res.copyfrom :
                    lang.replace(res.copyfrommaster, { name: params.model.masterLanguage });
            }

            this.set("isAvailable", true);
            this.set("canExecute", true);
        },

        _onModelChange: function () {
            var existingLanguageBranches = array.filter(this.model.contentData.existingLanguageBranches, function (item) {
                return this.model.currentItemData && item.languageId !== this.model.currentItemData.languageID;
            }, this);

            this.label = (existingLanguageBranches && existingLanguageBranches.length > 1) ? res.copyfrom :
                lang.replace(res.copyfrommaster, { name: this.model.masterLanguage });
        },

        execute: function (isCreatingNew) {
            this._execute(isCreatingNew);
        },

        _execute: function (isCreatingNew) {
            // summary:
            //		Executes this command assuming canExecute has been checked. Subclasses should override this method.
            // tags:
            //		protected

            // creating a new language branch with duplicate content from master
            if (isCreatingNew === true) {
                this.model.duplicateContent();

                return;
            }

            // return if there are no existing language branches, thus there is not the master language branch
            var existingLanguageBranches = this.model.contentData.existingLanguageBranches;
            if (existingLanguageBranches.length === 0) {
                return;
            }

            // replace existing language branch with duplicate content from master
            var masterLanguageName = existingLanguageBranches.filter(function (languageBranch) {
                return languageBranch.isMasterLanguage;
            });

            // Workaround to get the master language.
            if (masterLanguageName.length === 0) {
                masterLanguageName = existingLanguageBranches;
            }

            var dialog = new Dialog({
                destroyOnHide: true,
                dialogClass: "epi-dialog-confirm",
                title: res.replacecontent,
                description: lang.replace(res.duplicatecontentconfirmation,
                    {
                        pageName: entities.encode(this.model.contentData.name),
                        toLanguage: this.model.currentItemData.name,
                        fromLanguage: masterLanguageName[0].name
                    }),
                confirmActionText: res.replacecontent
            });
            domStyle.set(dialog.domNode, { width: "450px" });

            dialog.connect(dialog, "onExecute", lang.hitch(this, function () {
                this.model.duplicateContent();
            }));

            dialog.show();
        }
    });
});

},
'epi-languagemanager/widget/command/StartBlank':function(){
﻿define([
// Dojo
    "dojo/_base/declare",
    "dojo/topic",
    // EPi Framework
    "epi-cms/command/TranslateContent",
    // Resource
    "epi/i18n!epi/cms/nls/languagemanager.gadget"
],
function (
// Dojo
    declare,
    topic,
    // EPi Framework
    TranslateContent,
    // Resource
    res
) {

    // module:
    //      "epi-languagemanager/widget/command/StartBlank"
    // summary:
    //      Used for selecting create language branch options for a page

    return declare([TranslateContent], {

        label: res.createlanguagebranch,

        _onModelChange: function () {
            // summary:
            //      Updates canExecute after the model has been updated.
            // tags:
            //      protected, extensions

            this.set("isAvailable", true);
            this.set("canExecute", true);
        },

        _getNormalizedModel: function () {
            // summary:
            //      Gets a normalized model in order to handle the different possible inputs.
            // tags:
            //      protected, extensions

            var model = this.inherited(arguments);

            if (model && !model.language) {
                model.language = {
                    preferredLanguage: this.model.currentItemData.languageID
                };
            }

            return model;
        },

        _execute: function () {
            // summary:
            //      Publishes a change view request to change to the create language branch view.
            // tags:
            //      protected
            var model = this._getNormalizedModel();

            if (typeof this.executeDelegate === "function") {
                this.executeDelegate(this.model);
            } else {
                var data = {
                    contentData: model.content,
                    languageBranch: model.language.preferredLanguage
                };

                topic.publish("/epi/shell/action/changeview", "epi-languagemanager/contentediting/editors/CreateLanguageBranch", null, data);
            }
        }

    });
});

},
'epi-languagemanager/widget/command/AutoTranslate':function(){
﻿define([
// Dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/array",
    "dojo/dom-style",

    // Dojox
    "dojox/html/entities",

    // EPi Framework
    "epi/shell/command/_Command",
    "epi/shell/widget/dialog/Dialog",

    // Resource
    "epi/i18n!epi/cms/nls/languagemanager.gadget"

], function (
// Dojo
    declare,
    lang,
    array,
    domStyle,

    // Dojox
    entities,

    // EPi Framework
    _Command,
    Dialog,

    // Resource
    res

) {

    // module:
    //      "epi-languagemanager/widget/command/AutoTranslate"
    // summary:
    //      Used for selecting create language branch options for a page

    return declare([_Command], {

        label: "Auto-translate from {language}",

        constructor: function (params) {
            if (params && params.model) {
                var existingLanguageBranches = array.filter(params.model.contentData.existingLanguageBranches, function (item) {
                    return params.model.currentItemData && item.languageId !== params.model.currentItemData.languageID;
                }, this);

                this.label = (existingLanguageBranches && existingLanguageBranches.length > 1) ? res.translateandcopyfrom :
                    lang.replace(res.translateandcopyfrommaster, { name: params.model.masterLanguage });
            }
            this.set("isAvailable", true);
            this.set("canExecute", true);
        },

        _onModelChange: function () {
            var existingLanguageBranches = array.filter(this.model.contentData.existingLanguageBranches, function (item) {
                return this.model.currentItemData && item.languageId !== this.model.currentItemData.languageID;
            }, this);

            this.label = (existingLanguageBranches && existingLanguageBranches.length > 1) ? res.translateandcopyfrom :
                lang.replace(res.translateandcopyfrommaster, { name: this.model.masterLanguage });
        },

        execute: function (isCreatingNew) {
            this._execute(isCreatingNew);
        },

        _execute: function (isCreatingNew) {
            // summary:
            //		Executes this command assuming canExecute has been checked. Subclasses should override this method.
            // tags:
            //		protected

            // creating a new language branch with auto translate from master
            if (isCreatingNew === true) {
                this.model.autoTranslate();
                return;
            }

            // return if there are no existing language branches, thus there is not the master language branch
            var existingLanguageBranches = this.model.contentData.existingLanguageBranches;
            if (existingLanguageBranches.length === 0) {
                return;
            }

            // replace existing language branch with auto translate from master
            var masterLanguageName = existingLanguageBranches.filter(function (languageBranch) {
                return languageBranch.isMasterLanguage;
            });

            // Workaround to get the master language.
            if (masterLanguageName.length === 0) {
                masterLanguageName = existingLanguageBranches;
            }

            var dialog = new Dialog({
                destroyOnHide: true,
                dialogClass: "epi-dialog-confirm",
                title: res.replacecontent,
                description: lang.replace(res.autotranslateconfirmation,
                    {
                        pageName: entities.encode(this.model.contentData.name),
                        toLanguage: this.model.currentItemData.name,
                        fromLanguage: masterLanguageName[0].name
                    }),
                confirmActionText: res.replacecontent
            });
            domStyle.set(dialog.domNode, { width: "450px" });

            dialog.connect(dialog, "onExecute", lang.hitch(this, function () {
                this.model.autoTranslate();
            }));

            dialog.show();
        }
    });
});

},
'epi-languagemanager/component/command/ReplaceLanguageBranch':function(){
﻿define([
// Dojo base
    "dojo/_base/declare",

    // Epi CMS
    "epi-cms/contentediting/ContentActionSupport",

    // Language manager
    "epi-languagemanager/component/command/_CommandWithOptions",
    "epi-languagemanager/widget/command/DuplicateContent",
    "epi-languagemanager/widget/command/AutoTranslate",

    // Resource
    "epi/i18n!epi/cms/nls/languagemanager.gadget"
],
function (
// Dojo base
    declare,

    // Epi CMS
    ContentActionSupport,

    // Language manager
    _CommandWithOptions,
    DuplicateContent,
    AutoTranslate,

    // Resource
    res
) {

    return declare([_CommandWithOptions], {

        // label: [public] String
        //      The action text of the command to be used in visual elements.
        label: res.replacecontent,

        _setupPopup: function (/*Object*/popup) {

            this.inherited(arguments);
            popup.set("headerDisplay", false);
        },

        _onModelChange: function () {
            // summary:
            //      Updates canExecute and isAvailable after the model has been updated.
            // tags:
            //      protected

            this.inherited(arguments);

            var item = this.model.currentItemData;

            if (!item) {
                this.set("canExecute", false);
                return;
            }

            var isReadonlyVersion = item.versionStatus === ContentActionSupport.versionStatus.CheckedIn
                                    || item.versionStatus === ContentActionSupport.versionStatus.DelayedPublish,
                // Do nothing (command disabled) if the content is Wastebasket or Root or has been deleted or is an unsupported type
                disabled = this.isWastebasket(this.model.contentData) || this.isRoot(this.model.contentData)
                || this.model.contentData.isDeleted || !this.isSupportedType(this.model.contentData);

            this.set("isAvailable", item.isCreated && item.canEdit && !item.isMaster && item.isActive && !isReadonlyVersion && !disabled);
            this.set("canExecute", item.isCreated && item.canEdit && !item.isMaster && item.isActive && !isReadonlyVersion && !disabled);
        },

        getSubCommands: function (model) {
            // summary:
            //      Setup sub menu items when user click to create language branch.
            // tags:
            //      private

            var isTranslatingSystemAvailable = model.isTranslatingSystemAvailable;

            var autoTranslate = new AutoTranslate({ model: model }),
                duplicateContent = new DuplicateContent({ model: model }),
                languageBranchCommands = [
                    {
                        label: autoTranslate.label,
                        value: autoTranslate,
                        disabled: isTranslatingSystemAvailable === false ? "disabled" : false
                    },
                    {
                        label: duplicateContent.label,
                        value: duplicateContent
                    }
                ];

            return languageBranchCommands;
        },
        onItemSelected: function (command) {
            // summary:
            //      Callback when a subcommand is selected
            // tags:
            //      public

            command.execute(false);
        }
    });
});

},
'epi-languagemanager/component/command/AddToTranslationProject':function(){
﻿define([
// dojo
    "dojo/_base/declare",
    "dojo/Deferred",
    "dojo/when",
    // epi
    "epi/shell/widget/dialog/Dialog",
    "epi-cms/core/ContentReference",
    "epi-cms/project/CreateNewDraftConfirmationDialog",
    "epi/dependency",
    // add-ons
    "epi-languagemanager/component/command/CommandBase",
    "epi-languagemanager/widget/AddToTranslationOptions",
    // resource
    "epi/i18n!epi/cms/nls/languagemanager"
],

function (
// dojo
    declare,
    Deferred,
    when,
    // epi
    Dialog,
    ContentReference,
    CreateNewDraftConfirmationDialog,
    dependency,
    // add-ons
    CommandBase,
    AddToTranslationOptions,
    // resource
    res
) {

    return declare([CommandBase], {

        // label: [public] String
        //      The action text of the command to be used in visual elements.
        label: res.gadget.addtotranslationproject,

        category: "context",

        // projectStore: [readonly] Store
        //      A REST store for interacting with projects.
        projectStore: null,

        constructor: function (params) {
            this.inherited(arguments);
            this.set("isAvailable", true);
            this.set("canExecute", true);
        },

        _onModelChange: function () {
            // summary:
            //      Updates canExecute and isAvailable after the model has been updated.
            // tags:
            //      protected

            var item = this.model.currentItemData;
            if (!item) {
                this.set("canExecute", false);
                this.set("isAvailable", false);
                return;
            }

            var commandAvailable = item.canActivate && item.canEdit && item.isActive;

            when(this.model.hasAnyProject()).then(function (hasProject) {
                this.set("canExecute", commandAvailable && item.isCreated && hasProject);
                this.set("isAvailable", commandAvailable);
            }.bind(this));
        },

        _execute: function () {
            // summary:
            //      Send to translation project.
            // tags:
            //      protected

            var addToTranslationOptions = new AddToTranslationOptions(),
                projectSelector = addToTranslationOptions.projectSelector,
                projectStore = this.projectStore || dependency.resolve("epi.storeregistry").get("epi.cms.project");

            projectSelector.set("store", projectStore);

            this._sendToProjectDialog = new Dialog({
                destroyOnHide: true,
                dialogClass: "epi-dialog-confirm",
                title: res.addtoproject.heading,
                description: res.addtoproject.description,
                content: addToTranslationOptions
            });

            projectSelector.watch("value", this._projectSelectorValueChanged.bind(this));

            this._sendToProjectDialog.on("execute", this._onDialogExecute.bind(this));

            this._sendToProjectDialog.show();

            this._setOkButtonEnabled(false);
        },

        _onDialogExecute: function () {
            // summary:
            //      Performs send to translation process when dialog's "execute" even fired
            // tags:
            //      private

            if (!this._sendToProjectDialog || !this._sendToProjectDialog.content) {
                return;
            }

            var def = new Deferred(),
                currentItemData = this.model.currentItemData;
            if (!this.model.currentItemData.isCreated) {
                when(this.model.duplicateContent()).then(function () {
                    def.resolve();
                }.bind(this));
            } else {
                def.resolve();
            }

            when(def).then(function () {
                var dialogContent = this._sendToProjectDialog.content,
                    projectSelector = dialogContent.projectSelector;
                if (projectSelector) {
                    var selectedProject = dialogContent.projectSelector.get("value");
                    if (selectedProject && selectedProject.id) {
                        var targetProject = selectedProject.id,
                            model = this.model;

                        //Callback method to execute when the canAddContent promise gets resolved
                        var addContent = function (result) {
                            if (result.existingProjectItems.length !== 0) {
                                var dialog = new CreateNewDraftConfirmationDialog({
                                    projectItems: result.existingProjectItems,
                                    contentReferences: result.contentReferences,
                                    onAction: function (dialogResult) {
                                        if (dialogResult) {
                                            model.addProjectItems(targetProject, result.contentReferencesToAdd, currentItemData.languageID);
                                        }
                                    }
                                });

                                dialog.show();

                            } else if (result.contentReferencesToAdd.length > 0) {
                                model.addProjectItems(targetProject, result.contentReferencesToAdd, currentItemData.languageID);
                            }
                        };

                        // 1. Get all content need to translate
                        //      - Checked all children option: Get all descendents of the content
                        //      - Checked related blocks option: Get reference to related blocks of the content (Content Area, Main Area, ...)
                        // 2. Validate the contents can be add/not.
                        //      - Display dialog to show list content has existed in other project
                        return when(model.getContentsToProject(targetProject,
                            dialogContent.addAllChildrenOption && dialogContent.addAllChildrenOption.checked,
                            dialogContent.addRelatedBlocksOption && dialogContent.addRelatedBlocksOption.checked)
                        ).then(function (contentReferences) {

                            var ids = contentReferences.map(function (item) {
                                var reference = ContentReference(item);
                                // TECH NOTE: we DONT know the version of current content when user add content to project from LM context menu,
                                // so that we send content ID and LanguageId, the ProjectStore will add the draff version of that language.
                                reference.workId = 0;

                                return reference.toString();
                            });

                            model.canAddContent(targetProject, ids).then(addContent);
                        });
                    }
                }
            }.bind(this));
        },

        _projectSelectorValueChanged: function (/*String*/propertyName, /*Object*/oldValue, /*Object*/newValue) {
            // summary:
            //      Watchs any change of the Project Selector widget.
            //      If a project selected from list, the "OK" button will be active.
            // propertyName: [String]
            //      The property that watching
            // oldValue: [Object]
            //      The previous selection data
            // newValue: [Object]
            //      The new selection data
            // tags:
            //      private

            if (!newValue) {
                return;
            }
            this._setOkButtonEnabled(true);

            var projectId = newValue.id,
                contentReference = this.model.contentData.contentLink,
                languageId = this.model.currentItemData.languageID;
            when(this.model.isContentExistingInProject(projectId, contentReference, languageId)).then(function (/*Boolean*/existing) {
                this._toggleNotification(existing);
            }.bind(this));
        },

        _toggleNotification: function (/*Boolean*/visible) {
            // summary:
            //      Toggle display of the notification bar.
            // visible: [Boolean]
            //      Flag indicate that the notification bar should display or not.
            // tags:
            //      private

            var dialogContent = this._sendToProjectDialog.content;
            if (dialogContent) {
                if (visible) {
                    (typeof dialogContent.showNotification === "function") && dialogContent.showNotification(res.addtoproject.notification.existingcontent);
                } else {
                    (typeof dialogContent.hideNotification === "function") && dialogContent.hideNotification();
                }
            }
        },

        _setOkButtonEnabled: function (enabled) {
            this._sendToProjectDialog.definitionConsumer.setItemProperty(this._sendToProjectDialog._okButtonName, "disabled", !enabled);
        }
    });

});

},
'epi-languagemanager/widget/AddToTranslationOptions':function(){
﻿define([
// dojo
    "dojo/_base/declare",
    "dojo/dom-style",
    "dojo/dom-class",
    "dojo/html",
    // dijit
    "dijit/_TemplatedMixin",
    "dijit/_Widget",
    "dijit/_WidgetsInTemplateMixin",
    // epi
    "epi/dependency",
    "epi/shell/widget/dialog/_DialogContentMixin",
    "epi-cms/project/ProjectSelector",
    // template
    "dojo/text!./templates/AddToTranslationOptions.html",
    // resources
    "epi/i18n!epi/cms/nls/languagemanager.addtoproject"
],
function (
// dojo
    declare,
    domStyle,
    domClass,
    html,
    // dijit
    _TemplatedMixin,
    _Widget,
    _WidgetsInTemplateMixin,
    // epi
    dependency,
    _DialogContentMixin,
    ProjectSelector, // used in template
    // template
    template,
    // resources
    resources
) {

    return declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin, _DialogContentMixin], {

        templateString: template,

        res: resources,

        // projectStore: [readonly] Store
        //      A REST store for interacting with projects.
        projectStore: null,

        postscript: function () {

            this.inherited(arguments);

            this.projectStore = this.projectStore || dependency.resolve("epi.storeregistry").get("epi.cms.project");
        },

        startup: function () {

            this.inherited(arguments);

            var projectSelector = this.projectSelector;

            projectSelector.set("store", this.projectStore);
        },

        showNotification: function (/*String*/message) {
            // summary:
            //      Show notification
            // message: [String]
            //      Notification message to show
            // tags:
            //      public

            html.set(this.notificationMessage, message);

            domClass.toggle(this.notificationBar, "dijitHidden", false);
        },

        hideNotification: function () {
            // summary:
            //      Hide notification
            // tags:
            //      public

            domClass.toggle(this.notificationBar, "dijitHidden", true);
        }

    });

});

},
'url:epi-languagemanager/widget/templates/AddToTranslationOptions.html':"﻿<section class=\"epi-languageManager-optionsSelector\">\n    <div class=\"epi-languageManager__notificationBar dijitHidden\" data-dojo-attach-point=\"notificationBar\">\n        <span class=\"media-list__object dijitInline dijitReset dijitIcon epi-icon--large epi-iconWarning epi-floatLeft\"></span>\n        <label class=\"epi-languageManager__notificationMessage\" data-dojo-attach-point=\"notificationMessage\"></label>\n    </div>\n    <ul class=\"option-list\">\n        <li class=\"option-list-item\">\n            <label data-dojo-attach-point=\"projectSelectorLabel\">${res.options.addtoproject}</label>\n            <span data-dojo-type=\"epi-cms/project/ProjectSelector\" data-dojo-attach-point=\"projectSelector\"></span>\n        </li>\n        <li class=\"option-list-item\">\n            <input data-dojo-attach-point=\"addAllChildrenOption\" id=\"option-addAllChildren\" data-dojo-type=\"dijit/form/CheckBox\" />\n            <label for=\"option-addAllChildren\">${res.options.addallchildren}</label>\n        </li>\n        <li class=\"option-list-item\">\n            <input data-dojo-attach-point=\"addRelatedBlocksOption\" id=\"option-addRelatedBlocks\" data-dojo-type=\"dijit/form/CheckBox\" />\n            <label for=\"option-addRelatedBlocks\">${res.options.addrelatedblocks}</label>\n        </li>\n    </ul>\n</section>",
'epi-languagemanager/component/viewmodel/LanguageManagerViewModelWrapper':function(){
﻿define([
    // dojo
    "dojo/_base/lang",
    "dojo/_base/array",

    "dojo/aspect",
    "dojo/Deferred",
    "dojo/when",

    "epi/dependency",
    "epi/shell/widget/dialog/Dialog",

    "epi-languagemanager/widget/SourceLanguageOptions",
    // resource
    "epi/i18n!epi/cms/nls/languagemanager"
],
function (
    // dojo
    lang,
    array,

    aspect,
    Deferred,
    when,

    dependency,
    Dialog,

    SourceLanguageOptions,
    // resource
    res
) {
    return function (model) {
        var showSourceLanguageSelectorDialog = function (title, confirmationMessage) {
            var deferred = new Deferred();
            var registry = dependency.resolve("epi.storeregistry"),
                lmStore = registry.get("epi-languagemanager.language-manager");

            when(lmStore.query({ contentLink: model.contentData.contentLink }), function (branches) {
                var existingLanguageBranches = array.filter(branches, function (item) {
                    return item.isCreated && model.currentItemData && item.languageID !== model.currentItemData.languageID;
                });

                when(confirmationMessage, function (message) {
                    var sourceLanguageOptions = new SourceLanguageOptions({
                        languageBranches: existingLanguageBranches,
                        isBlock: model.contentData.capabilities.isBlock
                    });
                    var dialog = new Dialog({
                        destroyOnHide: true,
                        dialogClass: "epi-dialog-confirm",
                        title: title,
                        description: message,
                        content: sourceLanguageOptions
                    });

                    dialog.on("execute", lang.hitch(this, function () {
                        deferred.resolve([
                            dialog.content.languageSources.value, 
                            dialog.content.addAllChildrenOption.checked, 
                            dialog.content.addRelatedBlocksOption.checked,
                            dialog.content.publishChildrenContent.checked
                        ]);
                    }));
                    
                    dialog.on("cancel", lang.hitch(this, function () {
                        deferred.cancel();
                    }));

                    dialog.show();
                });
            });
            return deferred;
        };

        var autoTranslate = function (originalMethod) {
            var confirmation = showSourceLanguageSelectorDialog(res.translatecontent.heading, res.translatecontent.description);

            return when(confirmation, function (selectedLanguageOptions) {
                // Call pasteItem of the model
                return originalMethod.apply(model, selectedLanguageOptions);
            }, function () {
                return false;
            });
        };

        var duplicateContent = function (originalMethod) {
            var confirmation = showSourceLanguageSelectorDialog(res.dulicatecontent.heading, res.dulicatecontent.description);

            return when(confirmation, function (selectedLanguageOptions) {
                // Call pasteItem of the model
                return originalMethod.apply(model, selectedLanguageOptions);
            }, function () {
                return false;
            });
        };

        aspect.around(model, "autoTranslate", function (originalMethod) {
            return function () {
                return autoTranslate(originalMethod, arguments);
            };
        });

        aspect.around(model, "duplicateContent", function (originalMethod) {
            return function () {
                return duplicateContent(originalMethod, arguments);
            };
        });

        return model;
    };
});
},
'epi-languagemanager/widget/SourceLanguageOptions':function(){
﻿define([
    // dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/dom-class",
    "dojo/_base/array",
    "dojo/dom-construct",
    // dijit
    "dijit/_TemplatedMixin",
    "dijit/_Widget",
    "dijit/_WidgetsInTemplateMixin",
    // epi
    "epi/shell/widget/dialog/_DialogContentMixin",
    //epi-languagemanager
    "./LanguageOption",
    // template
    "dojo/text!./templates/SourceLanguageOptions.html",
    // resources
    "epi/i18n!epi/cms/nls/languagemanager.addtoproject",
    "dijit/form/Select"
],
function (
    // dojo
    declare,
    lang,
    domClass,
    array,
    domConstruct,
    // dijit
    _TemplatedMixin,
    _Widget,
    _WidgetsInTemplateMixin,
    // epi
    _DialogContentMixin,
    //epi-languagemanager
    LanguageOption,
    // template
    template,
    // resources
    resources
) {
    return declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin, _DialogContentMixin], {

        templateString: template,

        res: resources,

        buildRendering: function () {
            this.inherited(arguments);
            domClass.toggle(this.addAllChildrenOptionContainerNode, "dijitHidden", this.isBlock);
        },

        postCreate: function () {
            this.inherited(arguments);

            this.renderListOptions();

            this.own(
                this.addAllChildrenOption.on("click", function (e) {
                    this._togglePublishChildren(!e.target.checked && !this.addRelatedBlocksOption.checked);
                }.bind(this)),

                this.addRelatedBlocksOption.on("click", function (e) {
                    this._togglePublishChildren(!e.target.checked && !this.addAllChildrenOption.checked);
                }.bind(this))
            );

        },

        renderListOptions: function () {
            if (!this.languageBranches || !this.languageBranches.length) {
                return;
            }

            var masterLangID = "";
            var languageOptions = this.languageBranches.map(function (language) {
                var itemSetting = new LanguageOption({ item: language })
                if (language.isMaster) {
                    masterLangID = language.languageID;
                }
                return { label: itemSetting.domNode.outerHTML, value: language.languageID };
            });

            this.languageSources.set("options", languageOptions);
            this.languageSources.set("value", masterLangID);
            
        },

        _togglePublishChildren: function (hide) {
            domClass.toggle(this.publishChildrenContentContainer, "dijitHidden", hide);
            if (hide) {
                this.publishChildrenContent.set("checked", false);
            }
        }
    });
});
},
'epi-languagemanager/widget/LanguageOption':function(){
﻿define([
// dojo
    "dojo/_base/declare",
    "dojo/dom-class",
    "dojo/dom-construct",
    // dijit
    "dijit/_TemplatedMixin",
    "dijit/_Widget",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/form/RadioButton",
    // template
    "dojo/text!./templates/LanguageOption.html",
    // Resources
    "epi/i18n!epi/cms/nls/languagemanager.gadget"
],
function (
// dojo
    declare,
    domClass,
    domConstruct,
    // dijit
    _TemplatedMixin,
    _Widget,
    _WidgetsInTemplateMixin,
    RadioButton, // used in template
    // template
    template,
    // Resources
    res
) {
    return declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin], {
        templateString: template,

        buildRendering: function () {
            this.inherited(arguments);
            var span = null;
            if (this.item && this.item.isMaster) {
                domClass.add(this.optionWrapper, "master");
                span = domConstruct.toDom("<span> (" + res.master + ")</span>");
                domConstruct.place(span, this.optionLabel, "last");
            }

            if (this.item && this.item.systemIconPath) {
                span = domConstruct.toDom("<span class='systemIcon' style='background-image:url(" + this.item.systemIconPath + ")'" + " ></span>");
                domConstruct.place(span, this.optionLabel, "first");
            }
        },

        postCreate: function () {
            this.inherited(arguments);
        },

        _onChanged: function (selected) {
            this.onChange(this.item, selected);
        },

        onChange: function () {

        }
    });
});

},
'url:epi-languagemanager/widget/templates/LanguageOption.html':"﻿<div class=\"language-option-list-item\" data-dojo-attach-point=\"optionWrapper\">\n    <label data-dojo-attach-point=\"optionLabel\" for=\"rdb-${item.languageID}\">${item.name}</label>\n</div>",
'url:epi-languagemanager/widget/templates/SourceLanguageOptions.html':"﻿<section class=\"epi-languageManager-optionsSelector\">\n    <div class=\"option-list\" data-dojo-attach-point=\"languageSources\" data-dojo-type=\"dijit/form/Select\" data-dojo-props=\"maxHeight:-1\"></div>\n    <div data-dojo-attach-point=\"translationContainerNode\">\n        <hr>\n        <ul class=\"translation-option-list\">\n            <li class=\"translation-option-list-item\" data-dojo-attach-point=\"addAllChildrenOptionContainerNode\">\n                <input data-dojo-attach-point=\"addAllChildrenOption\" id=\"option-addAllChildren\" data-dojo-type=\"dijit/form/CheckBox\" />\n                <label for=\"option-addAllChildren\">${res.options.addallchildren}</label>\n            </li>\n            <li class=\"translation-option-list-item\">\n                <input data-dojo-attach-point=\"addRelatedBlocksOption\" id=\"option-addRelatedBlocks\" data-dojo-type=\"dijit/form/CheckBox\" />\n                <label for=\"option-addRelatedBlocks\">${res.options.addrelatedblocks}</label>\n            </li>\n            <li class=\"translation-option-list-item dijitHidden\" data-dojo-attach-point=\"publishChildrenContentContainer\">\n                <input data-dojo-attach-point=\"publishChildrenContent\" id=\"option-publishChildrenContent\" data-dojo-type=\"dijit/form/CheckBox\" />\n                <label for=\"option-publishChildrenContent\">${res.options.publishchildrencontent}</label>\n            </li>\n        </ul>\n    </div>\n</section>",
'dijit/form/Select':function(){
require({cache:{
'url:dijit/form/templates/Select.html':"<table class=\"dijit dijitReset dijitInline dijitLeft\"\n\tdata-dojo-attach-point=\"_buttonNode,tableNode,focusNode,_popupStateNode\" cellspacing='0' cellpadding='0'\n\trole=\"listbox\" aria-haspopup=\"true\"\n\t><tbody role=\"presentation\"><tr role=\"presentation\"\n\t\t><td class=\"dijitReset dijitStretch dijitButtonContents\" role=\"presentation\"\n\t\t\t><div class=\"dijitReset dijitInputField dijitButtonText\"  data-dojo-attach-point=\"containerNode\" role=\"presentation\"></div\n\t\t\t><div class=\"dijitReset dijitValidationContainer\"\n\t\t\t\t><input class=\"dijitReset dijitInputField dijitValidationIcon dijitValidationInner\" value=\"&#935; \" type=\"text\" tabIndex=\"-1\" readonly=\"readonly\" role=\"presentation\"\n\t\t\t/></div\n\t\t\t><input type=\"hidden\" ${!nameAttrSetting} data-dojo-attach-point=\"valueNode\" value=\"${value}\" aria-hidden=\"true\"\n\t\t/></td\n\t\t><td class=\"dijitReset dijitRight dijitButtonNode dijitArrowButton dijitDownArrowButton dijitArrowButtonContainer\"\n\t\t\tdata-dojo-attach-point=\"titleNode\" role=\"presentation\"\n\t\t\t><input class=\"dijitReset dijitInputField dijitArrowButtonInner\" value=\"&#9660; \" type=\"text\" tabIndex=\"-1\" readonly=\"readonly\" role=\"presentation\"\n\t\t\t\t${_buttonInputDisabled}\n\t\t/></td\n\t></tr></tbody\n></table>\n"}});
define("dijit/form/Select", [
	"dojo/_base/array", // array.forEach
	"dojo/_base/declare", // declare
	"dojo/dom-attr", // domAttr.set
	"dojo/dom-class", // domClass.add domClass.remove domClass.toggle
	"dojo/dom-geometry", // domGeometry.setMarginBox
	"dojo/_base/event", // event.stop
	"dojo/i18n", // i18n.getLocalization
	"dojo/_base/lang", // lang.hitch
	"dojo/sniff", // has("ie")
	"./_FormSelectWidget",
	"../_HasDropDown",
	"../Menu",
	"../MenuItem",
	"../MenuSeparator",
	"../Tooltip",
	"dojo/text!./templates/Select.html",
	"dojo/i18n!./nls/validate"
], function(array, declare, domAttr, domClass, domGeometry, event, i18n, lang, has,
			_FormSelectWidget, _HasDropDown, Menu, MenuItem, MenuSeparator, Tooltip, template){

// module:
//		dijit/form/Select


var _SelectMenu = declare("dijit.form._SelectMenu", Menu, {
	// summary:
	//		An internally-used menu for dropdown that allows us a vertical scrollbar

	// Override Menu.autoFocus setting so that opening a Select highlights the current value.
	autoFocus: true,

	buildRendering: function(){
		// summary:
		//		Stub in our own changes, so that our domNode is not a table
		//		otherwise, we won't respond correctly to heights/overflows
		this.inherited(arguments);
		var o = (this.menuTableNode = this.domNode);
		var n = (this.domNode = this.ownerDocument.createElement("div"));
		n.style.cssText = "overflow-x: hidden; overflow-y: scroll";
		if(o.parentNode){
			o.parentNode.replaceChild(n, o);
		}
		domClass.remove(o, "dijitMenuTable");
		n.className = o.className + " dijitSelectMenu";
		o.className = "dijitReset dijitMenuTable";
		n.setAttribute("role", "listbox");
		o.setAttribute("role", "presentation");
		n.appendChild(o);
	},

	postCreate: function(){
		// summary:
		//		stop mousemove from selecting text on IE to be consistent with other browsers

		this.inherited(arguments);

		this.connect(this.domNode, "onselectstart", event.stop);
	},


	focus: function(){
		// summary:
		//		Overridden so that the previously selected value will be focused instead of only the first item
		var	found = false,
			val = this.parentWidget.value;
		if(lang.isArray(val)){
			val = val[val.length-1];
		}
		if(val){ // if focus selected
			array.forEach(this.parentWidget._getChildren(), function(child){
				if(child.option && (val === child.option.value)){ // find menu item widget with this value
					found = true;
					this.focusChild(child, false); // focus previous selection
				}
			}, this);
		}
		if(!found){
			this.inherited(arguments); // focus first item by default
		}
	},

	resize: function(/*Object*/ mb){
		// summary:
		//		Overridden so that we are able to handle resizing our
		//		internal widget.  Note that this is not a "full" resize
		//		implementation - it only works correctly if you pass it a
		//		marginBox.
		//
		// mb: Object
		//		The margin box to set this dropdown to.
		if(mb){
			domGeometry.setMarginBox(this.domNode, mb);
			if("w" in mb){
				// We've explicitly set the wrapper <div>'s width, so set <table> width to match.
				// 100% is safer than a pixel value because there may be a scroll bar with
				// browser/OS specific width.
				this.menuTableNode.style.width = "100%";
			}
		}
	}
});

var Select = declare("dijit.form.Select", [_FormSelectWidget, _HasDropDown], {
	// summary:
	//		This is a "styleable" select box - it is basically a DropDownButton which
	//		can take a `<select>` as its input.

	baseClass: "dijitSelect dijitValidationTextBox",

	templateString: template,

	_buttonInputDisabled: has("ie") ? "disabled" : "", // allows IE to disallow focus, but Firefox cannot be disabled for mousedown events

	// required: Boolean
	//		Can be true or false, default is false.
	required: false,

	// state: [readonly] String
	//		"Incomplete" if this select is required but unset (i.e. blank value), "" otherwise
	state: "",

	// message: String
	//		Currently displayed error/prompt message
	message: "",

	// tooltipPosition: String[]
	//		See description of `dijit/Tooltip.defaultPosition` for details on this parameter.
	tooltipPosition: [],

	// emptyLabel: string
	//		What to display in an "empty" dropdown
	emptyLabel: "&#160;",	// &nbsp;

	// _isLoaded: Boolean
	//		Whether or not we have been loaded
	_isLoaded: false,

	// _childrenLoaded: Boolean
	//		Whether or not our children have been loaded
	_childrenLoaded: false,

	_fillContent: function(){
		// summary:
		//		Set the value to be the first, or the selected index
		this.inherited(arguments);
		// set value from selected option
		if(this.options.length && !this.value && this.srcNodeRef){
			var si = this.srcNodeRef.selectedIndex || 0; // || 0 needed for when srcNodeRef is not a SELECT
			this.value = this.options[si >= 0 ? si : 0].value;
		}
		// Create the dropDown widget
		this.dropDown = new _SelectMenu({ id: this.id + "_menu", parentWidget: this });
		domClass.add(this.dropDown.domNode, this.baseClass.replace(/\s+|$/g, "Menu "));
	},

	_getMenuItemForOption: function(/*_FormSelectWidget.__SelectOption*/ option){
		// summary:
		//		For the given option, return the menu item that should be
		//		used to display it.  This can be overridden as needed
		if(!option.value && !option.label){
			// We are a separator (no label set for it)
			return new MenuSeparator({ownerDocument: this.ownerDocument});
		}else{
			// Just a regular menu option
			var click = lang.hitch(this, "_setValueAttr", option);
			var item = new MenuItem({
				option: option,
				label: option.label || this.emptyLabel,
				onClick: click,
				ownerDocument: this.ownerDocument,
				dir: this.dir,
				disabled: option.disabled || false
			});
			item.focusNode.setAttribute("role", "option");
			return item;
		}
	},

	_addOptionItem: function(/*_FormSelectWidget.__SelectOption*/ option){
		// summary:
		//		For the given option, add an option to our dropdown.
		//		If the option doesn't have a value, then a separator is added
		//		in that place.
		if(this.dropDown){
			this.dropDown.addChild(this._getMenuItemForOption(option));
		}
	},

	_getChildren: function(){
		if(!this.dropDown){
			return [];
		}
		return this.dropDown.getChildren();
	},

	_loadChildren: function(/*Boolean*/ loadMenuItems){
		// summary:
		//		Resets the menu and the length attribute of the button - and
		//		ensures that the label is appropriately set.
		// loadMenuItems: Boolean
		//		actually loads the child menu items - we only do this when we are
		//		populating for showing the dropdown.

		if(loadMenuItems === true){
			// this.inherited destroys this.dropDown's child widgets (MenuItems).
			// Avoid this.dropDown (Menu widget) having a pointer to a destroyed widget (which will cause
			// issues later in _setSelected). (see #10296)
			if(this.dropDown){
				delete this.dropDown.focusedChild;
			}
			if(this.options.length){
				this.inherited(arguments);
			}else{
				// Drop down menu is blank but add one blank entry just so something appears on the screen
				// to let users know that they are no choices (mimicing native select behavior)
				array.forEach(this._getChildren(), function(child){ child.destroyRecursive(); });
				var item = new MenuItem({
					ownerDocument: this.ownerDocument,
					label: this.emptyLabel
				});
				this.dropDown.addChild(item);
			}
		}else{
			this._updateSelection();
		}

		this._isLoaded = false;
		this._childrenLoaded = true;

		if(!this._loadingStore){
			// Don't call this if we are loading - since we will handle it later
			this._setValueAttr(this.value, false);
		}
	},

	_refreshState: function(){
		if(this._started){
			this.validate(this.focused);
		}
	},

	startup: function(){
		this.inherited(arguments);
		this._refreshState(); // after all _set* methods have run
	},

	_setValueAttr: function(value){
		this.inherited(arguments);
		domAttr.set(this.valueNode, "value", this.get("value"));
		this._refreshState();	// to update this.state
	},

	_setDisabledAttr: function(/*Boolean*/ value){
		this.inherited(arguments);
		this._refreshState();	// to update this.state
	},

	_setRequiredAttr: function(/*Boolean*/ value){
		this._set("required", value);
		this.focusNode.setAttribute("aria-required", value);
		this._refreshState();	// to update this.state
	},

	_setOptionsAttr: function(/*Array*/ options){
		this._isLoaded = false;
		this._set('options', options);
	},

	_setDisplay: function(/*String*/ newDisplay){
		// summary:
		//		sets the display for the given value (or values)
		var lbl = newDisplay || this.emptyLabel;
		this.containerNode.innerHTML = '<span role="option" class="dijitReset dijitInline ' + this.baseClass.replace(/\s+|$/g, "Label ")+'">' + lbl + '</span>';
	},

	validate: function(/*Boolean*/ isFocused){
		// summary:
		//		Called by oninit, onblur, and onkeypress, and whenever required/disabled state changes
		// description:
		//		Show missing or invalid messages if appropriate, and highlight textbox field.
		//		Used when a select is initially set to no value and the user is required to
		//		set the value.

		var isValid = this.disabled || this.isValid(isFocused);
		this._set("state", isValid ? "" : (this._hasBeenBlurred ? "Error" : "Incomplete"));
		this.focusNode.setAttribute("aria-invalid", isValid ? "false" : "true");
		var message = isValid ? "" : this._missingMsg;
		if(message && this.focused && this._hasBeenBlurred){
			Tooltip.show(message, this.domNode, this.tooltipPosition, !this.isLeftToRight());
		}else{
			Tooltip.hide(this.domNode);
		}
		this._set("message", message);
		return isValid;
	},

	isValid: function(/*Boolean*/ /*===== isFocused =====*/){
		// summary:
		//		Whether or not this is a valid value.  The only way a Select
		//		can be invalid is when it's required but nothing is selected.
		return (!this.required || this.value === 0 || !(/^\s*$/.test(this.value || ""))); // handle value is null or undefined
	},

	reset: function(){
		// summary:
		//		Overridden so that the state will be cleared.
		this.inherited(arguments);
		Tooltip.hide(this.domNode);
		this._refreshState();	// to update this.state
	},

	postMixInProperties: function(){
		// summary:
		//		set the missing message
		this.inherited(arguments);
		this._missingMsg = i18n.getLocalization("dijit.form", "validate", this.lang).missingMessage;
	},

	postCreate: function(){
		// summary:
		//		stop mousemove from selecting text on IE to be consistent with other browsers

		this.inherited(arguments);
 
		this.connect(this.domNode, "onselectstart", event.stop);
		this.domNode.setAttribute("aria-expanded", "false");
	},

	_setStyleAttr: function(/*String||Object*/ value){
		this.inherited(arguments);
		domClass.toggle(this.domNode, this.baseClass.replace(/\s+|$/g, "FixedWidth "), !!this.domNode.style.width);
	},

	isLoaded: function(){
		return this._isLoaded;
	},

	loadDropDown: function(/*Function*/ loadCallback){
		// summary:
		//		populates the menu
		this._loadChildren(true);
		this._isLoaded = true;
		loadCallback();
	},

	closeDropDown: function(){
		// overriding _HasDropDown.closeDropDown()
		this.inherited(arguments);

		if(this.dropDown && this.dropDown.menuTableNode){
			// Erase possible width: 100% setting from _SelectMenu.resize().
			// Leaving it would interfere with the next openDropDown() call, which
			// queries the natural size of the drop down.
			this.dropDown.menuTableNode.style.width = "";
		}
	},

	destroy: function(preserveDom){
		if(this.dropDown && !this.dropDown._destroyed){
			this.dropDown.destroyRecursive(preserveDom);
			delete this.dropDown;
		}
		this.inherited(arguments);
	},

	_onFocus: function(){
		this.validate(true);	// show tooltip if second focus of required tooltip, but no selection
		this.inherited(arguments);
	},

	_onBlur: function(){
		Tooltip.hide(this.domNode);
		this.inherited(arguments);
		this.validate(false);
	}
});

Select._Menu = _SelectMenu;	// for monkey patching

return Select;
});

},
'dijit/form/_FormSelectWidget':function(){
define("dijit/form/_FormSelectWidget", [
	"dojo/_base/array", // array.filter array.forEach array.map array.some
	"dojo/_base/Deferred",
	"dojo/aspect", // aspect.after
	"dojo/data/util/sorter", // util.sorter.createSortFunction
	"dojo/_base/declare", // declare
	"dojo/dom", // dom.setSelectable
	"dojo/dom-class", // domClass.toggle
	"dojo/_base/kernel",	// _scopeName
	"dojo/_base/lang", // lang.delegate lang.isArray lang.isObject lang.hitch
	"dojo/query", // query
	"dojo/when",
	"dojo/store/util/QueryResults",
	"./_FormValueWidget"
], function(array, Deferred, aspect, sorter, declare, dom, domClass, kernel, lang, query, when,
			QueryResults, _FormValueWidget){

// module:
//		dijit/form/_FormSelectWidget

/*=====
var __SelectOption = {
	// value: String
	//		The value of the option.  Setting to empty (or missing) will
	//		place a separator at that location
	// label: String
	//		The label for our option.  It can contain html tags.
	// selected: Boolean
	//		Whether or not we are a selected option
	// disabled: Boolean
	//		Whether or not this specific option is disabled
};
=====*/

var _FormSelectWidget = declare("dijit.form._FormSelectWidget", _FormValueWidget, {
	// summary:
	//		Extends _FormValueWidget in order to provide "select-specific"
	//		values - i.e., those values that are unique to `<select>` elements.
	//		This also provides the mechanism for reading the elements from
	//		a store, if desired.

	// multiple: [const] Boolean
	//		Whether or not we are multi-valued
	multiple: false,

	// options: __SelectOption[]
	//		The set of options for our select item.  Roughly corresponds to
	//		the html `<option>` tag.
	options: null,

	// store: dojo/store/api/Store
	//		A store to use for getting our list of options - rather than reading them
	//		from the `<option>` html tags.   Should support getIdentity().
	//		For back-compat store can also be a dojo/data/api/Identity.
	store: null,

	// query: object
	//		A query to use when fetching items from our store
	query: null,

	// queryOptions: object
	//		Query options to use when fetching from the store
	queryOptions: null,

	// labelAttr: String?
	//		The entries in the drop down list come from this attribute in the dojo.store items.
	//		If ``store`` is set, labelAttr must be set too, unless store is an old-style
	//		dojo.data store rather than a new dojo/store.
	labelAttr: "",

	// onFetch: Function
	//		A callback to do with an onFetch - but before any items are actually
	//		iterated over (i.e. to filter even further what you want to add)
	onFetch: null,

	// sortByLabel: Boolean
	//		Flag to sort the options returned from a store by the label of
	//		the store.
	sortByLabel: true,


	// loadChildrenOnOpen: Boolean
	//		By default loadChildren is called when the items are fetched from the
	//		store.  This property allows delaying loadChildren (and the creation
	//		of the options/menuitems) until the user clicks the button to open the
	//		dropdown.
	loadChildrenOnOpen: false,

	// onLoadDeferred: [readonly] dojo.Deferred
	//		This is the `dojo.Deferred` returned by setStore().
	//		Calling onLoadDeferred.then() registers your
	//		callback to be called only once, when the prior setStore completes.
	onLoadDeferred: null,

	getOptions: function(/*anything*/ valueOrIdx){
		// summary:
		//		Returns a given option (or options).
		// valueOrIdx:
		//		If passed in as a string, that string is used to look up the option
		//		in the array of options - based on the value property.
		//		(See dijit/form/_FormSelectWidget.__SelectOption).
		//
		//		If passed in a number, then the option with the given index (0-based)
		//		within this select will be returned.
		//
		//		If passed in a dijit/form/_FormSelectWidget.__SelectOption, the same option will be
		//		returned if and only if it exists within this select.
		//
		//		If passed an array, then an array will be returned with each element
		//		in the array being looked up.
		//
		//		If not passed a value, then all options will be returned
		//
		// returns:
		//		The option corresponding with the given value or index.
		//		null is returned if any of the following are true:
		//
		//		- A string value is passed in which doesn't exist
		//		- An index is passed in which is outside the bounds of the array of options
		//		- A dijit/form/_FormSelectWidget.__SelectOption is passed in which is not a part of the select

		// NOTE: the compare for passing in a dijit/form/_FormSelectWidget.__SelectOption checks
		//		if the value property matches - NOT if the exact option exists
		// NOTE: if passing in an array, null elements will be placed in the returned
		//		array when a value is not found.
		var opts = this.options || [];

		if(valueOrIdx == null){
			return opts; // __SelectOption[]
		}
		if(lang.isArray(valueOrIdx)){
			return array.map(valueOrIdx, "return this.getOptions(item);", this); // __SelectOption[]
		}
		if(lang.isString(valueOrIdx)){
			valueOrIdx = { value: valueOrIdx };
		}
		if(lang.isObject(valueOrIdx)){
			// We were passed an option - so see if it's in our array (directly),
			// and if it's not, try and find it by value.

			if(!array.some(opts, function(option, idx){
				for(var a in valueOrIdx){
					if(!(a in option) || option[a] != valueOrIdx[a]){ // == and not === so that 100 matches '100'
						return false;
					}
				}
				valueOrIdx = idx;
				return true; // stops iteration through opts
			})){
				valueOrIdx = -1;
			}
		}
		if(valueOrIdx >= 0 && valueOrIdx < opts.length){
			return opts[valueOrIdx]; // __SelectOption
		}
		return null; // null
	},

	addOption: function(/*__SelectOption|__SelectOption[]*/ option){
		// summary:
		//		Adds an option or options to the end of the select.  If value
		//		of the option is empty or missing, a separator is created instead.
		//		Passing in an array of options will yield slightly better performance
		//		since the children are only loaded once.
		array.forEach(lang.isArray(option) ? option : [option], function(i){
			if(i && lang.isObject(i)){
				this.options.push(i);
			}
		}, this);
		this._loadChildren();
	},

	removeOption: function(/*String|__SelectOption|Number|Array*/ valueOrIdx){
		// summary:
		//		Removes the given option or options.  You can remove by string
		//		(in which case the value is removed), number (in which case the
		//		index in the options array is removed), or select option (in
		//		which case, the select option with a matching value is removed).
		//		You can also pass in an array of those values for a slightly
		//		better performance since the children are only loaded once.
		//		For numeric option values, specify {value: number} as the argument.
		var oldOpts = this.getOptions(lang.isArray(valueOrIdx) ? valueOrIdx : [valueOrIdx]);
		array.forEach(oldOpts, function(option){
			// We can get null back in our array - if our option was not found.  In
			// that case, we don't want to blow up...
			if(option){
				this.options = array.filter(this.options, function(node){
					return (node.value !== option.value || node.label !== option.label);
				});
				this._removeOptionItem(option);
			}
		}, this);
		this._loadChildren();
	},

	updateOption: function(/*__SelectOption|__SelectOption[]*/ newOption){
		// summary:
		//		Updates the values of the given option.  The option to update
		//		is matched based on the value of the entered option.  Passing
		//		in an array of new options will yield better performance since
		//		the children will only be loaded once.
		array.forEach(lang.isArray(newOption) ? newOption : [newOption], function(i){
			var oldOpt = this.getOptions({ value: i.value }), k;
			if(oldOpt){
				for(k in i){ oldOpt[k] = i[k]; }
			}
		}, this);
		this._loadChildren();
	},

	setStore: function(store, selectedValue, fetchArgs){
		// summary:
		//		Sets the store you would like to use with this select widget.
		//		The selected value is the value of the new store to set.  This
		//		function returns the original store, in case you want to reuse
		//		it or something.
		// store: dojo/store/api/Store
		//		The dojo.store you would like to use - it MUST implement getIdentity()
		//		and MAY implement observe().
		//		For backwards-compatibility this can also be a data.data store, in which case
		//		it MUST implement dojo/data/api/Identity,
		//		and MAY implement dojo/data/api/Notification.
		// selectedValue: anything?
		//		The value that this widget should set itself to *after* the store
		//		has been loaded
		// fetchArgs: Object?
		//		Hash of parameters to set filter on store, etc.
		//
		//		- query: new value for Select.query,
		//		- queryOptions: new value for Select.queryOptions,
		//		- onFetch: callback function for each item in data (Deprecated)
		var oStore = this.store;
		fetchArgs = fetchArgs || {};

		if(oStore !== store){
			// Our store has changed, so cancel any listeners on old store (remove for 2.0)
			var h;
			while((h = this._notifyConnections.pop())){ h.remove(); }

			// For backwards-compatibility, accept dojo.data store in addition to dojo.store.store.  Remove in 2.0.
			if(!store.get){
				lang.mixin(store, {
					_oldAPI: true,
					get: function(id){
						// summary:
						//		Retrieves an object by it's identity. This will trigger a fetchItemByIdentity.
						//		Like dojo.store.DataStore.get() except returns native item.
						var deferred = new Deferred();
						this.fetchItemByIdentity({
							identity: id,
							onItem: function(object){
								deferred.resolve(object);
							},
							onError: function(error){
								deferred.reject(error);
							}
						});
						return deferred.promise;
					},
					query: function(query, options){
						// summary:
						//		Queries the store for objects.   Like dojo/store/DataStore.query()
						//		except returned Deferred contains array of native items.
						var deferred = new Deferred(function(){ if(fetchHandle.abort){ fetchHandle.abort(); } } );
						deferred.total = new Deferred();
						var fetchHandle = this.fetch(lang.mixin({
							query: query,
							onBegin: function(count){
								deferred.total.resolve(count);
							},
							onComplete: function(results){
								deferred.resolve(results);
							},
							onError: function(error){
								deferred.reject(error);
							}
						}, options));
						return new QueryResults(deferred);
					}
				});

				if(store.getFeatures()["dojo.data.api.Notification"]){
					this._notifyConnections = [
						aspect.after(store, "onNew", lang.hitch(this, "_onNewItem"), true),
						aspect.after(store, "onDelete", lang.hitch(this, "_onDeleteItem"), true),
						aspect.after(store, "onSet", lang.hitch(this, "_onSetItem"), true)
					];
				}
			}
			this._set("store", store);			// Our store has changed, so update our notifications
		}

		// Remove existing options (if there are any)
		if(this.options && this.options.length){
			this.removeOption(this.options);
		}

			// Cancel listener for updates to old (dojo.data) store
		if(this._queryRes && this._queryRes.close){
			this._queryRes.close();
		}
			
			// Cancel listener for updates to new (dojo.store) store
			if(this._observeHandle && this._observeHandle.remove){
				this._observeHandle.remove();
				this._observeHandle = null;
			}

		// If user has specified new query and query options along with this new store, then use them.
		if(fetchArgs.query){
			this._set("query", fetchArgs.query);
			this._set("queryOptions", fetchArgs.queryOptions);
		}

		// Add our new options
		if(store){
			this._loadingStore = true;
			this.onLoadDeferred = new Deferred();

			// Run query
			// Save result in this._queryRes so we can cancel the listeners we register below
			this._queryRes = store.query(this.query, this.queryOptions);
			when(this._queryRes, lang.hitch(this, function(items){

				if(this.sortByLabel && !fetchArgs.sort && items.length){
					if(store.getValue){
						// Old dojo.data API to access items, remove for 2.0
						items.sort(sorter.createSortFunction([{
							attribute: store.getLabelAttributes(items[0])[0]
						}], store));
					}else{
						var labelAttr = this.labelAttr;
						items.sort(function(a, b){
							return a[labelAttr] > b[labelAttr] ? 1 :  b[labelAttr] > a[labelAttr] ? -1 : 0;
						});
					}
				}

				if(fetchArgs.onFetch){
						items = fetchArgs.onFetch.call(this, items, fetchArgs);
				}

				// TODO: Add these guys as a batch, instead of separately
				array.forEach(items, function(i){
					this._addOptionForItem(i);
				}, this);

				// Register listener for store updates
				if(this._queryRes.observe){
						// observe returns yet another handle that needs its own explicit gc
						this._observeHandle = this._queryRes.observe(lang.hitch(this, function(object, deletedFrom, insertedInto){
						if(deletedFrom == insertedInto){
							this._onSetItem(object);
						}else{
							if(deletedFrom != -1){
								this._onDeleteItem(object);
							}
							if(insertedInto != -1){
								this._onNewItem(object);
							}
						}
					}), true);
				}

				// Set our value (which might be undefined), and then tweak
				// it to send a change event with the real value
				this._loadingStore = false;
				this.set("value", "_pendingValue" in this ? this._pendingValue : selectedValue);
				delete this._pendingValue;

				if(!this.loadChildrenOnOpen){
					this._loadChildren();
				}else{
					this._pseudoLoadChildren(items);
				}
				this.onLoadDeferred.resolve(true);
				this.onSetStore();
			}), function(err){
					console.error('dijit.form.Select: ' + err.toString());
					this.onLoadDeferred.reject(err);
			});
		}
		return oStore;	// dojo/data/api/Identity
	},

	// TODO: implement set() and watch() for store and query, although not sure how to handle
	// setting them individually rather than together (as in setStore() above)

	_setValueAttr: function(/*anything*/ newValue, /*Boolean?*/ priorityChange){
		// summary:
		//		set the value of the widget.
		//		If a string is passed, then we set our value from looking it up.
		if(!this._onChangeActive){ priorityChange = null; }
		if(this._loadingStore){
			// Our store is loading - so save our value, and we'll set it when
			// we're done
			this._pendingValue = newValue;
			return;
		}
		if(newValue == null){
			return;
		}
		if(lang.isArray(newValue)){
			newValue = array.map(newValue, function(value){ return lang.isObject(value) ? value : { value: value }; }); // __SelectOption[]
		}else if(lang.isObject(newValue)){
			newValue = [newValue];
		}else{
			newValue = [{ value: newValue }];
		}
		newValue = array.filter(this.getOptions(newValue), function(i){ return i && i.value; });
		var opts = this.getOptions() || [];
		if(!this.multiple && (!newValue[0] || !newValue[0].value) && !!opts.length){
			newValue[0] = opts[0];
		}
		array.forEach(opts, function(opt){
			opt.selected = array.some(newValue, function(v){ return v.value === opt.value; });
		});
		var val = array.map(newValue, function(opt){ return opt.value; });

		if(typeof val == "undefined" || typeof val[0] == "undefined"){ return; } // not fully initialized yet or a failed value lookup
		var disp = array.map(newValue, function(opt){ return opt.label; });
		this._setDisplay(this.multiple ? disp : disp[0]);
		this.inherited(arguments, [ this.multiple ? val : val[0], priorityChange ]);
		this._updateSelection();
	},

	_getDisplayedValueAttr: function(){
		// summary:
		//		returns the displayed value of the widget
		var ret = array.map([].concat(this.get('selectedOptions')), function(v){
			if(v && "label" in v){
				return v.label;
			}else if(v){
				return v.value;
			}
			return null;
		}, this);
		return this.multiple ? ret : ret[0];
	},

	_setDisplayedValueAttr: function(label){
		// summary:
		//		Sets the displayed value of the widget
		this.set('value', this.getOptions(typeof label == "string" ? { label: label } : label));
	},

	_loadChildren: function(){
		// summary:
		//		Loads the children represented by this widget's options.
		//		reset the menu to make it populatable on the next click
		if(this._loadingStore){ return; }
		array.forEach(this._getChildren(), function(child){
			child.destroyRecursive();
		});
		// Add each menu item
		array.forEach(this.options, this._addOptionItem, this);

		// Update states
		this._updateSelection();
	},

	_updateSelection: function(){
		// summary:
		//		Sets the "selected" class on the item for styling purposes
		this._set("value", this._getValueFromOpts());
		var val = [].concat(this.value);
		if(val && val[0]){
			array.forEach(this._getChildren(), function(child){
				var isSelected = array.some(val, function(v){
					return child.option && (v === child.option.value);
				});
				domClass.toggle(child.domNode, this.baseClass.replace(/\s+|$/g, "SelectedOption "), isSelected);
				child.domNode.setAttribute("aria-selected", isSelected ? "true" : "false");
			}, this);
		}
	},

	_getValueFromOpts: function(){
		// summary:
		//		Returns the value of the widget by reading the options for
		//		the selected flag
		var opts = this.getOptions() || [];
		if(!this.multiple && opts.length){
			// Mirror what a select does - choose the first one
			var opt = array.filter(opts, function(i){
				return i.selected;
			})[0];
			if(opt && opt.value){
				return opt.value;
			}else{
				opts[0].selected = true;
				return opts[0].value;
			}
		}else if(this.multiple){
			// Set value to be the sum of all selected
			return array.map(array.filter(opts, function(i){
				return i.selected;
			}), function(i){
				return i.value;
			}) || [];
		}
		return "";
	},

	// Internal functions to call when we have store notifications come in
	_onNewItem: function(/*item*/ item, /*Object?*/ parentInfo){
		if(!parentInfo || !parentInfo.parent){
			// Only add it if we are top-level
			this._addOptionForItem(item);
		}
	},
	_onDeleteItem: function(/*item*/ item){
		var store = this.store;
		this.removeOption({value: store.getIdentity(item) });
	},
	_onSetItem: function(/*item*/ item){
		this.updateOption(this._getOptionObjForItem(item));
	},

	_getOptionObjForItem: function(item){
		// summary:
		//		Returns an option object based off the given item.  The "value"
		//		of the option item will be the identity of the item, the "label"
		//		of the option will be the label of the item.

		// remove getLabel() call for 2.0 (it's to support the old dojo.data API)
		var store = this.store,
			label = (this.labelAttr && this.labelAttr in item) ? item[this.labelAttr] : store.getLabel(item),
			value = (label ? store.getIdentity(item) : null);
		return {value: value, label: label, item: item}; // __SelectOption
	},

	_addOptionForItem: function(/*item*/ item){
		// summary:
		//		Creates (and adds) the option for the given item
		var store = this.store;
		if(store.isItemLoaded && !store.isItemLoaded(item)){
			// We are not loaded - so let's load it and add later.
			// Remove for 2.0 (it's the old dojo.data API)
			store.loadItem({item: item, onItem: function(i){
				this._addOptionForItem(i);
			},
			scope: this});
			return;
		}
		var newOpt = this._getOptionObjForItem(item);
		this.addOption(newOpt);
	},

	constructor: function(params /*===== , srcNodeRef =====*/){
		// summary:
		//		Create the widget.
		// params: Object|null
		//		Hash of initialization parameters for widget, including scalar values (like title, duration etc.)
		//		and functions, typically callbacks like onClick.
		//		The hash can contain any of the widget's properties, excluding read-only properties.
		// srcNodeRef: DOMNode|String?
		//		If a srcNodeRef (DOM node) is specified, replace srcNodeRef with my generated DOM tree

		//		Saves off our value, if we have an initial one set so we
		//		can use it if we have a store as well (see startup())
		this._oValue = (params || {}).value || null;
		this._notifyConnections = [];	// remove for 2.0
	},

	buildRendering: function(){
		this.inherited(arguments);
		dom.setSelectable(this.focusNode, false);
	},

	_fillContent: function(){
		// summary:
		//		Loads our options and sets up our dropdown correctly.  We
		//		don't want any content, so we don't call any inherit chain
		//		function.
		if(!this.options){
			this.options =
				this.srcNodeRef
				? query("> *", this.srcNodeRef).map(
					function(node){
						if(node.getAttribute("type") === "separator"){
							return { value: "", label: "", selected: false, disabled: false };
						}
						return {
							value: (node.getAttribute("data-" + kernel._scopeName + "-value") || node.getAttribute("value")),
							label: String(node.innerHTML),
							// FIXME: disabled and selected are not valid on complex markup children (which is why we're
							// looking for data-dojo-value above.  perhaps we should data-dojo-props="" this whole thing?)
							// decide before 1.6
							selected: node.getAttribute("selected") || false,
							disabled: node.getAttribute("disabled") || false
						};
					},
					this)
				: [];
		}
		if(!this.value){
			this._set("value", this._getValueFromOpts());
		}else if(this.multiple && typeof this.value == "string"){
			this._set("value", this.value.split(","));
		}
	},

	postCreate: function(){
		// summary:
		//		sets up our event handling that we need for functioning
		//		as a select
		this.inherited(arguments);

		// Make our event connections for updating state
		aspect.after(this, "onChange", lang.hitch(this, "_updateSelection"));

		// moved from startup
		//		Connects in our store, if we have one defined
		var store = this.store;
		if(store && (store.getIdentity || store.getFeatures()["dojo.data.api.Identity"])){
			// Temporarily set our store to null so that it will get set
			// and connected appropriately
			this.store = null;
			this.setStore(store, this._oValue);
		}
	},

	startup: function(){
		// summary:
		this._loadChildren();
		this.inherited(arguments);
	},

	destroy: function(){
		// summary:
		//		Clean up our connections

		var h;
		while((h = this._notifyConnections.pop())){ h.remove(); }

		// Cancel listener for store updates
		if(this._queryRes && this._queryRes.close){
			this._queryRes.close();
			}

			// Cancel listener for updates to new (dojo.store) store
			if(this._observeHandle && this._observeHandle.remove){
				this._observeHandle.remove();
				this._observeHandle = null;
		}

		this.inherited(arguments);
	},

	_addOptionItem: function(/*__SelectOption*/ /*===== option =====*/){
		// summary:
		//		User-overridable function which, for the given option, adds an
		//		item to the select.  If the option doesn't have a value, then a
		//		separator is added in that place.  Make sure to store the option
		//		in the created option widget.
	},

	_removeOptionItem: function(/*__SelectOption*/ /*===== option =====*/){
		// summary:
		//		User-overridable function which, for the given option, removes
		//		its item from the select.
	},

	_setDisplay: function(/*String or String[]*/ /*===== newDisplay =====*/){
		// summary:
		//		Overridable function which will set the display for the
		//		widget.  newDisplay is either a string (in the case of
		//		single selects) or array of strings (in the case of multi-selects)
	},

	_getChildren: function(){
		// summary:
		//		Overridable function to return the children that this widget contains.
		return [];
	},

	_getSelectedOptionsAttr: function(){
		// summary:
		//		hooks into this.attr to provide a mechanism for getting the
		//		option items for the current value of the widget.
		return this.getOptions({ selected: true });
	},

	_pseudoLoadChildren: function(/*item[]*/ /*===== items =====*/){
		// summary:
		//		a function that will "fake" loading children, if needed, and
		//		if we have set to not load children until the widget opens.
		// items:
		//		An array of items that will be loaded, when needed
	},

	onSetStore: function(){
		// summary:
		//		a function that can be connected to in order to receive a
		//		notification that the store has finished loading and all options
		//		from that store are available
	}
});

/*=====
_FormSelectWidget.__SelectOption = __SelectOption;
=====*/

return _FormSelectWidget;

});

},
'dojo/data/util/sorter':function(){
define("dojo/data/util/sorter", ["../../_base/lang"], function(lang){
	// module:
	//		dojo/data/util/sorter
	// summary:
	//		TODOC

var sorter = {};
lang.setObject("dojo.data.util.sorter", sorter);

sorter.basicComparator = function(	/*anything*/ a,
													/*anything*/ b){
	// summary:
	//		Basic comparison function that compares if an item is greater or less than another item
	// description:
	//		returns 1 if a > b, -1 if a < b, 0 if equal.
	//		'null' values (null, undefined) are treated as larger values so that they're pushed to the end of the list.
	//		And compared to each other, null is equivalent to undefined.

	//null is a problematic compare, so if null, we set to undefined.
	//Makes the check logic simple, compact, and consistent
	//And (null == undefined) === true, so the check later against null
	//works for undefined and is less bytes.
	var r = -1;
	if(a === null){
		a = undefined;
	}
	if(b === null){
		b = undefined;
	}
	if(a == b){
		r = 0;
	}else if(a > b || a == null){
		r = 1;
	}
	return r; //int {-1,0,1}
};

sorter.createSortFunction = function(	/* attributes[] */sortSpec, /*dojo/data/api/Read*/ store){
	// summary:
	//		Helper function to generate the sorting function based off the list of sort attributes.
	// description:
	//		The sort function creation will look for a property on the store called 'comparatorMap'.  If it exists
	//		it will look in the mapping for comparisons function for the attributes.  If one is found, it will
	//		use it instead of the basic comparator, which is typically used for strings, ints, booleans, and dates.
	//		Returns the sorting function for this particular list of attributes and sorting directions.
	// sortSpec:
	//		A JS object that array that defines out what attribute names to sort on and whether it should be descenting or asending.
	//		The objects should be formatted as follows:
	// |	{
	// |		attribute: "attributeName-string" || attribute,
	// |		descending: true|false;   // Default is false.
	// |	}
	// store:
	//		The datastore object to look up item values from.

	var sortFunctions=[];

	function createSortFunction(attr, dir, comp, s){
		//Passing in comp and s (comparator and store), makes this
		//function much faster.
		return function(itemA, itemB){
			var a = s.getValue(itemA, attr);
			var b = s.getValue(itemB, attr);
			return dir * comp(a,b); //int
		};
	}
	var sortAttribute;
	var map = store.comparatorMap;
	var bc = sorter.basicComparator;
	for(var i = 0; i < sortSpec.length; i++){
		sortAttribute = sortSpec[i];
		var attr = sortAttribute.attribute;
		if(attr){
			var dir = (sortAttribute.descending) ? -1 : 1;
			var comp = bc;
			if(map){
				if(typeof attr !== "string" && ("toString" in attr)){
					 attr = attr.toString();
				}
				comp = map[attr] || bc;
			}
			sortFunctions.push(createSortFunction(attr,
				dir, comp, store));
		}
	}
	return function(rowA, rowB){
		var i=0;
		while(i < sortFunctions.length){
			var ret = sortFunctions[i++](rowA, rowB);
			if(ret !== 0){
				return ret;//int
			}
		}
		return 0; //int
	}; // Function
};

return sorter;
});

}}});
﻿/* This is for collecting all needed modules for bundling/minifying */
