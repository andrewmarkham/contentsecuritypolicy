﻿define("epi-languagemanager/component/command/CreateLanguageBranch", [
// Dojo base
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/aspect",

    // Dijit
    "dijit/popup",
    "dijit/focus",
    "dijit/registry",

    // Language manager
    "epi-languagemanager/component/command/_CommandWithOptions",
    "epi-languagemanager/widget/command/DuplicateContent",
    "epi-languagemanager/widget/command/StartBlank",
    "epi-languagemanager/widget/command/AutoTranslate",

    // Resources
    "epi/i18n!epi/cms/nls/languagemanager.gadget"
],
function (
// Dojo base
    declare,
    lang,
    aspect,

    // Dijit
    popupManager,
    focusUtil,
    registry,

    // Language manager
    _CommandWithOptions,
    DuplicateContent,
    StartBlank,
    AutoTranslate,

    // Resources
    res
) {

    return declare([_CommandWithOptions], {

        label: res.create,

        // For create link
        _internalPopup: null,

        _setupPopup: function (/*Object*/popup) {

            this.inherited(arguments);
            // Set new header label
            popup.set("headingText", lang.replace(res.createpagein, this.model.currentItemData));
        },

        _setupInternalPopup: function (/*Boolean*/commandAvailable) {
            // summary:
            //      Create an independent popup that used to display everywhere
            // tags:
            //      private

            // Close current open popup if command is not available
            if (!commandAvailable) {
                if (this._internalPopup) {
                    var focusNode = focusUtil.get("curNode");
                    popupManager.close(this._internalPopup);
                    this._setEditorFocus(focusNode);
                }

                return;
            }

            if (!this._internalPopup) {
                this._internalPopup = new this.popupClass();
                this._setupEvent(this._internalPopup);
            }
            this._setupPopup(this._internalPopup);
        },

        _onModelChange: function () {
            // summary:
            //      Updates canExecute and isAvailable after the model has been updated.
            // tags:
            //      protected

            this.inherited(arguments);

            var item = this.model.currentItemData;

            if (!item) {
                this.set("canExecute", false);
                this.set("isAvailable", false);
                return;
            }

            var commandAvailable = item.isActive && item.canCreate && !item.isCreated,
                // Do nothing (command disabled) if the content is Wastebasket or Root or has been deleted
                disabled = this.isWastebasket(this.model.contentData) || this.isRoot(this.model.contentData) || this.model.contentData.isDeleted;

            this.set("isAvailable", commandAvailable);
            this.set("canExecute", commandAvailable && !disabled);

            this._setupInternalPopup(commandAvailable && !disabled);
        },

        execute: function (evt) {
            this._execute(evt);
        },

        getSubCommands: function (model) {
            // summary:
            //      Setup sub menu items when user click to create language branch.
            // tags:
            //      public

            var isTranslatingSystemAvailable = model.isTranslatingSystemAvailable;

            var autoTranslate = new AutoTranslate({ model: model }),
                duplicateContent = new DuplicateContent({ model: model }),
                startWithBlank = new StartBlank({ model: model }),
                createLanguageBranchCommands = [
                    {
                        label: autoTranslate.label,
                        value: autoTranslate,
                        disabled: isTranslatingSystemAvailable === false ? "disabled" : false
                    },
                    {
                        label: duplicateContent.label,
                        value: duplicateContent,
                        disabled: false
                    },
                    {
                        label: startWithBlank.label,
                        value: startWithBlank,
                        disabled: false
                    }
                ];

            return createLanguageBranchCommands;
        },

        _execute: function (evt) {
            // summary:
            //      Executes this command assuming canExecute has been checked. Subclasses should override this method.
            // tags:
            //      protected

            var self = this,
                target = this.model.get("target"),
                mouseEvent = evt || target;

            if (!mouseEvent) {
                return;
            }

            var popup = this._internalPopup,
                prevFocusNode = focusUtil.get("prevNode"),
                curFocusNode = focusUtil.get("curNode"),
                focusNode = popup.domNode,
                savedFocusNode = prevFocusNode ? prevFocusNode : curFocusNode;

            var popupBlurHanlder = aspect.after(popup, "onBlur", function () {
                popupBlurHanlder.remove();

                self.model.set("target", null);
                popupManager.close(popup);
                self._setEditorFocus(savedFocusNode);
            });

            focusUtil.focus(focusNode);

            popupManager.open({
                around: mouseEvent.target,
                popup: popup,
                onCancel: function () {
                    popupManager.close(popup);
                }
            });
        },

        _setEditorFocus: function (nodeToFocus) {
            // summary:
            //      Set focus for given dom node and enclosing editor.
            // tags:
            //      private

            if (!nodeToFocus) {
                return;

            }
            nodeToFocus.focus();

            // call _onFocus to make TinyMCE editor active and auto save work
            var parentWidget = registry.getEnclosingWidget(nodeToFocus);
            if (parentWidget && parentWidget._onFocus) {
                parentWidget._onFocus();
            }
        }
    });
});
