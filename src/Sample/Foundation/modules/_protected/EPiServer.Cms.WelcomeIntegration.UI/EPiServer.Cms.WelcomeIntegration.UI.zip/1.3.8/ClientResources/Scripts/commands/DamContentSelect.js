define([
  // dojo
  "dojo/_base/declare",
  "dojo/when",

  // epi
  "epi/shell/command/_Command",
  "epi/routes",
  "epi/dependency",
  "epi/shell/TypeDescriptorManager",

  // epi-cms
  "epi-cms/core/ContentReference",

  // welcome integration
  "../tracking/tracker",

  // resources
  "epi/i18n!epi/cms/nls/episerver.welcomedamintegration"
], function (
  // dojo
  declare,
  when,

  // epi
  _Command,
  routes,
  dependency,
  TypeDescriptorManager,

  // epi-cms
  ContentReference,

  // welcome integration
  tracker,

  // resources
  resources
) {

  return declare([_Command], {
    // summary:
    //		Shell module implementation.
    //
    // tags:
    //      internal

    iconClass: "dijitNoIcon",
    label: "",
    isAvailable: true,
    canExecute: true,

    settings: null,
    moduleArea: null,
    assetTypes: null,

    _store: null,

    onExecuted: function (contentReference) {
      // callback
      this.isExecuting = false;
      this._cleanup();
    },

    onCancelled: function () {
      this._cleanup();
    },

    destroy: function () {
      this._cleanup();
    },

    postscript: function () {
      this.inherited(arguments);

      var registry = dependency.resolve("epi.storeregistry");
      this._store = registry.create("episerver.cms.dam.integration.store." + this.moduleArea, routes.getRestPath({ moduleArea: this.moduleArea, storeName: this.settings.storeName }));
      var iconClass = this.settings && this.settings.iconClass || "epi-iconObjectExternalLink";
      this.label = (resources.command.provider.dam.label + "<span class=\"dijitInline dijitIcon dijitMenuItemIcon {0}\" data-dojo-attach-point=\"iconNode\"></span>").replace("{0}", iconClass);
    },

    _cleanup: function () {
      clearInterval(this.interval);
      removeEventListener("message", this, false);
      this.damWindow = null;
    },

    _getDAMAllowedTypes: function () {
      if (!this.settings.availableTypes || this.settings.availableTypes.length === 0) {
        return [];
      }

      return TypeDescriptorManager.getValidAcceptedTypes(this.settings.availableTypes.split(","), this.model.allowedTypes, this.model.restrictedTypes);
    },

    _onModelChange: function () {
      if (!this.model || !this.settings.availableTypes) {
        return;
      }

      var types = this._getDAMAllowedTypes();

      if (types && types.length > 0) {
        return;
      }

      this.set("isAvailable", false);
    },
    

    _getQuery: function () {
      let data = [];
      var types = this._getDAMAllowedTypes();

      types.forEach(type => {
        switch(type) {
          case "episerver.cms.welcomeintegration.core.internal.damimageasset":
            data.push(["assetTypes", "image"]);
            break;
          case "episerver.cms.welcomeintegration.core.internal.damvideoasset":
            data.push(["assetTypes", "video"]);
            break;
          case "episerver.cms.welcomeintegration.core.internal.damasset":
            data.push(["assetTypes", "raw_file"]);
            break;
          default:
            break;  
        }
      });
      return new URLSearchParams(data);
    },

    _execute: function () {
      var url = new URL(this.settings.endpoint);
      url.pathname = this.settings.path;
      url.search = this._getQuery().toString();

      addEventListener("message", this, false);
      this.handled = false;
      this.damWindow = window.open(url, "Library", "popup");

      if (this.damWindow) {
        // We can't access cross-origin window objects, so we have to check if it's closed by using an interval.
        // The problem is, this can cause a race condition if we click confirm while the close event is being processed.

        this.interval = setInterval(() => {
          if (this.damWindow) {
            // The window exists, but we need to check if the event has been handled or cancelled.
            // This code has to be wrapped in try..catch to avoid user agent policy exceptions.
            // If the window is closed, then we can assume it's been cancelled.
            try {
              if (this.damWindow.closed && !this.isExecuting) {
                // Window is closed, but it still exists in a variable, so it means it was cancelled.
                this.onCancelled();
              } else if (!this.damWindow) {
                // Window is missing, so we have successfully executed the action.
                this._cleanup();
              }
            } catch {
              // Clear the interval and call _cleanup if we can't access the window.
              this._cleanup();
            }
          } else {
            // If for some reason the window is missing, we need to clear the interval...
            this._cleanup();
          }
        }, 500);
      }

      // tracking
      this._trackEvent("openLibrayPopup");
    },

    _trackEvent: function (/*string*/eventType, /*object*/customData) {
      var eventMappings = {
        "openLibrayPopup": Object.assign({}, this.settings)
      };

      var data = customData || eventMappings[eventType];
      tracker.trackEvent(eventType, data)
    },

    handleEvent: function (event) {
      if (!this.damWindow) {
        return;
      }
      this._trackEvent("closeLibrayPopup", event);
      if (event.origin === this.settings.endpoint && event.data && !event.data.type) {
        [].concat(event.data).forEach(function (item) {
          if (!item || !item.url) {
            return;
          }
          this.isExecuting = true;

          fetch(item.url).then(resp => {
            var contentType = [...resp.headers].filter(h => h[0] === "content-type")[0][1];
            var assetType = contentType && this.assetTypes.find(x => contentType.toString().startsWith(x.name.toLowerCase()))?.value;

            when(this._store.put({ externalUrl: item.url, title: item.title, assetType: assetType })).then(function (result) {
              var value = new ContentReference(result.contentLink).toString();
              if (this.model && this.model.modelType && this.model.modelType === "EPiServer.Cms.Shell.UI.ObjectEditing.InternalMetadata.LinkModel") {
                value = { href: result.permanentLink, text: item.title };
              }
              this.onExecuted(value);
            }.bind(this));
          });
        }.bind(this));
      }
    }
  });
});
