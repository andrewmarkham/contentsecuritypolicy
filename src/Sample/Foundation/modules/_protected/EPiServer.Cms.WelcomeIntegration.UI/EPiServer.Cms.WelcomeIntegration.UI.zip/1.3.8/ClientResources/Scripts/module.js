define([
  // dojo
  "dojo/_base/declare",
  "dojo/_base/lang",
  "dojo/when",
  "dojo/aspect",

  // epi
  "epi/_Module",
  "epi/shell/command/_Command",
  "epi-cms/plugin-area/content-selector-plugandplay",
  "epi-cms/core/ContentReference",

  // commands
  "./commands/DamContentSelect",
  "epi-cms/widget/command/DefaultContentSelectorPlugAndPlayCommand",

  // epi widgets
  "epi-cms/widget/ThumbnailSelector"
], function (
  // dojo
  declare,
  lang,
  when,
  aspect,

  // epi
  _Module,
  _Command,
  pluginArea,
  ContentReference,

  // commands
  DamContentSelect,
  DefaultContentSelectorPlugAndPlayCommand,

  // epi widgets
  ThumbnailSelector,
) {

  return declare([_Module], {
    // summary:
    //		Shell module implementation.
    //
    // tags:
    //      internal

    _settings: null,

    constructor: function (settings) {
      this._settings = settings;
    },

    initialize: function () {
      // summary:
      //		Initialize module

      return when(this.inherited(arguments)).then(function () {

        var options = this._settings.options;
        if (!options || !options.enabled || !options.settings) {
          return;
        }

        var that = this;
        for (var key in options.settings) {
          if (options.settings.hasOwnProperty(key)) {
            var settings = options.settings[key];
            if (settings) {
              var contentSelectCommand = new DamContentSelect({
                settings: settings,
                moduleArea: that._settings.name,
                assetTypes: that._settings.assetTypes
              });
              pluginArea.add(contentSelectCommand);
              this._overrideDefaultContentSelectorCommand(contentSelectCommand);
              this._overrideThumbnailSelector(contentSelectCommand);
            }
          }
        }
      }.bind(this));
    },

    _overrideThumbnailSelector: function (contentSelectCommand) {
      // summary:
      //		Override default content selector command to open Welcome when executing the replace functionality for ThumbnailSelector.
      //
      // tags:
      //		private

      var originalOnClick = ThumbnailSelector.prototype._onClick;
      ThumbnailSelector.prototype._onClick = function () {
        if (this.contentLink) {
          var contentLink = ContentReference.toContentReference(this.contentLink);
          if (contentLink) {
            var isDamAsset = contentLink.providerName === "dam";
            if (isDamAsset) {
              var modifiedContentSelectCommand = lang.mixin(contentSelectCommand, { model: this.contentSelectorDialogSettings });
              var executionAspect = aspect.after(modifiedContentSelectCommand, "onExecuted", function (value) {
                this.contentSelectorPnP.onDialogExecute(value);
                executionAspect.remove();
              }.bind(this), true);

              // If we close the window, we need to clean up both aspects.
              var cancellationAspect = aspect.after(modifiedContentSelectCommand, "onCancelled", function (value) {
                executionAspect.remove();
                cancellationAspect.remove();
              }.bind(this), true);
              modifiedContentSelectCommand.execute();
            }
          }
        }

        originalOnClick.apply(this, arguments);
      }
    },

    _overrideDefaultContentSelectorCommand: function (contentSelectCommand) {
      // summary:
      //		Override default content selector command to open Welcome when executing the replace functionality.
      //
      // tags:
      //		private

      var originalExecute = DefaultContentSelectorPlugAndPlayCommand.prototype.execute;
      DefaultContentSelectorPlugAndPlayCommand.prototype.execute = function () {
        // If it has a model and contentLink, it is safe to assume we are calling "replace".
        if (this.model && this.model.contentLink) {

          // Check if it's a DAM asset, then call the execute
          var contentLink = ContentReference.toContentReference(this.model.contentLink);
          if (contentLink) {
            var isDamAsset = contentLink.providerName === "dam";
            if (isDamAsset) {
              // We need to clone the command.
              var modifiedContentSelectCommand = lang.mixin(contentSelectCommand, { model: this.contentSelectorDialogSettings });
              // Bind the `onExecuted` of this command to the `onDialogExecute` of the ContentSelect command.
              var executionAspect = aspect.after(modifiedContentSelectCommand, "onExecuted", function (value) {
                this.onDialogExecute(value);
                executionAspect.remove();
              }.bind(this), true);

              // If we close the window, we need to clean up both aspects.
              var cancellationAspect = aspect.after(modifiedContentSelectCommand, "onCancelled", function (value) {
                executionAspect.remove();
                cancellationAspect.remove();
              }.bind(this), true);
              modifiedContentSelectCommand.execute();
              return;
            }
          }
        }

        // Otherwise just fall through and call the original.
        originalExecute.apply(this, arguments);
      }
    }
  });
});
