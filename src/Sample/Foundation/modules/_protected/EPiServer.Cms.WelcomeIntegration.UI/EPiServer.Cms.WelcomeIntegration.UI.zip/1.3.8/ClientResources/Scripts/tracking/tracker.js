define([], function () {
  return {
    trackEvent: function (event, data) {
      if (typeof aptrinsic === "function") {
        aptrinsic('track', event, data);
      }
    }
  };
});
