define("epi-cms/command/TranslateContent", [
    "require",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/Deferred",
    "dojo/when",
    "dojo/topic",
    "epi/i18n!epi/cms/nls/episerver.cms.contentediting.toolbar.buttons.translate",
    "epi/shell/command/_Command",
    "epi-cms/ContentLanguageHelper"
], function (moduleRequire, declare, lang, Deferred, when, topic, resources, _Command, ContentLanguageHelper) {
    return declare([_Command], {
        // tags:
        //      internal xproduct
        // label: [public] String
        //      The action text of the command to be used in visual elements.
        label: resources.label,
        // iconClass: [readonly] String
        //		The icon class of the command to be used in visual elements.
        iconClass: "epi-iconLanguage",
        // executingLabel: [public] String
        //      The action text of the command when executing to be used in visual elements.
        executingLabel: resources.executinglabel,
        // tooltip: [public] String
        //      The description text of the command to be used in visual elements.
        tooltip: resources.title,
        // category: [const] String
        //      A category which provides a hint about how the command could be displayed.
        category: "context",
        _execute: function () {
            // summary:
            //      Publishes a change view request to change to the create language branch view.
            // tags:
            //      protected
            if (typeof this.executeDelegate === "function") {
                this.executeDelegate(this.model);
            }
            else {
                this._showTranslateContentDialog();
            }
        },
        _onModelChange: function () {
            // summary:
            //      Updates canExecute after the model has been updated.
            // tags:
            //      protected
            this._normalizeModel(this.model).then(function (normalizedModel) {
                this.model = normalizedModel;
                this.set("isAvailable", this.calculateIsAvailable(normalizedModel));
                this.set("canExecute", this.calculateCanExecute(normalizedModel));
            }.bind(this));
        },
        _normalizeModel: function (model) {
            // summary:
            //      Normalizes the model to contain all necessary information for the command to work.
            // tags:
            //      private
            var contentModel = model ? model.contentData ? model.contentData : model : null;
            if (!contentModel || !contentModel.contentLink) {
                return new Deferred().resolve(null);
            }
            var _model = {
                contentLink: contentModel.contentLink,
                // when this.model.missingLanguageBranch is set,it indicates that content is missing in the current language.
                targetLanguage: contentModel.missingLanguageBranch ?
                    contentModel.missingLanguageBranch.preferredLanguage :
                    model.currentContentLanguage ? model.currentContentLanguage : null,
                sourceLanguage: contentModel.missingLanguageBranch ?
                    contentModel.missingLanguageBranch.language :
                    contentModel.currentLanguageBranch ? contentModel.currentLanguageBranch.languageId : null
            };
            return when(ContentLanguageHelper.getContentLanguages(contentModel.contentLink))
                .then(function (contentLanguages) {
                return lang.mixin(_model, {
                    masterLanguage: contentLanguages.masterLanguage,
                    existingLanguages: contentLanguages.existingLanguages,
                    missingLanguages: contentLanguages.missingLanguages
                });
            })
                .otherwise(function () {
                return _model;
            });
        },
        calculateIsAvailable: function (model) {
            // The existing of masterLanguage indicates that the content is localizable.
            return !!(model && model.masterLanguage);
        },
        calculateCanExecute: function (model) {
            return !!(model && model.masterLanguage && (model.missingLanguages && model.missingLanguages.length > 0) && (model.existingLanguages && model.existingLanguages.length > 0));
        },
        _showTranslateContentDialog: function () {
            if (!this.model) {
                console.error("TranslateContentCommand: model is not set.");
                return;
            }
            var loadTranslateContentWidget = this.translateContentWidget
                ? Promise.resolve(this.translateContentWidget)
                : new Promise(function (resolve) {
                    moduleRequire([
                        "epi-cms-react/components/translate-content-widget"
                    ], function (TranslateContentWidget) {
                        this.translateContentWidget = TranslateContentWidget;
                        resolve(TranslateContentWidget);
                    }.bind(this));
                }.bind(this));
            loadTranslateContentWidget.then(function (TranslateContentWidget) {
                var translateContentWidget = new TranslateContentWidget({
                    model: lang.mixin(this.model, {
                        onTranslateSuccess: function (newContentLink, targetLanguage, sourceLanguage) {
                            this._onSaveSuccess(newContentLink, targetLanguage);
                        }.bind(this)
                    })
                });
                translateContentWidget.render();
            }.bind(this));
        },
        _onSaveSuccess: function (contentLink, languageBranch) {
            // summary:
            //    Handle save success event from the model.
            //
            // tags:
            //    private
            try {
                var url = new URL(window.location.href);
                if (!url) {
                    throw new Error("Error while setting content language");
                }
                var urlToNavigate = [
                    url.protocol,
                    "//",
                    url.host,
                    url.pathname,
                    "?language=",
                    languageBranch,
                    "#context=epi.cms.contentdata:///",
                    contentLink,
                    "&viewsetting=viewlanguage:///",
                    languageBranch
                ].join("");
                var contentUrl = new URL(urlToNavigate);
                topic.publish("/epi/shell/context/request", { uri: "epi.cms.contentdata:///" + contentLink }, {
                    sender: this,
                    forceContextChange: true,
                    forceReload: true
                });
                if (url.href !== contentUrl.href) {
                    setTimeout(function () {
                        window.location.assign(contentUrl);
                    }, 0);
                }
                // Stop further execution
                return;
            }
            catch (err) {
                console.error(err.message);
                // Fallback to window.location reload?
                window.location.reload();
            }
        }
    });
});
