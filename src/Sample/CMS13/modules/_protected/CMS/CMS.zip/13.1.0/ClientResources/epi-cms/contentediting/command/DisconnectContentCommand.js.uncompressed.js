define("epi-cms/contentediting/command/DisconnectContentCommand", [
    "require",
    "dojo/_base/declare",
    "epi/shell/command/_Command",
    "epi-cms/contentediting/command/_ContentCommandBase",
    //Resources
    "epi/i18n!epi/cms/nls/episerver.cms.contentbinding.disconnectcontent"
], function (moduleRequire, declare, _Command, _ContentCommandBase, resources) {
    return declare([_ContentCommandBase], {
        // summary:
        //      Disconnect content from a content source.
        //
        // tags:
        //      internal
        name: "disconnectcontent",
        label: resources.command,
        category: _Command.CateoryMenuWithSeparator,
        // summary:
        // Model should be IContentBindable, so it should has the properties below:
        //    IContentBindable {
        //        contentBindable?: ContentBindableModel;
        //        contentTypeID: number;
        //    }
        model: null,
        // summary:
        //      Update the content binding after user selected a source content.
        updateBinding: function () {
            // Override to provide custom binding update logic.
        },
        _onModelChange: function () {
            // summary:
            //		Updates canExecute after the model has been updated.
            // tags:
            //		protected
            this.inherited(arguments);
            var canExecute = !!this.model &&
                !!this.model.contentBindable &&
                !!this.model.contentBindable.binding &&
                !this.model.readOnly;
            this.set("canExecute", canExecute);
            this.set("isAvailable", canExecute);
        },
        _execute: function () {
            var loadDialog = this.showBindingContentDialog
                ? Promise.resolve(this.showBindingContentDialog)
                : new Promise(function (resolve) {
                    moduleRequire(["epi-cms-react/components/show-binding-content-dialog"], function (showBindingContentDialog) {
                        this.showBindingContentDialog = showBindingContentDialog;
                        resolve(showBindingContentDialog);
                    }.bind(this));
                }.bind(this));
            return loadDialog.then(function (dialog) {
                dialog.showDisconnectContentDialog({
                    sourceContentName: this.model.contentBindable.binding.name,
                    updateBinding: this.updateBinding.bind(this)
                });
            }.bind(this));
        }
    });
});
