define(["require","exports","./index_2","./icon_2"],(function(i,e,t,o){"use strict";var r=o.requireReactDom();const c=t.getDefaultExportFromCjs(r);e.ReactDOM=c,e.reactDomExports=r}));
//# sourceMappingURL=index_23.js.map
