define("epi-cms/contentediting/command/ConnectInlineContentCommand", [
    "require",
    "dojo/_base/declare",
    "epi/shell/command/_Command",
    "epi-cms/contentediting/command/_ContentCommandBase",
    //Resources
    "epi/i18n!epi/cms/nls/episerver.cms.contentbinding.connectcontent",
    "epi/i18n!epi/cms/nls/episerver.visualbuilder.editors.commands"
], function (moduleRequire, declare, _Command, _ContentCommandBase, connectContentCommandsResources, visualBuilderCommandsResources) {
    return declare([_ContentCommandBase], {
        // summary:
        //      Connect content to a content source.
        //
        // tags:
        //      internal
        name: "connectcontent",
        label: connectContentCommandsResources.command,
        iconClass: "epi-iconLink",
        category: _Command.CateoryMenuWithSeparator,
        showSeparator: true,
        // summary:
        // Model should be IContentBindable, so it should has the properties below:
        //    IContentBindable {
        //        contentBindable?: ContentBindableModel;
        //        contentTypeID: number;
        //    }
        model: null,
        /** List of content type GUIDs from which source contents can be selected. */
        allowedTypes: [],
        // summary:
        //      Update the content binding after user selected a source content.
        updateBinding: function (sourceContentLink) {
            // Override to provide custom binding update logic.
        },
        _onModelChange: function () {
            // summary:
            //		Updates canExecute after the model has been updated.
            // tags:
            //		protected
            this.inherited(arguments);
            this.set("label", connectContentCommandsResources.command);
            this.set("allowedTypes", []);
            this.set("showSeparator", true);
            if (!this.model || !this.model.contentTypeId || this.model.contentLink || this.model.readOnly) {
                this.set("canExecute", false);
                this.set("isAvailable", false);
                return;
            }
            var loadService = this.contentBindingService
                ? Promise.resolve(this.contentBindingService)
                : new Promise(function (resolve) {
                    moduleRequire(["epi-cms-react/components/content-binding-service"], function (contentBindingService) {
                        this.contentBindingService = contentBindingService;
                        resolve(contentBindingService);
                    }.bind(this));
                }.bind(this));
            loadService
                .then(function (service) {
                return service.getBindingDefinitions(this.model.contentTypeId);
            }.bind(this))
                .then(function (bindingDefinitions) {
                var canExecute = bindingDefinitions && bindingDefinitions.length > 0;
                this.set("canExecute", canExecute);
                this.set("isAvailable", canExecute);
                var allowedTypes = [];
                for (var i = 0; i < (bindingDefinitions ? bindingDefinitions.length : 0); i++) {
                    allowedTypes.push(bindingDefinitions[i].contentType);
                }
                this.set("allowedTypes", allowedTypes);
                if (this.model && this.model.contentBindable && this.model.contentBindable.binding) {
                    this.set("label", visualBuilderCommandsResources.replace);
                    this.set("showSeparator", false);
                }
            }.bind(this));
        },
        _execute: function () {
            var loadDialog = this.showBindingContentDialog
                ? Promise.resolve(this.showBindingContentDialog)
                : new Promise(function (resolve) {
                    moduleRequire(["epi-cms-react/components/show-binding-content-dialog"], function (showBindingContentDialog) {
                        this.showBindingContentDialog = showBindingContentDialog;
                        resolve(showBindingContentDialog);
                    }.bind(this));
                }.bind(this));
            return loadDialog.then(function (dialog) {
                dialog.showConnectContentDialog({
                    allowedTypesGuids: this.allowedTypes,
                    updateBinding: this.updateBinding.bind(this)
                });
            }.bind(this));
        }
    });
});
